import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function makeZipBackup() {
  const zip = new JSZip();
  const backupDir = path.resolve(process.cwd(), 'backup');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  function addDirToZip(dirPath, zipFolder) {
    const items = fs.readdirSync(dirPath);
    for (const item of items) {
      if (item === 'node_modules' || item === '.git' || item === 'dist' || item === 'backup') continue;
      const fullPath = path.join(dirPath, item);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        const subFolder = zipFolder.folder(item);
        addDirToZip(fullPath, subFolder);
      } else {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(item, content);
      }
    }
  }

  addDirToZip(process.cwd(), zip);

  const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFilePath = path.join(backupDir, `backup_termal_sablon_${timestamp}.zip`);
  const latestBackupPath = path.join(backupDir, 'latest_backup.zip');

  fs.writeFileSync(backupFilePath, buffer);
  fs.writeFileSync(latestBackupPath, buffer);
  console.log(`Backup created successfully: ${backupFilePath}`);
}

makeZipBackup().catch(console.error);
