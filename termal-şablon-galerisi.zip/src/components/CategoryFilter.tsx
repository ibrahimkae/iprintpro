import React from 'react';
import { LabelCategory } from '../types';
import { CATEGORY_METADATA } from '../data/dimensions';
import {
  LayoutGrid,
  ShoppingBag,
  Tag,
  Receipt,
  Barcode,
  Truck,
  AlertTriangle,
  Layers,
  Sparkles,
  CheckSquare,
  Bookmark
} from 'lucide-react';

interface CategoryFilterProps {
  activeCategory: LabelCategory;
  onSelectCategory: (cat: LabelCategory) => void;
  categoryCounts: Record<string, number>;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  activeCategory,
  onSelectCategory,
  categoryCounts
}) => {
  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'ecommerce_shipping':
        return <ShoppingBag size={13} />;
      case 'product':
        return <Tag size={13} />;
      case 'receipt':
        return <Receipt size={13} />;
      case 'inventory':
        return <Barcode size={13} />;
      case 'shipping':
        return <Truck size={13} />;
      case 'warning':
        return <AlertTriangle size={13} />;
      case 'organization':
        return <Layers size={13} />;
      case 'stickers':
        return <Sparkles size={13} />;
      case 'notes':
        return <CheckSquare size={13} />;
      case 'custom':
        return <Bookmark size={13} />;
      case 'all':
      default:
        return <LayoutGrid size={13} />;
    }
  };

  return (
    <div className="w-full overflow-x-auto pb-1 scrollbar-none no-print">
      <div className="flex items-center gap-2 min-w-max">
        {CATEGORY_METADATA.map((cat) => {
          const isSelected = activeCategory === cat.id;
          const count = categoryCounts[cat.id] ?? 0;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id as LabelCategory)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer active:scale-95 ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30 border border-blue-500'
                  : 'bg-[#1E1E1E] hover:bg-[#252525] text-gray-300 border border-[#2A2A2A]'
              }`}
            >
              {getCategoryIcon(cat.id)}
              <span>{cat.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-[#2A2A2A] text-gray-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
