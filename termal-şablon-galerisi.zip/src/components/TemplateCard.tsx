import React from 'react';
import { ThermalTemplate, LabelDimension, ThermalPaperStyle } from '../types';
import { ThermalTemplateRenderer } from './ThermalTemplateRenderer';
import { Heart, Printer, Edit3 } from 'lucide-react';

interface TemplateCardProps {
  template: ThermalTemplate;
  dimension: LabelDimension;
  paperStyle: ThermalPaperStyle;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onSelect: (template: ThermalTemplate) => void;
  onQuickPrint: (template: ThermalTemplate) => void;
}

export const TemplateCard: React.FC<TemplateCardProps> = ({
  template,
  dimension,
  paperStyle,
  isFavorite,
  onToggleFavorite,
  onSelect,
  onQuickPrint
}) => {
  // Use selected dimension from top bar, fallback to template's recommended dimension
  const cardWidthMm = dimension.widthMm || template.recommendedWidthMm || 57;
  const cardHeightMm = dimension.heightMm ? dimension.heightMm : template.heightMm;

  // Auto-calculate scale factor for 2-column mobile and multi-column desktop
  // Ensures labels fit crisply and fill the card cleanly
  const baseContainerWidth = 195;
  const calculatedScale = Math.min(0.92, baseContainerWidth / (cardWidthMm * 4.6));

  return (
    <div
      onClick={() => onSelect(template)}
      className="break-inside-avoid mb-2 sm:mb-3.5 md:mb-4 group relative bg-[#151515] rounded-xl sm:rounded-2xl border border-[#262626] hover:border-blue-500/80 shadow-sm hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-200 overflow-hidden cursor-pointer w-full flex flex-col"
    >
      {/* Pure Visual Thermal Label Stage (Exact Aspect Ratio Preview) */}
      <div className="p-1.5 sm:p-3 bg-[#111111] flex items-center justify-center relative overflow-hidden transition-colors group-hover:bg-[#141414] min-h-[100px] sm:min-h-[140px]">
        <div className="transform group-hover:scale-[1.02] transition-transform duration-200 origin-center drop-shadow-md flex items-center justify-center pointer-events-none max-w-full">
          <ThermalTemplateRenderer
            template={template}
            data={template.defaultData}
            widthMm={cardWidthMm}
            heightMm={cardHeightMm}
            paperStyle={paperStyle}
            scale={calculatedScale}
          />
        </div>

        {/* Favorite indicator badge (Top Right) */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(template.id);
          }}
          className={`absolute top-1.5 right-1.5 sm:top-2 sm:right-2 z-10 w-6 h-6 sm:w-7 sm:h-7 rounded-full flex items-center justify-center backdrop-blur-md transition-all active:scale-90 ${
            isFavorite
              ? 'bg-red-500/30 text-red-400 border border-red-500/50 shadow-md'
              : 'bg-black/60 text-gray-400 hover:text-red-400 border border-white/10 opacity-70 hover:opacity-100'
          }`}
          title={isFavorite ? 'Favorilerden Çıkar' : 'Favorilere Ekle'}
        >
          <Heart size={12} fill={isFavorite ? 'currentColor' : 'none'} />
        </button>

        {/* Dimension badge (Top Left) */}
        <div className="absolute top-1.5 left-1.5 sm:top-2 sm:left-2 z-10">
          <span className="px-1.5 py-0.5 text-[8px] sm:text-[9px] font-mono font-bold text-gray-200 bg-black/70 backdrop-blur-md rounded border border-white/10 shadow-xs">
            {cardWidthMm}mm{cardHeightMm ? `×${cardHeightMm}` : ''}
          </span>
        </div>

        {/* Desktop Hover Overlay with Action Details */}
        <div className="hidden sm:flex absolute inset-0 bg-gradient-to-t from-black/95 via-black/60 to-black/30 opacity-0 group-hover:opacity-100 transition-all duration-200 flex-col justify-between p-3 backdrop-blur-[2px] z-20">
          <div className="flex items-center justify-between gap-2">
            <span className="bg-blue-600 text-white text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-md tracking-wider shadow-sm">
              {template.category}
            </span>
          </div>

          <div className="space-y-1.5">
            <div>
              <h3 className="font-bold text-white text-xs leading-snug line-clamp-1 group-hover:text-blue-300 transition-colors">
                {template.title}
              </h3>
              <p className="text-[10px] text-gray-300 line-clamp-2 mt-0.5 leading-relaxed opacity-90">
                {template.description}
              </p>
            </div>

            <div className="flex items-center gap-1.5 pt-1 border-t border-white/10">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect(template);
                }}
                className="flex-1 py-1.5 px-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10.5px] shadow-md flex items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <Edit3 size={12} />
                <span>Düzenle & Aç</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickPrint(template);
                }}
                className="p-1.5 rounded-lg bg-black/60 hover:bg-[#333] border border-white/15 text-blue-400 hover:text-blue-300 shadow-md active:scale-95 transition-all"
                title="Hızlı Yazdır"
              >
                <Printer size={13} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
