import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';

interface BarcodeRendererProps {
  value: string;
  format?: 'CODE128' | 'EAN13' | 'CODE39' | 'UPC' | 'ITF';
  width?: number;
  height?: number;
  displayValue?: boolean;
  fontSize?: number;
  font?: string;
  textAlign?: 'left' | 'center' | 'right';
  textPosition?: 'bottom' | 'top';
  lineColor?: string;
  background?: string;
  className?: string;
}

export const BarcodeRenderer: React.FC<BarcodeRendererProps> = ({
  value,
  format = 'CODE128',
  width = 1.6,
  height = 36,
  displayValue = true,
  fontSize = 11,
  font = 'JetBrains Mono',
  textAlign = 'center',
  textPosition = 'bottom',
  lineColor = '#000000',
  background = 'transparent',
  className = ''
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;
    try {
      // Clean value according to format if needed
      let safeValue = value || '00000000';
      if (format === 'EAN13') {
        safeValue = safeValue.replace(/\D/g, '').slice(0, 13).padEnd(12, '0');
      }

      JsBarcode(svgRef.current, safeValue, {
        format: format,
        width: Math.max(1, width),
        height: Math.max(18, height),
        displayValue: displayValue,
        text: value,
        font: font,
        textAlign: textAlign,
        textPosition: textPosition,
        fontSize: fontSize,
        background: background,
        lineColor: lineColor,
        margin: 2,
        valid: () => true
      });
    } catch (err) {
      console.warn('JsBarcode render error with format', format, 'fallback to CODE128', err);
      try {
        if (svgRef.current) {
          JsBarcode(svgRef.current, value || 'CODE-128', {
            format: 'CODE128',
            width: Math.max(1, width),
            height: Math.max(18, height),
            displayValue: displayValue,
            fontSize: fontSize,
            background: background,
            lineColor: lineColor,
            margin: 2
          });
        }
      } catch (fallbackErr) {
        console.error('Barcode complete fallback failure:', fallbackErr);
      }
    }
  }, [value, format, width, height, displayValue, fontSize, font, textAlign, textPosition, lineColor, background]);

  return (
    <div className={`flex flex-col items-center justify-center max-w-full overflow-hidden ${className}`}>
      <svg ref={svgRef} className="max-w-full h-auto" style={{ shapeRendering: 'crispEdges' }} />
    </div>
  );
};
