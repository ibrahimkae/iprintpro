/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { ThermalTemplate, LabelCategory, LabelDimension, ThermalPaperStyle } from './types';
import { INITIAL_TEMPLATES } from './data/templates';
import { STANDARD_DIMENSIONS, CATEGORY_METADATA } from './data/dimensions';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { CategoryFilter } from './components/CategoryFilter';
import { TemplateCard } from './components/TemplateCard';
import { TemplateEditorModal } from './components/TemplateEditorModal';
import { CustomTemplateCreatorModal } from './components/CustomTemplateCreatorModal';
import { BackupModal } from './components/BackupModal';
import { ThermalTemplateRenderer } from './components/ThermalTemplateRenderer';
import {
  Printer,
  Sparkles,
  Layers,
  Archive,
  Search,
  Filter,
  Plus,
  Heart,
  SlidersHorizontal,
  Info,
  CheckCircle2
} from 'lucide-react';

const LOCAL_STORAGE_KEY_CUSTOM = 'termal_studio_custom_templates';
const LOCAL_STORAGE_KEY_FAVORITES = 'termal_studio_favorites';

export default function App() {
  const [standardTemplates] = useState<ThermalTemplate[]>(INITIAL_TEMPLATES);
  const [userCustomTemplates, setUserCustomTemplates] = useState<ThermalTemplate[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState<LabelCategory>('all');
  const [selectedDimension, setSelectedDimension] = useState<LabelDimension>(STANDARD_DIMENSIONS[0]); // 57mm default
  const [paperStyle, setPaperStyle] = useState<ThermalPaperStyle>('standard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  // Modals state
  const [activeTemplate, setActiveTemplate] = useState<ThermalTemplate | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState<boolean>(false);
  const [quickPrintTemplate, setQuickPrintTemplate] = useState<ThermalTemplate | null>(null);

  // Load custom templates & favorites from local storage on mount
  useEffect(() => {
    try {
      const savedCustom = localStorage.getItem(LOCAL_STORAGE_KEY_CUSTOM);
      if (savedCustom) {
        setUserCustomTemplates(JSON.parse(savedCustom));
      }
      const savedFavs = localStorage.getItem(LOCAL_STORAGE_KEY_FAVORITES);
      if (savedFavs) {
        setFavorites(JSON.parse(savedFavs));
      }
    } catch (e) {
      console.error('LocalStorage load error:', e);
    }
  }, []);

  // Save custom templates
  const saveCustomTemplates = (list: ThermalTemplate[]) => {
    setUserCustomTemplates(list);
    localStorage.setItem(LOCAL_STORAGE_KEY_CUSTOM, JSON.stringify(list));
  };

  // Toggle favorite
  const handleToggleFavorite = (id: string) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      localStorage.setItem(LOCAL_STORAGE_KEY_FAVORITES, JSON.stringify(next));
      return next;
    });
  };

  // Add customized copy of template
  const handleSaveAsCustom = (
    baseTemplate: ThermalTemplate,
    customTitle: string,
    customData: Record<string, any>
  ) => {
    const newTpl: ThermalTemplate = {
      ...baseTemplate,
      id: `custom-${Date.now()}`,
      title: customTitle,
      defaultData: customData,
      isCustom: true,
      category: 'custom',
      createdAt: Date.now()
    };
    const updated = [newTpl, ...userCustomTemplates];
    saveCustomTemplates(updated);
  };

  // Add brand new custom template
  const handleAddCustomTemplate = (newTpl: ThermalTemplate) => {
    const updated = [newTpl, ...userCustomTemplates];
    saveCustomTemplates(updated);
    setActiveCategory('custom');
  };

  // Restore backup
  const handleRestoreBackup = (importedList: ThermalTemplate[]) => {
    saveCustomTemplates(importedList);
  };

  // All combined templates
  const allTemplates = useMemo(() => {
    return [...userCustomTemplates, ...standardTemplates];
  }, [userCustomTemplates, standardTemplates]);

  // Category counts calculation
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {
      all: allTemplates.length,
      ecommerce_shipping: 0,
      product: 0,
      receipt: 0,
      inventory: 0,
      shipping: 0,
      warning: 0,
      organization: 0,
      stickers: 0,
      notes: 0,
      custom: userCustomTemplates.length
    };

    allTemplates.forEach((tpl) => {
      if (counts[tpl.category] !== undefined) {
        counts[tpl.category]++;
      }
    });

    return counts;
  }, [allTemplates, userCustomTemplates]);

  // Filtered templates based on search, category, and favorites
  const filteredTemplates = useMemo(() => {
    return allTemplates.filter((tpl) => {
      // Favorites filter
      if (showFavoritesOnly && !favorites.includes(tpl.id)) {
        return false;
      }

      // Category filter
      if (activeCategory === 'custom') {
        if (!tpl.isCustom && tpl.category !== 'custom') return false;
      } else if (activeCategory !== 'all' && tpl.category !== activeCategory) {
        return false;
      }

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = tpl.title.toLowerCase().includes(q);
        const matchDesc = tpl.description.toLowerCase().includes(q);
        const matchTags = tpl.tags.some((t) => t.toLowerCase().includes(q));
        const matchValues = Object.values(tpl.defaultData).some(
          (val) => typeof val === 'string' && val.toLowerCase().includes(q)
        );
        if (!matchTitle && !matchDesc && !matchTags && !matchValues) {
          return false;
        }
      }

      return true;
    });
  }, [allTemplates, activeCategory, showFavoritesOnly, favorites, searchQuery]);

  // Open editor modal for specific template
  const handleOpenEditor = (template: ThermalTemplate) => {
    setActiveTemplate(template);
    setIsEditorOpen(true);
  };

  // Quick print
  const handleQuickPrint = (template: ThermalTemplate) => {
    setQuickPrintTemplate(template);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  return (
    <div className="min-h-screen bg-[#121212] flex font-sans text-white selection:bg-blue-600 selection:text-white">
      
      {/* Left Bento Sidebar */}
      <Sidebar
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        categoryCounts={categoryCounts}
        selectedDimension={selectedDimension}
        onDimensionChange={setSelectedDimension}
        showFavoritesOnly={showFavoritesOnly}
        onToggleFavoritesOnly={() => setShowFavoritesOnly(!showFavoritesOnly)}
        favoritesCount={favorites.length}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
        onOpenBackupModal={() => setIsBackupModalOpen(true)}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Studio Canvas */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Bento Header */}
        <Header
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedDimension={selectedDimension}
          onDimensionChange={setSelectedDimension}
          paperStyle={paperStyle}
          onPaperStyleChange={setPaperStyle}
          showFavoritesOnly={showFavoritesOnly}
          onToggleFavoritesOnly={() => setShowFavoritesOnly(!showFavoritesOnly)}
          favoritesCount={favorites.length}
          onOpenCreateModal={() => setIsCreateModalOpen(true)}
          onOpenBackupModal={() => setIsBackupModalOpen(true)}
          onToggleMobileMenu={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        />

        {/* Main Content Workspace */}
        <main className="flex-1 p-2.5 sm:p-5 md:p-6 overflow-y-auto space-y-3 sm:space-y-5">
          
          {/* Top Quick Category Pills (for horizontal scrolling) */}
          <div className="no-print">
            <CategoryFilter
              activeCategory={activeCategory}
              onSelectCategory={setActiveCategory}
              categoryCounts={categoryCounts}
            />
          </div>

          {/* Bento Info & Status Row */}
          <div className="bg-[#181818] border border-[#2A2A2A] rounded-xl sm:rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 sm:gap-3 no-print">
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-bold shrink-0">
                <Printer size={15} />
              </div>
              <div>
                <h2 className="text-xs sm:text-base font-extrabold text-white flex items-center gap-1.5 sm:gap-2 leading-none">
                  {showFavoritesOnly
                    ? 'Favori Şablonlarım'
                    : activeCategory === 'all'
                    ? 'Tüm Şablon Arşivi'
                    : CATEGORY_METADATA.find((c) => c.id === activeCategory)?.label || 'Şablonlar'}
                  <span className="px-1.5 sm:px-2 py-0.5 rounded-full bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[9px] sm:text-[10px] font-mono">
                    {filteredTemplates.length} Şablon
                  </span>
                </h2>
                <p className="text-[10px] sm:text-xs text-gray-400 mt-0.5">
                  Termal 203 DPI vektörel şablonlar, gerçek baskı boyutlarında ölçeklenir.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 text-[10px] sm:text-xs text-gray-400 bg-[#222] border border-[#2A2A2A] px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-lg sm:rounded-xl w-full sm:w-auto justify-between sm:justify-start">
              <div className="flex items-center gap-1.5 font-mono text-gray-300">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Rulo: <strong className="text-white font-bold">{selectedDimension.name}</strong></span>
              </div>
              <span className="text-gray-600">|</span>
              <span className="text-gray-300">ESC/POS</span>
            </div>
          </div>

          {/* Pinterest-Style Masonry Waterfall Gallery (2 Columns on Mobile, Multi-Column on Desktop) */}
          {filteredTemplates.length > 0 ? (
            <div className="columns-2 sm:columns-2 md:columns-3 lg:columns-3 xl:columns-4 gap-2.5 sm:gap-4 md:gap-5 no-print">
              {filteredTemplates.map((template) => (
                <TemplateCard
                  key={template.id}
                  template={template}
                  dimension={selectedDimension}
                  paperStyle={paperStyle}
                  isFavorite={favorites.includes(template.id)}
                  onToggleFavorite={handleToggleFavorite}
                  onSelect={handleOpenEditor}
                  onQuickPrint={handleQuickPrint}
                />
              ))}
            </div>
          ) : (
            /* Empty State in Bento style */
            <div className="bg-[#181818] rounded-3xl p-12 text-center border border-[#2A2A2A] max-w-md mx-auto my-12 shadow-xl space-y-3 no-print">
              <div className="w-12 h-12 rounded-2xl bg-[#252525] text-gray-400 flex items-center justify-center mx-auto border border-[#333]">
                <Search size={22} />
              </div>
              <h3 className="text-base font-bold text-white">Aradığınız kriterlere uygun şablon bulunamadı</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Filtreleri sıfırlayabilir veya özel termal şablon tasarımınızı galeriye ekleyebilirsiniz.
              </p>
              <div className="pt-2 flex justify-center gap-2">
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveCategory('all');
                    setShowFavoritesOnly(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-[#252525] hover:bg-[#333] border border-[#2A2A2A] text-gray-200 text-xs font-bold transition-colors"
                >
                  Filtreleri Sıfırla
                </button>
                <button
                  onClick={() => setIsCreateModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/30 transition-colors"
                >
                  Özel Şablon Ekle
                </button>
              </div>
            </div>
          )}

        </main>

        {/* Footer */}
        <footer className="border-t border-[#2A2A2A] bg-[#181818] px-6 py-4 text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-2 no-print">
          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-300">ThermalLab Studio</span>
            <span>•</span>
            <span>57mm & Dinamik Termal Şablon Galerisi (Bento Grid)</span>
          </div>
          <div className="text-[11px] text-gray-500 font-mono">
            ESC/POS • 203 DPI • Vektör Baskı Motoru
          </div>
        </footer>

      </div>

      {/* Hidden Print Container specifically targeted by CSS @media print */}
      <div className="print-area-container hidden">
        {quickPrintTemplate && (
          <ThermalTemplateRenderer
            template={quickPrintTemplate}
            data={quickPrintTemplate.defaultData}
            widthMm={quickPrintTemplate.recommendedWidthMm || selectedDimension.widthMm || 57}
            heightMm={quickPrintTemplate.heightMm || selectedDimension.heightMm}
            isPrintMode={true}
          />
        )}
      </div>

      {/* Modals */}
      {isEditorOpen && activeTemplate && (
        <TemplateEditorModal
          template={activeTemplate}
          isOpen={isEditorOpen}
          onClose={() => setIsEditorOpen(false)}
          onSaveAsCustom={handleSaveAsCustom}
          initialWidthMm={selectedDimension.widthMm}
          initialPaperStyle={paperStyle}
        />
      )}

      {isCreateModalOpen && (
        <CustomTemplateCreatorModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onAddCustomTemplate={handleAddCustomTemplate}
        />
      )}

      {isBackupModalOpen && (
        <BackupModal
          isOpen={isBackupModalOpen}
          onClose={() => setIsBackupModalOpen(false)}
          templates={standardTemplates}
          userCustomTemplates={userCustomTemplates}
          favorites={favorites}
          onRestoreBackup={handleRestoreBackup}
        />
      )}

    </div>
  );
}
