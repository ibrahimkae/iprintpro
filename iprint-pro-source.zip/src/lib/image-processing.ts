/**
 * Image Processing Utilities for Thermal Printing
 */

export type DitheringType = 'none' | 'floyd-steinberg' | 'atkinson' | 'stucki' | 'bayer' | 'threshold' | 'dot-matrix' | 'sierra' | 'jarvis-judice-ninke' | 'fast-print';

export function processImage(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  dithering: DitheringType
): Uint8Array {
  // Safety check for zero dimensions
  if (width <= 0 || height <= 0) {
    return new Uint8Array(0);
  }

  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  // Convert to grayscale first
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    data[i] = data[i + 1] = data[i + 2] = gray;
  }

  if (dithering === 'floyd-steinberg') {
    applyFloydSteinberg(data, width, height);
  } else if (dithering === 'atkinson') {
    applyAtkinson(data, width, height);
  } else if (dithering === 'stucki') {
    applyStucki(data, width, height);
  } else if (dithering === 'bayer') {
    applyBayer(data, width, height);
  } else if (dithering === 'sierra') {
    applySierra(data, width, height);
  } else if (dithering === 'jarvis-judice-ninke') {
    applyJJN(data, width, height);
  } else if (dithering === 'fast-print') {
    // Fast print optimization: lower resolution / simple skip
    applyFastPrint(data, width, height);
  } else {
    // Simple threshold
    for (let i = 0; i < data.length; i += 4) {
      const val = data[i] > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = val;
    }
  }

  // Convert to 1-bit bitmap (8 pixels per byte)
  // Most Chinese thermal printers (Luck Jingle, Phomemo) expect LSB-first bit packing
  const bitmap = new Uint8Array(Math.ceil((width * height) / 8));
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const bit = data[idx] < 128 ? 1 : 0; // 1 is black, 0 is white for thermal
      if (bit) {
        const pixelIdx = y * width + x;
        const byteIdx = Math.floor(pixelIdx / 8);
        const bitIdx = pixelIdx % 8; // LSB first: pixel 0 is 0x01, pixel 7 is 0x80
        bitmap[byteIdx] |= (1 << bitIdx);
      }
    }
  }

  return bitmap;
}

function applyStucki(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const oldVal = data[i];
      const newVal = oldVal > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = newVal;
      const err = oldVal - newVal;

      if (x + 1 < w) distributeError(data, (y * w + (x + 1)) * 4, err * 8 / 42);
      if (x + 2 < w) distributeError(data, (y * w + (x + 2)) * 4, err * 4 / 42);
      
      if (y + 1 < h) {
        if (x > 1) distributeError(data, ((y + 1) * w + (x - 2)) * 4, err * 2 / 42);
        if (x > 0) distributeError(data, ((y + 1) * w + (x - 1)) * 4, err * 4 / 42);
        distributeError(data, ((y + 1) * w + x) * 4, err * 8 / 42);
        if (x + 1 < w) distributeError(data, ((y + 1) * w + (x + 1)) * 4, err * 4 / 42);
        if (x + 2 < w) distributeError(data, ((y + 1) * w + (x + 2)) * 4, err * 2 / 42);
      }
      
      if (y + 2 < h) {
        if (x > 1) distributeError(data, ((y + 2) * w + (x - 2)) * 4, err * 1 / 42);
        if (x > 0) distributeError(data, ((y + 2) * w + (x - 1)) * 4, err * 2 / 42);
        distributeError(data, ((y + 2) * w + x) * 4, err * 4 / 42);
        if (x + 1 < w) distributeError(data, ((y + 2) * w + (x + 1)) * 4, err * 2 / 42);
        if (x + 2 < w) distributeError(data, ((y + 2) * w + (x + 2)) * 4, err * 1 / 42);
      }
    }
  }
}

function applyBayer(data: Uint8ClampedArray, w: number, h: number) {
  const bayerThresholdMap = [
    [  15, 135,  45, 165 ],
    [ 195,  75, 225, 105 ],
    [  60, 180,  30, 150 ],
    [ 240, 120, 210,  90 ]
  ];

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const threshold = bayerThresholdMap[y % 4][x % 4];
      const val = data[i] > threshold ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = val;
    }
  }
}

function applyFloydSteinberg(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const oldVal = data[i];
      const newVal = oldVal > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = newVal;
      const err = oldVal - newVal;

      if (x + 1 < w) distributeError(data, (y * w + (x + 1)) * 4, err * 7 / 16);
      if (y + 1 < h) {
        if (x > 0) distributeError(data, ((y + 1) * w + (x - 1)) * 4, err * 3 / 16);
        distributeError(data, ((y + 1) * w + x) * 4, err * 5 / 16);
        if (x + 1 < w) distributeError(data, ((y + 1) * w + (x + 1)) * 4, err * 1 / 16);
      }
    }
  }
}

function applyAtkinson(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const oldVal = data[i];
      const newVal = oldVal > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = newVal;
      const err = (oldVal - newVal) / 8;

      if (x + 1 < w) distributeError(data, (y * w + (x + 1)) * 4, err);
      if (x + 2 < w) distributeError(data, (y * w + (x + 2)) * 4, err);
      if (y + 1 < h) {
        if (x > 0) distributeError(data, ((y + 1) * w + (x - 1)) * 4, err);
        distributeError(data, ((y + 1) * w + x) * 4, err);
        if (x + 1 < w) distributeError(data, ((y + 1) * w + (x + 1)) * 4, err);
      }
      if (y + 2 < h) {
        distributeError(data, ((y + 2) * w + x) * 4, err);
      }
    }
  }
}

function applyDotMatrix(data: Uint8ClampedArray, w: number, h: number) {
  // Simple pattern-based dithering for a "dot-matrix" look
  const matrix = [
    [0, 128],
    [192, 64]
  ];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const threshold = matrix[y % 2][x % 2];
      const val = data[i] > threshold ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = val;
    }
  }
}

function applySierra(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const oldVal = data[i];
      const newVal = oldVal > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = newVal;
      const err = oldVal - newVal;

      if (x + 1 < w) distributeError(data, (y * w + (x + 1)) * 4, err * 5 / 32);
      if (x + 2 < w) distributeError(data, (y * w + (x + 2)) * 4, err * 3 / 32);
      if (y + 1 < h) {
        if (x > 1) distributeError(data, ((y + 1) * w + (x - 2)) * 4, err * 2 / 32);
        if (x > 0) distributeError(data, ((y + 1) * w + (x - 1)) * 4, err * 4 / 32);
        distributeError(data, ((y + 1) * w + x) * 4, err * 5 / 32);
        if (x + 1 < w) distributeError(data, ((y + 1) * w + (x + 1)) * 4, err * 4 / 32);
        if (x + 2 < w) distributeError(data, ((y + 1) * w + (x + 2)) * 4, err * 2 / 32);
      }
      if (y + 2 < h) {
        if (x > 0) distributeError(data, ((y + 2) * w + (x - 1)) * 4, err * 2 / 32);
        distributeError(data, ((y + 2) * w + x) * 4, err * 3 / 32);
        if (x + 1 < w) distributeError(data, ((y + 2) * w + (x + 1)) * 4, err * 2 / 32);
      }
    }
  }
}

function applyJJN(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const oldVal = data[i];
      const newVal = oldVal > 128 ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = newVal;
      const err = oldVal - newVal;

      if (x + 1 < w) distributeError(data, (y * w + (x + 1)) * 4, err * 7 / 48);
      if (x + 2 < w) distributeError(data, (y * w + (x + 2)) * 4, err * 5 / 48);
      
      if (y + 1 < h) {
        for (let dx = -2; dx <= 2; dx++) {
          if (x + dx >= 0 && x + dx < w) {
            const weights = [3, 5, 7, 5, 3];
            distributeError(data, ((y + 1) * w + (x + dx)) * 4, err * weights[dx + 2] / 48);
          }
        }
      }
      if (y + 2 < h) {
        for (let dx = -2; dx <= 2; dx++) {
          if (x + dx >= 0 && x + dx < w) {
            const weights = [1, 3, 5, 3, 1];
            distributeError(data, ((y + 2) * w + (x + dx)) * 4, err * weights[dx + 2] / 48);
          }
        }
      }
    }
  }
}

function applyFastPrint(data: Uint8ClampedArray, w: number, h: number) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      // Ultra fast: ignore even lines or use high contrast threshold
      if (y % 2 === 0) {
        data[i] = data[i + 1] = data[i + 2] = data[i] > 100 ? 255 : 0;
      } else {
        data[i] = data[i + 1] = data[i + 2] = 255; // Skip every other line
      }
    }
  }
}

function distributeError(data: Uint8ClampedArray, i: number, err: number) {
  data[i] = Math.min(255, Math.max(0, data[i] + err));
  data[i + 1] = data[i];
  data[i + 2] = data[i];
}
