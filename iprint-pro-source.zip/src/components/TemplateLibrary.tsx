import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { FileText, Tag, ListChecks, QrCode, CreditCard, ShoppingCart } from 'lucide-react';

const templates = [
  { id: 'todo', name: 'Yapılacaklar Listesi', icon: ListChecks, type: 'editor', content: '# YAPILACAKLAR\n- [ ] \n- [ ] \n- [ ] ' },
  { id: 'label', name: 'Adres Etiketi', icon: Tag, type: 'editor', content: 'ALICI:\nADRES:\n\nTEL:' },
  { id: 'business', name: 'Kartvizit QR', icon: CreditCard, type: 'tools', content: 'İSİM SOYİSİM\nÜNVAN\nTEL' },
  { id: 'shopping', name: 'Alışveriş Listesi', icon: ShoppingCart, type: 'editor', content: '🛒 MARKET LİSTESİ\n- ' },
];

export const TemplateLibrary = ({ onSelect }: { onSelect: (template: any) => void }) => {
  return (
    <div className="space-y-4">
      <h3 className="text-xs font-black uppercase text-slate-500 tracking-widest px-2">Profesyonel Şablonlar</h3>
      <div className="grid grid-cols-2 gap-2">
        {templates.map((t) => (
          <Card 
            key={t.id} 
            className="p-4 flex flex-col items-center gap-2 cursor-pointer hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-all border-slate-100 dark:border-slate-800"
            onClick={() => onSelect(t)}
          >
            <div className="p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm">
              <t.icon size={24} className="text-teal-600 dark:text-teal-400" />
            </div>
            <span className="text-[10px] font-bold text-center dark:text-slate-200">{t.name}</span>
          </Card>
        ))}
      </div>
    </div>
  );
};
