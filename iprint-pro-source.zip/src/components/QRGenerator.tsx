import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import bwipjs from 'bwip-js';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { logger } from '../lib/logger';
import { QrCode, Barcode, Download, Copy, RefreshCw } from 'lucide-react';

export const QRGenerator = ({ onGenerate }: { onGenerate: (img: string) => void }) => {
  const [type, setType] = useState<'qr' | 'barcode'>('qr');
  const [value, setValue] = useState('https://iprint.pro');
  const [barcodeType, setBarcodeType] = useState('code128');
  const barcodeRef = useRef<HTMLCanvasElement>(null);

  const generate = () => {
    if (type === 'qr') {
      const svg = document.getElementById('qr-gen-svg');
      if (svg) {
        const svgData = new XMLSerializer().serializeToString(svg);
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        img.onload = () => {
          canvas.width = img.width * 2;
          canvas.height = img.height * 2;
          ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
          onGenerate(canvas.toDataURL('image/png'));
        };
        img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
      }
    } else {
      try {
        const canvas = bwipjs.toCanvas(barcodeRef.current!, {
          bcid: barcodeType,
          text: value,
          scale: 3,
          height: 10,
          includetext: true,
          textxalign: 'center',
        });
        onGenerate(canvas.toDataURL('image/png'));
      } catch (e) {
        logger.error('Barcode generation failed', e);
      }
    }
  };

  useEffect(() => {
    if (type === 'barcode' && value) {
      generate();
    }
  }, [value, barcodeType, type]);

  return (
    <Card className="p-4 space-y-4 dark:bg-slate-900 border-slate-800">
      <div className="flex gap-2">
        <Button 
          variant={type === 'qr' ? 'default' : 'outline'} 
          onClick={() => setType('qr')}
          className="flex-1 gap-2"
        >
          <QrCode size={16}/> QR
        </Button>
        <Button 
          variant={type === 'barcode' ? 'default' : 'outline'} 
          onClick={() => setType('barcode')}
          className="flex-1 gap-2"
        >
          <Barcode size={16}/> Barkod
        </Button>
      </div>

      <div className="space-y-2">
        <Label className="text-xs uppercase font-bold text-slate-500">İçerik</Label>
        <Input 
          value={value} 
          onChange={(e) => setValue(e.target.value)}
          placeholder="Metin veya URL girin..."
          className="dark:bg-slate-800 border-none"
        />
      </div>

      {type === 'barcode' && (
        <div className="space-y-2">
          <Label className="text-xs uppercase font-bold text-slate-500">Barkod Tipi</Label>
          <Select value={barcodeType} onValueChange={(v) => v && setBarcodeType(v)}>
            <SelectTrigger className="dark:bg-slate-800 border-none">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="code128">Code 128</SelectItem>
              <SelectItem value="ean13">EAN-13</SelectItem>
              <SelectItem value="upca">UPC-A</SelectItem>
              <SelectItem value="qrcode">QR Code</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="flex justify-center p-4 bg-white rounded-xl">
        {type === 'qr' ? (
          <QRCodeSVG 
            id="qr-gen-svg"
            value={value} 
            size={128}
            level="H"
            includeMargin={true}
          />
        ) : (
          <canvas ref={barcodeRef} />
        )}
      </div>

      <Button onClick={generate} className="w-full gap-2 bg-teal-600 hover:bg-teal-700">
        <RefreshCw size={16}/> Şablona Ekle
      </Button>
    </Card>
  );
};
