import React, { useState } from 'react';
import { PrinterService } from '../lib/printer';
import { Bug, Send, Zap, Activity, RefreshCw, Battery, ChevronDown, Minus, Plus, Settings2, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { logger } from '../lib/logger';

interface DiagnosticsPanelProps {
  printer: PrinterService;
  isConnected: boolean;
  onSwitchChannel: () => void;
  feedAmount: number;
  setFeedAmount: (val: number) => void;
  onAdvancePaper: (amount: number) => void;
  isExtraDark: boolean;
  setIsExtraDark: (val: boolean) => void;
  onTestDarkness: () => void;
}

export function DiagnosticsPanel({ 
  printer, 
  isConnected, 
  onSwitchChannel, 
  feedAmount, 
  setFeedAmount, 
  onAdvancePaper,
  isExtraDark,
  setIsExtraDark,
  onTestDarkness
}: DiagnosticsPanelProps) {
  const [rawHex, setRawHex] = useState('');

  const handleProbe = async (type: 'LUCK_JINGLE' | 'PHOMEMO' | 'STANDARD') => {
    if (!isConnected) {
      logger.warn('Connect to printer first!');
      return;
    }
    await printer.probeProtocol(type);
  };

  const handleSendRaw = async () => {
    if (!isConnected || !rawHex) return;
    await printer.sendRawHex(rawHex.replace(/\s/g, ''));
  };

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6">
      <div className="flex items-center gap-2 mb-2">
        <Bug className="text-purple-600" size={20} />
        <h2 className="text-lg font-bold text-slate-800">Gelişmiş Tanılama Araçları</h2>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-4">
          <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100 space-y-3">
            <div className="flex items-center justify-between">
               <p className="text-xs font-black text-purple-800 uppercase tracking-widest flex items-center gap-1.5"><Activity size={14}/> Kağıt Sür</p>
               <span className="text-[10px] font-bold bg-white text-purple-600 px-2 py-0.5 rounded-md border border-purple-100">{feedAmount} Nokta</span>
            </div>
            <div className="flex gap-2">
              <div className="flex-1 flex items-center bg-white rounded-xl border border-purple-200 overflow-hidden px-2 h-10">
                <Button variant="ghost" size="icon" className="h-7 w-7 text-purple-400" onClick={() => setFeedAmount(Math.max(1, feedAmount - 10))}><Minus size={14}/></Button>
                <input title="Kağıt Sürme Miktarı" aria-label="Kağıt Sürme Nokta Sayısı" type="number" value={feedAmount} onChange={e => setFeedAmount(Number(e.target.value)||50)} className="flex-1 w-0 text-center text-xs font-black bg-transparent border-none focus:outline-none" />
                <Button variant="ghost" size="icon" className="h-7 w-7 text-purple-400" onClick={() => setFeedAmount(feedAmount + 10)}><Plus size={14}/></Button>
              </div>
              <Button onClick={() => onAdvancePaper(feedAmount)} className="bg-purple-600 hover:bg-purple-700 rounded-xl h-10 shadow-lg shadow-purple-100 flex-1 font-bold text-xs gap-1.5 transition-transform active:scale-95">
                <Send size={14}/> Sür
              </Button>
            </div>
          </div>

          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">iPrint (GB03) Özel Komutlar</p>
          <div className="grid grid-cols-2 gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={async () => {
                if (!isConnected) return;
                logger.info('iPrint: Pil Durumu Sorgulanıyor...');
                await printer.sendData(PrinterService.createLuckJinglePacket(0xA3, 0x00));
              }}
              className="text-[10px] h-9 border-purple-100 hover:bg-purple-50 font-bold"
            >
              <Battery size={14} className="mr-1 text-purple-500" /> Pil Durumu
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onTestDarkness}
              className={`text-[10px] h-9 border-orange-100 font-bold transition-all ${isExtraDark ? 'bg-orange-600 text-white border-orange-500' : 'hover:bg-orange-50 text-slate-700'}`}
            >
              <Zap size={14} className={`mr-1 ${isExtraDark ? 'text-white' : 'text-orange-500'}`} /> {isExtraDark ? 'Ekstra Koyu AKTİF' : 'Ekstra Koyu TEST'}
            </Button>
            <div className="flex items-center justify-between bg-white px-2 rounded-xl border border-orange-100">
               <Label className="text-[9px] font-black text-orange-600 uppercase">Koyu Mod</Label>
               <input 
                 type="checkbox" 
                 checked={isExtraDark} 
                 onChange={(e) => setIsExtraDark(e.target.checked)}
                 className="w-4 h-4 accent-orange-600"
               />
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={async () => {
                 if (!isConnected) return;
                 await printer.testPrint();
              }}
              className="text-[10px] h-9 border-teal-100 hover:bg-teal-50 font-bold"
            >
              <Activity size={14} className="mr-1 text-teal-500" /> Kendi Sınama
            </Button>
            <Button 
               variant="outline" 
               size="sm" 
               onClick={onSwitchChannel}
               className="text-[10px] h-8 border-slate-100 hover:bg-slate-50 font-bold"
             >
               <RefreshCw size={12} className="mr-1 text-slate-400" /> Kanal Değiştir
             </Button>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Diğer Protokol Taramaları</p>
          <div className="grid grid-cols-2 gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleProbe('PHOMEMO')}
              className="text-[10px] h-8 border-blue-100 hover:bg-blue-50"
            >
              Phomemo/Peripage
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleProbe('STANDARD')}
              className="text-[10px] h-8 border-green-100 hover:bg-green-50"
            >
              Standart ESC/POS
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ham Komut Gönder (HEX)</p>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={rawHex}
              onChange={(e) => setRawHex(e.target.value)}
              placeholder="Örn: 1B 40 0A"
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <Button size="sm" onClick={handleSendRaw} className="bg-purple-600 hover:bg-purple-700">
              <Send size={14} />
            </Button>
          </div>
          <p className="text-[9px] text-slate-400">
            * Boşluklu veya bitişik hex kodları girebilirsiniz.
          </p>
        </div>

        <div className="p-3 bg-amber-50 rounded-2xl border border-amber-100">
          <div className="flex gap-2">
            <Activity size={14} className="text-amber-600 shrink-0 mt-0.5" />
            <p className="text-[10px] text-amber-800 leading-relaxed">
              <strong>İpucu:</strong> GB03 modelleri genellikle <strong>Luck Jingle</strong> protokolünü kullanır. Eğer tepki alamazsanız önce kanalı değiştirip sonra tekrar Luck Jingle butonuna basmayı deneyin.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
