import React, { useEffect, useRef, useState, useCallback } from 'react';
import { fabric } from 'fabric';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ScrollArea } from './ui/scroll-area';
import {
  Type,
  Image as ImageIcon,
  FileText,
  Trash2,
  PrinterCheck,
  Bold,
  Italic,
  Underline,
  RotateCw,
  Lock,
  Unlock,
  Plus,
  Minus,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Layers,
  ArrowUp,
  ArrowDown,
  X,
  Eye,
  EyeOff,
  Copy,
  FlipHorizontal,
  Move,
} from 'lucide-react';
import * as pdfjs from 'pdfjs-dist';
import { removeBackground } from '../lib/background-removal';
import { Sparkles, Loader2, Check } from 'lucide-react';

pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

interface CollageEditorProps {
  pageWidth: number;
  onPreview: (dataUrl: string) => void;
}

interface LayerItem {
  id: string;
  name: string;
  type: 'text' | 'image' | 'pdf';
  visible: boolean;
  locked: boolean;
  fabricObj: fabric.Object;
}

const FONT_LIST = ['Outfit', 'Arial', 'Times New Roman', 'Courier New', 'Georgia', 'Verdana', 'Impact'];

export const CollageEditor: React.FC<CollageEditorProps> = ({ pageWidth, onPreview }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [canvas, setCanvas] = useState<fabric.Canvas | null>(null);
  const [canvasHeight, setCanvasHeight] = useState(600);
  const [layers, setLayers] = useState<LayerItem[]>([]);
  const [selectedLayer, setSelectedLayer] = useState<LayerItem | null>(null);
  const [activeTab, setActiveTab] = useState<'layers' | 'props'>('layers');
  const [isRemovingBg, setIsRemovingBg] = useState(false);

  // Text properties panel
  const [textValue, setTextValue] = useState('');
  const [textSize, setTextSize] = useState(32);
  const [textFont, setTextFont] = useState('Outfit');
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'right'>('center');
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);

  // Object size controls
  const [objW, setObjW] = useState(0);
  const [objH, setObjH] = useState(0);
  const [objX, setObjX] = useState(0);
  const [objY, setObjY] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [keepAspect, setKeepAspect] = useState(true);

  const layerCountRef = useRef(0);

  useEffect(() => {
    if (!canvasRef.current) return;
    const fc = new fabric.Canvas(canvasRef.current, {
      width: pageWidth,
      height: canvasHeight,
      backgroundColor: '#ffffff',
      preserveObjectStacking: true,
      selection: true,
    });

    fc.on('selection:created', (e) => updateSelectedLayer(fc, e.selected?.[0]));
    fc.on('selection:updated', (e) => updateSelectedLayer(fc, e.selected?.[0]));
    fc.on('selection:cleared', () => { setSelectedLayer(null); });
    fc.on('object:modified', (e) => syncObjProps(e.target));

    setCanvas(fc);
    return () => { fc.dispose(); };
  }, []);

  useEffect(() => {
    if (canvas) {
      canvas.setWidth(pageWidth);
      canvas.setHeight(canvasHeight);
      canvas.renderAll();
    }
  }, [pageWidth, canvasHeight, canvas]);

  const updateSelectedLayer = (fc: fabric.Canvas, obj?: fabric.Object) => {
    if (!obj) { setSelectedLayer(null); return; }
    const found = layers.find(l => l.fabricObj === obj);
    if (found) {
      setSelectedLayer(found);
      setActiveTab('props');
      syncObjProps(obj);
      if (obj.type === 'i-text') {
        const t = obj as fabric.IText;
        setTextValue(t.text || '');
        setTextSize(t.fontSize || 32);
        setTextFont(t.fontFamily || 'Outfit');
        setTextAlign((t.textAlign as any) || 'center');
        setIsBold(t.fontWeight === 'bold');
        setIsItalic(t.fontStyle === 'italic');
        setIsUnderline(t.underline || false);
      }
    }
  };

  const syncObjProps = (obj?: fabric.Object) => {
    if (!obj) return;
    setObjW(Math.round(obj.getScaledWidth()));
    setObjH(Math.round(obj.getScaledHeight()));
    setObjX(Math.round(obj.left || 0));
    setObjY(Math.round(obj.top || 0));
    setIsLocked(!!(obj as any).lockMovementX);
  };

  const addLayer = (fabricObj: fabric.Object, name: string, type: 'text' | 'image' | 'pdf') => {
    if (!canvas) return;
    layerCountRef.current++;
    const layer: LayerItem = {
      id: `${type}-${layerCountRef.current}`,
      name: `${name} ${layerCountRef.current}`,
      type,
      visible: true,
      locked: false,
      fabricObj,
    };
    canvas.add(fabricObj);
    canvas.setActiveObject(fabricObj);
    canvas.renderAll();
    setLayers(prev => [...prev, layer]);
    setSelectedLayer(layer);
    setActiveTab('props');
  };

  const addText = () => {
    const t = new fabric.IText('Yeni Metin', {
      left: 20, top: 40,
      fontFamily: 'Outfit',
      fill: '#000000',
      fontSize: 32,
      textAlign: 'center',
      width: pageWidth - 40,
    });
    addLayer(t, 'Metin', 'text');
  };

  const addImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !canvas) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      fabric.Image.fromURL(dataUrl, (img) => {
        if (img.width && img.width > pageWidth) img.scaleToWidth(pageWidth - 20);
        img.set({ left: 10, top: 10 });
        addLayer(img, 'Görsel', 'image');
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const addPdf = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !canvas) return;
    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ 
        data: arrayBuffer
      });
      const pdf = await loadingTask.promise;
      const page = await pdf.getPage(1);
      const vp = page.getViewport({ scale: 2 });
      const tmp = document.createElement('canvas');
      const ctx = tmp.getContext('2d')!;
      tmp.width = vp.width; tmp.height = vp.height;
      await (page as any).render({ canvasContext: ctx, viewport: vp }).promise;
      fabric.Image.fromURL(tmp.toDataURL(), (img) => {
        if (img.width && img.width > pageWidth) img.scaleToWidth(pageWidth - 20);
        img.set({ left: 10, top: 10 });
        addLayer(img, 'PDF', 'pdf');
      });
    } catch (err) { alert('PDF yüklenemedi: ' + err); }
    e.target.value = '';
  };

  const applyTextProp = (key: string, value: any) => {
    if (!canvas || !selectedLayer) return;
    const obj = selectedLayer.fabricObj as fabric.IText;
    if (obj.type !== 'i-text') return;
    obj.set(key as any, value);
    canvas.renderAll();
  };

  const applyObjSize = (w: number, h: number) => {
    if (!canvas || !selectedLayer) return;
    const obj = selectedLayer.fabricObj;
    const curW = obj.getScaledWidth();
    const curH = obj.getScaledHeight();
    const scaleX = (obj.scaleX || 1) * (w / curW);
    const scaleY = keepAspect ? (obj.scaleY || 1) * (w / curW) : (obj.scaleY || 1) * (h / curH);
    obj.set({ scaleX, scaleY });
    canvas.renderAll();
    syncObjProps(obj);
  };

  const applyObjPos = (x: number, y: number) => {
    if (!canvas || !selectedLayer) return;
    selectedLayer.fabricObj.set({ left: x, top: y });
    canvas.renderAll();
  };

  const deleteLayer = (layer: LayerItem) => {
    if (!canvas) return;
    canvas.remove(layer.fabricObj);
    canvas.renderAll();
    setLayers(prev => prev.filter(l => l.id !== layer.id));
    if (selectedLayer?.id === layer.id) setSelectedLayer(null);
  };

  const toggleVisibility = (layer: LayerItem) => {
    layer.fabricObj.set('visible', !layer.fabricObj.visible);
    canvas?.renderAll();
    setLayers(prev => prev.map(l => l.id === layer.id ? { ...l, visible: !l.visible } : l));
  };

  const toggleLayerLock = (layer: LayerItem) => {
    const locked = !layer.locked;
    layer.fabricObj.set({
      lockMovementX: locked, lockMovementY: locked,
      lockScalingX: locked, lockScalingY: locked,
      lockRotation: locked,
      selectable: !locked,
    });
    canvas?.renderAll();
    setLayers(prev => prev.map(l => l.id === layer.id ? { ...l, locked } : l));
    if (selectedLayer?.id === layer.id) setIsLocked(locked);
  };

  const bringForward = (layer: LayerItem) => {
    canvas?.bringForward(layer.fabricObj);
    canvas?.renderAll();
    setLayers(prev => {
      const idx = prev.findIndex(l => l.id === layer.id);
      if (idx >= prev.length - 1) return prev;
      const arr = [...prev];
      [arr[idx], arr[idx + 1]] = [arr[idx + 1], arr[idx]];
      return arr;
    });
  };

  const sendBackward = (layer: LayerItem) => {
    canvas?.sendBackwards(layer.fabricObj);
    canvas?.renderAll();
    setLayers(prev => {
      const idx = prev.findIndex(l => l.id === layer.id);
      if (idx <= 0) return prev;
      const arr = [...prev];
      [arr[idx], arr[idx - 1]] = [arr[idx - 1], arr[idx]];
      return arr;
    });
  };

  const rotateObj = (layer: LayerItem) => {
    layer.fabricObj.rotate(((layer.fabricObj.angle || 0) + 90) % 360);
    canvas?.renderAll();
  };

  const duplicateLayer = (layer: LayerItem) => {
    layer.fabricObj.clone((cloned: fabric.Object) => {
      cloned.set({ left: (layer.fabricObj.left || 0) + 20, top: (layer.fabricObj.top || 0) + 20 });
      addLayer(cloned, layer.name + ' (Kopya)', layer.type);
    });
  };

  const handlePreview = () => {
    if (!canvas) return;
    canvas.discardActiveObject();
    canvas.renderAll();
    onPreview(canvas.toDataURL({ format: 'png', quality: 1 }));
  };

  const layerTypeIcon = (type: string) => {
    if (type === 'text') return <Type size={12} />;
    if (type === 'pdf') return <FileText size={12} />;
    return <ImageIcon size={12} />;
  };

  const layerTypeBg = (type: string) => {
    if (type === 'text') return 'bg-purple-100 text-purple-600';
    if (type === 'pdf') return 'bg-red-100 text-red-600';
    return 'bg-teal-100 text-teal-600';
  };

  return (
    <div className="flex flex-col h-full -m-1 p-1">
      {/* Toolbar - compact flex layout */}
      <div className="flex items-center gap-1.5 bg-slate-900 dark:bg-black rounded-2xl p-2 shadow-xl border border-slate-700 dark:border-slate-900 overflow-hidden">
        <Button onClick={addText} size="sm" className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl whitespace-nowrap h-8 px-2 gap-1 font-bold text-[10px] flex-shrink-0">
          <Type size={12} /> Metin
        </Button>
        <div className="relative flex-shrink-0">
          <Button size="sm" className="bg-teal-600 hover:bg-teal-700 text-white rounded-xl whitespace-nowrap h-8 px-2 gap-1 font-bold text-[10px] pointer-events-none">
            <ImageIcon size={12} /> Görsel
          </Button>
          <input type="file" accept="image/*" onChange={addImage} title="Görsel Ekle" className="absolute inset-0 opacity-0 cursor-pointer" />
        </div>
        <div className="relative flex-shrink-0">
          <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white rounded-xl whitespace-nowrap h-8 px-2 gap-1 font-bold text-[10px] pointer-events-none">
            <FileText size={12} /> PDF
          </Button>
          <input type="file" accept=".pdf" onChange={addPdf} title="PDF Ekle" className="absolute inset-0 opacity-0 cursor-pointer" />
        </div>
        <div className="ml-auto flex items-center gap-1 flex-shrink-0">
          <span className="text-[8px] font-black text-slate-500 dark:text-slate-400 uppercase">Tuval</span>
          <div className="flex items-center gap-0.5 bg-slate-800 dark:bg-slate-900 p-0.5 rounded-lg border border-slate-700 dark:border-slate-800">
             <Button size="icon" variant="ghost" className="h-6 w-6 text-slate-400 hover:text-white" onClick={() => setCanvasHeight(h => Math.max(50, h - 10))}><Minus size={10} /></Button>
             <input 
                title="Tuval Yüksekliği"
                aria-label="Tuval Yüksekliği"
                type="number" 
                value={canvasHeight} 
                onChange={e => setCanvasHeight(Number(e.target.value)||100)} 
                className="w-10 h-5 bg-transparent border-none text-center text-[10px] font-black p-0 text-teal-400 focus:outline-none"
              />
             <Button size="icon" variant="ghost" className="h-6 w-6 text-slate-400 hover:text-white" onClick={() => setCanvasHeight(h => h + 10)}><Plus size={10} /></Button>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-1.5 flex-1 overflow-hidden">
        {/* Canvas - full width, no scroll */}
        <div className="w-full overflow-hidden rounded-lg">
          <div className="bg-slate-800 dark:bg-slate-950 rounded-lg p-1 shadow-lg border border-slate-700 dark:border-slate-900 overflow-hidden">
            <div className="flex justify-center overflow-hidden">
              <canvas ref={canvasRef} className="shadow-md rounded [image-rendering:pixelated] max-w-full" />
            </div>
          </div>
        </div>

        {/* Bottom Panel - compact */}
        <div className="w-full space-y-1 overflow-hidden">
          {/* Tabs */}
          <div className="flex bg-slate-100 dark:bg-slate-950 rounded-lg p-0.5 gap-0.5 border border-slate-200 dark:border-slate-800">
            <button onClick={() => setActiveTab('layers')} className={`flex-1 text-[9px] font-bold h-7 rounded-md flex items-center justify-center gap-1 transition-all ${activeTab === 'layers' ? 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}>
              <Layers size={11} /> Katmanlar
            </button>
            <button onClick={() => setActiveTab('props')} className={`flex-1 text-[9px] font-bold h-7 rounded-md flex items-center justify-center gap-1 transition-all ${activeTab === 'props' ? 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}>
              <Move size={11} /> Özellikler
            </button>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'layers' && (
              <motion.div key="layers" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
                  <ScrollArea className="h-[100px]">
                    {layers.length === 0 && (
                      <div className="flex flex-col items-center justify-center h-24 text-slate-300 dark:text-slate-700">
                        <Layers size={24} className="mb-1 opacity-50" />
                        <p className="text-[10px] font-bold uppercase opacity-70">Henüz katman yok</p>
                      </div>
                    )}
                    {[...layers].reverse().map((layer) => (
                      <div
                        key={layer.id}
                        onClick={() => { canvas?.setActiveObject(layer.fabricObj); canvas?.renderAll(); updateSelectedLayer(canvas!, layer.fabricObj); }}
                        className={`flex items-center gap-2 px-3 py-2.5 cursor-pointer border-b border-slate-50 dark:border-slate-950 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors ${selectedLayer?.id === layer.id ? 'bg-teal-50 dark:bg-teal-900/10 border-l-2 border-l-teal-400' : ''}`}
                      >
                        <div className={`p-1.5 rounded-lg flex-shrink-0 ${layerTypeBg(layer.type)}`}>
                          {layerTypeIcon(layer.type)}
                        </div>
                        <span className={`flex-1 text-[11px] font-bold truncate transition-colors ${selectedLayer?.id === layer.id ? 'text-teal-700 dark:text-teal-400' : 'text-slate-700 dark:text-slate-300'}`}>{layer.name}</span>
                        <div className="flex gap-1 flex-shrink-0">
                          <button onClick={(e) => { e.stopPropagation(); toggleVisibility(layer); }} className="p-1 px-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                            {layer.visible ? <Eye size={12} className="text-slate-400 dark:text-slate-500" /> : <EyeOff size={12} className="text-slate-300 dark:text-slate-600" />}
                          </button>
                          <button onClick={(e) => { e.stopPropagation(); toggleLayerLock(layer); }} className="p-1 px-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                            {layer.locked ? <Lock size={12} className="text-amber-500" /> : <Unlock size={12} className="text-slate-400 dark:text-slate-500" />}
                          </button>
                          <button title="Katmanı Sil" onClick={(e) => { e.stopPropagation(); deleteLayer(layer); }} className="p-1 px-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/20 transition-colors">
                            <Trash2 size={12} className="text-red-400 dark:text-red-600" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </ScrollArea>
                </div>

                {selectedLayer && (
                  <div className="mt-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-3 space-y-2">
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Katman İşlemleri</span>
                    <div className="grid grid-cols-3 gap-2">
                      <Button size="sm" variant="outline" onClick={() => bringForward(selectedLayer)} className="h-9 text-[10px] rounded-xl font-bold dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300" title="Öne Al">
                        <ArrowUp size={14} />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => sendBackward(selectedLayer)} className="h-9 text-[10px] rounded-xl font-bold dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300" title="Arkaya At">
                        <ArrowDown size={14} />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => rotateObj(selectedLayer)} className="h-9 text-[10px] rounded-xl font-bold dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300" title="Döndür">
                        <RotateCw size={14} />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => duplicateLayer(selectedLayer)} className="h-9 text-[10px] rounded-xl col-span-2 font-black gap-2 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
                        <Copy size={14} /> KOPYALA
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => deleteLayer(selectedLayer)} className="h-9 text-[10px] rounded-xl font-black gap-2">
                        <Trash2 size={14} /> SİL
                      </Button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'props' && selectedLayer && (
              <motion.div key="props" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} className="space-y-2">
                {/* Position & Size */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Konum & Boyut</span>
                    <button onClick={() => setKeepAspect(p => !p)} className={`text-[9px] font-black px-2 py-0.5 rounded-lg transition-all ${keepAspect ? 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-600'}`}>
                       {keepAspect ? 'ORAN KİLİTLİ' : 'ORAN SERBEST'}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'X (px)', val: objX, set: (v: number) => { setObjX(v); applyObjPos(v, objY); } },
                      { label: 'Y (px)', val: objY, set: (v: number) => { setObjY(v); applyObjPos(objX, v); } },
                      { label: 'En (px)', val: objW, set: (v: number) => { setObjW(v); applyObjSize(v, objH); } },
                      { label: 'Boy (px)', val: objH, set: (v: number) => { setObjH(v); applyObjSize(objW, v); } },
                    ].map(({ label, val, set }) => (
                      <div key={label} className="space-y-1">
                        <Label className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase">{label}</Label>
                        <div className="flex items-center bg-slate-50 dark:bg-slate-950 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
                          <button title="Azalt" onClick={() => set(val - 1)} className="px-2 py-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"><Minus size={12} /></button>
                          <input title={label} aria-label={label} type="number" value={val} onChange={e => set(Number(e.target.value))} className="flex-1 w-0 text-center text-[11px] font-black bg-transparent border-none focus:outline-none dark:text-white" />
                          <button title="Artır" onClick={() => set(val + 1)} className="px-2 py-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"><Plus size={12} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="text-[9px] text-slate-400 dark:text-slate-500 font-black text-center border-t border-slate-50 dark:border-slate-850 pt-2 tracking-widest">
                    {(objW / 3.78).toFixed(1)}MM × {(objH / 3.78).toFixed(1)}MM
                  </div>
                </div>

                {/* Text props */}
                {selectedLayer.type === 'text' && (
                  <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-3 space-y-3">
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Metin Özellikleri</span>
                    <textarea
                      title="Metin İçeriği"
                      aria-label="Metin Katmanı İçeriği"
                      value={textValue}
                      onChange={(e) => { setTextValue(e.target.value); applyTextProp('text', e.target.value); }}
                      className="w-full text-xs border border-slate-200 dark:border-slate-800 rounded-xl p-2.5 resize-none focus:ring-1 focus:ring-purple-400 focus:border-purple-400 bg-slate-50 dark:bg-slate-950 dark:text-white font-medium"
                      rows={3}
                    />
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase">Font Boyutu</Label>
                          <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 p-1 mt-1">
                            <button title="Azalt" onClick={() => { const v = Math.max(8, textSize - 1); setTextSize(v); applyTextProp('fontSize', v); }} className="px-2 py-1 text-slate-500 hover:text-slate-800 dark:hover:text-white"><Minus size={12} /></button>
                            <input title="Font Boyutu" aria-label="Font Boyutu" type="number" value={textSize} onChange={e => { const v = Number(e.target.value) || 32; setTextSize(v); applyTextProp('fontSize', v); }} className="flex-1 text-center text-xs font-black bg-transparent border-none focus:outline-none dark:text-white" />
                            <button title="Artır" onClick={() => { const v = textSize + 1; setTextSize(v); applyTextProp('fontSize', v); }} className="px-2 py-1 text-slate-500 hover:text-slate-800 dark:hover:text-white"><Plus size={12} /></button>
                          </div>
                        </div>
                        <div>
                          <Label className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase">Font Ailesi</Label>
                          <Select value={textFont} onValueChange={(v) => { v && setTextFont(v); v && applyTextProp('fontFamily', v); }}>
                            <SelectTrigger className="h-9 text-xs font-bold rounded-xl mt-1 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 dark:text-slate-200"><SelectValue /></SelectTrigger>
                            <SelectContent className="dark:bg-slate-900 dark:border-slate-800">{FONT_LIST.map(f => <SelectItem key={f} value={f} className="text-xs font-medium dark:text-slate-200">{f}</SelectItem>)}</SelectContent>
                          </Select>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-1.5 pt-1">
                      {[
                        { icon: <Bold size={14} />, label: 'Kalın', active: isBold, action: () => { const v = !isBold; setIsBold(v); applyTextProp('fontWeight', v ? 'bold' : 'normal'); } },
                        { icon: <Italic size={14} />, label: 'İtalik', active: isItalic, action: () => { const v = !isItalic; setIsItalic(v); applyTextProp('fontStyle', v ? 'italic' : 'normal'); } },
                        { icon: <Underline size={14} />, label: 'Altı Çizili', active: isUnderline, action: () => { const v = !isUnderline; setIsUnderline(v); applyTextProp('underline', v); } },
                      ].map(({ icon, label, active, action }) => (
                        <button key={label} onClick={action} title={label} className={`h-10 rounded-xl flex items-center justify-center transition-all ${active ? 'bg-purple-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-750'}`}>
                          {icon}
                        </button>
                      ))}
                    </div>
                    <div className="flex bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-1 rounded-xl">
                      {(['left', 'center', 'right'] as const).map((align) => (
                        <button key={align} onClick={() => { setTextAlign(align); applyTextProp('textAlign', align); }} className={`flex-1 h-9 rounded-lg flex items-center justify-center transition-all ${textAlign === align ? 'bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-sm' : 'text-slate-400 hover:bg-white/50 dark:hover:bg-slate-800/50'}`}>
                          {align === 'left' ? <AlignLeft size={16} /> : align === 'center' ? <AlignCenter size={16} /> : <AlignRight size={16} />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Background removal for images */}
                {selectedLayer.type === 'image' && (
                  <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-4 space-y-3">
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest leading-none">Akıllı Görsel İşleme</span>
                    <Button 
                      onClick={async () => {
                        const img = selectedLayer.fabricObj as fabric.Image;
                        const src = img.getSrc();
                        setIsRemovingBg(true);
                        try {
                          const res = await removeBackground(src);
                          img.setSrc(res, () => {
                             canvas?.renderAll();
                             setIsRemovingBg(false);
                          });
                        } catch(e) { setIsRemovingBg(false); }
                      }} 
                      disabled={isRemovingBg}
                      className="w-full h-12 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-700 hover:to-indigo-600 font-black text-xs gap-3 shadow-xl shadow-indigo-100 dark:shadow-none transition-all active:scale-95"
                    >
                      {isRemovingBg ? <Loader2 size={18} className="animate-spin"/> : <Sparkles size={18} className="fill-white"/>}
                      {isRemovingBg ? 'YAPAY ZEKA TEMİZLİYOR...' : 'ARKAPLANI SİL'}
                    </Button>
                    <p className="text-[9px] text-slate-400 dark:text-slate-500 text-center font-bold tracking-tight italic">AI teknolojisi ile sadece nesneyi bırakır</p>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'props' && !selectedLayer && (
              <motion.div key="noprops" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-8 text-center border-dashed">
                <div className="bg-slate-50 dark:bg-slate-950 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-slate-100 dark:border-slate-800">
                  <Move size={32} className="text-slate-200 dark:text-slate-800" />
                </div>
                <p className="text-xs text-slate-400 dark:text-slate-600 font-black uppercase tracking-widest leading-loose">Düzenlemek için<br/>bir katman seçin</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Print Button - compact */}
      <Button onClick={handlePreview} className="w-full bg-slate-900 dark:bg-teal-600 hover:bg-black dark:hover:bg-teal-700 text-white rounded-xl h-10 text-xs font-black shadow-lg transition-all active:scale-95 gap-2 mt-1">
        <PrinterCheck size={16} /> ÖNİZLE & YAZDIR
      </Button>
    </div>
  );
};
