import React, { useState, useEffect, useRef } from 'react';
import { 
  Printer, 
  Bluetooth, 
  BluetoothOff, 
  Languages, 
  FileText, 
  Type, 
  Image as ImageIcon, 
  Tag, 
  Globe, 
  Settings2, 
  X, 
  Plus, 
  Minus, 
  Smartphone, 
  Contrast, 
  Layout, 
  Bug, 
  Monitor, 
  Battery, 
  Share2, 
  RotateCw, 
  ZoomIn, 
  ZoomOut, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify,
  Bold,
  Italic,
  Underline,
  Contrast as ContrastIcon,
  Layers,
  PrinterCheck,
  Zap,
  Maximize2,
  Lock,
  Unlock,
  Move,
  Trash2,
  ChevronUp,
  ChevronDown,
  Check,
  Terminal,
  Code,
  Eye,
  FileCode
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Switch } from './components/ui/switch';
import { Slider } from './components/ui/slider';
import { Progress } from './components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { ScrollArea } from './components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './components/ui/dialog';
import { useTranslation } from 'react-i18next';
import './i18n';
import { PrinterService } from './lib/printer';
import { processImage, DitheringType } from './lib/image-processing';
import { logger } from './lib/logger';
import * as pdfjs from 'pdfjs-dist';
import { fabric } from 'fabric';
import Cropper from 'react-easy-crop';
import { DebugConsole } from './components/DebugConsole';
import { DiagnosticsPanel } from './components/DiagnosticsPanel';
import { CollageEditor } from './components/CollageEditor';
import { QRGenerator } from './components/QRGenerator';
import { TemplateLibrary } from './components/TemplateLibrary';
import { removeBackground } from './lib/background-removal';
import { performOCR } from './lib/ocr';
import { Sparkles, Loader2, Save, Languages as OcrIcon, QrCode, Library } from 'lucide-react';

// Use a stable CDN for worker to bypass Vite/ESBuild strict mjs module issues natively
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@5.6.205/build/pdf.worker.min.mjs`;

const printer = new PrinterService();

const ArchitectWorkspace = React.memo(({ image, crops, onSync, parentFabricRef }: { image: string, crops: any[], onSync: (updated: any[]) => void, parentFabricRef: React.MutableRefObject<fabric.Canvas | null> }) => {
  const parentRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const localFabricRef = useRef<fabric.Canvas | null>(null);

  useEffect(() => {
    if (!image || !parentRef.current) return;
    
    // Cleanup previous if it exists manually to be safe
    parentRef.current.innerHTML = '';
    const canvasEl = document.createElement('canvas');
    parentRef.current.appendChild(canvasEl);
    
    // Precision dimension detection
    const w = parentRef.current.clientWidth || 350;
    const h = parentRef.current.clientHeight || 420;

    const fc = new fabric.Canvas(canvasEl, {
      width: w,
      height: h,
      backgroundColor: '#ffffff',
      preserveObjectStacking: true
    });
    
    localFabricRef.current = fc;
    if (parentFabricRef) parentFabricRef.current = fc;

    let isDisposed = false;

    // Load image with absolute reliability
    const imgObj = new Image();
    imgObj.onload = () => {
      if (isDisposed || !fc) return;
      
      const fabricImg = new fabric.Image(imgObj);
      const scale = Math.min(fc.width! / imgObj.width, fc.height! / imgObj.height) * 0.95;
      
      fabricImg.scale(scale);
      fabricImg.set({
        left: (fc.width! - (imgObj.width * scale)) / 2,
        top: (fc.height! - (imgObj.height * scale)) / 2,
        selectable: false,
        hoverCursor: 'default',
        evented: false
      });
      
      fc.add(fabricImg);
      fc.sendToBack(fabricImg);

      // Re-add crops if any exist already
      crops.forEach((zone) => {
        if (!zone.percent) return;
        const rect = new fabric.Rect({
          left: fabricImg.left! + (zone.percent.x * fabricImg.getScaledWidth()) / 100,
          top: fabricImg.top! + (zone.percent.y * fabricImg.getScaledHeight()) / 100,
          width: (zone.percent.width * fabricImg.getScaledWidth()) / 100,
          height: (zone.percent.height * fabricImg.getScaledHeight()) / 100,
          angle: zone.rotation || 0,
          fill: 'rgba(16,185,129,0.2)',
          stroke: '#10b981',
          strokeWidth: 2,
          cornerColor: '#10b981',
          cornerSize: 8,
          transparentCorners: false,
          data: { id: zone.id }
        });
        fc.add(rect);
      });
      fc.renderAll();
    };
    imgObj.src = image;

    const syncHandler = () => {
      const bgImg = fc.getObjects('image')[0] as fabric.Image;
      if (!bgImg) return;
      const updated = fc.getObjects('rect').map(r => {
        const rect = r as fabric.Rect;
        return {
          id: (rect as any).data?.id,
          rotation: rect.angle,
          percent: {
            x: ((rect.left! - bgImg.left!) / bgImg.getScaledWidth()) * 100,
            y: ((rect.top! - bgImg.top!) / bgImg.getScaledHeight()) * 100,
            width: (rect.getScaledWidth() / bgImg.getScaledWidth()) * 100,
            height: (rect.getScaledHeight() / bgImg.getScaledHeight()) * 100
          },
          width: rect.getScaledWidth(), height: rect.getScaledHeight(),
          x: rect.left! - bgImg.left!, y: rect.top! - bgImg.top!
        };
      });
      onSync(updated);
    };

    fc.on('object:modified', syncHandler);
    fc.on('object:added', syncHandler);
    fc.on('object:removed', syncHandler);

    return () => {
      isDisposed = true;
      fc.dispose();
      localFabricRef.current = null;
      if (parentFabricRef && parentFabricRef.current === fc) parentFabricRef.current = null;
      if (parentRef.current) parentRef.current.innerHTML = '';
    };
  }, [image]);

  useEffect(() => {
    const fc = localFabricRef.current;
    if (!fc) return;
    const bgImg = fc.getObjects('image')[0] as fabric.Image;
    if (!bgImg) return;

    const existingIds = fc.getObjects('rect').map(r => (r as any).data?.id);
    const incomingIds = crops.map(c => c.id);
    const needsRedraw = existingIds.length !== incomingIds.length || incomingIds.some(id => !existingIds.includes(id));

    if (needsRedraw) {
      fc.getObjects('rect').forEach(r => fc.remove(r));
      crops.forEach((zone) => {
        if (!zone.percent) return;
        const rect = new fabric.Rect({
          left: bgImg.left! + (zone.percent.x * bgImg.getScaledWidth()) / 100,
          top: bgImg.top! + (zone.percent.y * bgImg.getScaledHeight()) / 100,
          width: (zone.percent.width * bgImg.getScaledWidth()) / 100,
          height: (zone.percent.height * bgImg.getScaledHeight()) / 100,
          angle: zone.rotation || 0,
          fill: 'rgba(16,185,129,0.2)',
          stroke: '#10b981',
          strokeWidth: 2,
          cornerColor: '#10b981',
          cornerSize: 8,
          transparentCorners: false,
          data: { id: zone.id }
        });
        fc.add(rect);
      });
      fc.renderAll();
    }
  }, [crops]);

  return <div ref={parentRef} className="w-full h-full" />;
});

export default function App() {
  const { t, i18n } = useTranslation();
  const [isConnected, setIsConnected] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [activeView, setActiveView] = useState<'menu' | 'editor' | 'image' | 'document' | 'banner' | 'web' | 'collage' | 'tools' | 'templates'>('menu');
  const [isOcrLoading, setIsOcrLoading] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [printDelay, setPrintDelay] = useState(15);
  const [dithering, setDithering] = useState<DitheringType>('floyd-steinberg');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [printProgress, setPrintProgress] = useState(0);
  const [printStatus, setPrintStatus] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [darkness, setDarkness] = useState(50); // 0-100 Scale
  const [isExtraDark, setIsExtraDark] = useState(false);
  const [pageWidth, setPageWidth] = useState(384); // 57mm is ~384px
  const [pageHeight, setPageHeight] = useState(0); // 0 for infinite
  const [isCropping, setIsCropping] = useState(false);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);
  const [croppedAreaPercentages, setCroppedAreaPercentages] = useState<any>(null);
  const [isFreeCrop, setIsFreeCrop] = useState(false);
  const [cropLocked, setCropLocked] = useState(true); // aspect ratio lock
  const [cropCustomW, setCropCustomW] = useState(384);
  const [cropCustomH, setCropCustomH] = useState(200);
  
  // Editor State
  const [text, setText] = useState('');
  const [fontSize, setFontSize] = useState(24);
  const [alignment, setAlignment] = useState<'left' | 'center' | 'right' | 'justify'>('center');
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);
  const [fontFamily, setFontFamily] = useState('Outfit');
  const [customFonts, setCustomFonts] = useState<{name: string, url: string}[]>([]);
  const [selectedText, setSelectedText] = useState('');
  const [showHtmlEditor, setShowHtmlEditor] = useState(false);
  const [htmlTemplate, setHtmlTemplate] = useState(`<html>
  <body style="text-align: center;">
    <h1>{{BASLIK}}</h1>
    <p>{{METIN}}</p>
    <small>{{TARIH}}</small>
  </body>
</html>`);
  const [pdfRotation, setPdfRotation] = useState(0);
  const [isCustomPageEnabled, setIsCustomPageEnabled] = useState(false);
  const [printQuality, setPrintQuality] = useState<'draft' | 'normal' | 'fine'>('normal');
  const [savedCrops, setSavedCrops] = useState<{id: string, name: string, crops: any[] }[]>(() => {
    const saved = localStorage.getItem('iprint_saved_crops_v3');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Standart (57mm)', crops: [{x:0, y:0, width:384, height:200, percent: {x:0, y:0, width:100, height:50}}] }
    ];
  });
  const [activeMultiCrops, setActiveMultiCrops] = useState<any[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);

  // Image State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // PDF State
  const [pdfFiles, setPdfFiles] = useState<File[]>([]);
  const [activePdfIndex, setActivePdfIndex] = useState(0);
  const [printCopies, setPrintCopies] = useState(1);
  const [pdfScale, setPdfScale] = useState(1.0);
  const [pdfPageRange, setPdfPageRange] = useState('1');
  const [isPdfCropping, setIsPdfCropping] = useState(false);

  // Banner State
  const [bannerText, setBannerText] = useState('');
  const [bannerOrientation, setBannerOrientation] = useState<'horizontal' | 'vertical'>('horizontal');
  const [bannerType, setBannerType] = useState<'banner' | 'etiket'>('banner');
  const [bannerFontSize, setBannerFontSize] = useState(48);
  const [printAllFiles, setPrintAllFiles] = useState(false);

  // Web State
  const [webUrl, setWebUrl] = useState('');
  const [prePrintFeed, setPrePrintFeed] = useState(0); // lines to feed before print
  const [postPrintFeed, setPostPrintFeed] = useState(3); // lines to feed after print
  const [feedAmount, setFeedAmount] = useState(50); // dots to feed manually
  const [isRemovingBg, setIsRemovingBg] = useState(false);
  const [useArchitect, setUseArchitect] = useState(false);
  const fabricRef = useRef<fabric.Canvas | null>(null);
  const architectCanvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null);
  const [multiCropLayout, setMultiCropLayout] = useState<'vertical' | 'horizontal' | 'grid'>('vertical');
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('iprint_dark_mode') === 'true');
  const [showConsole, setShowConsole] = useState(() => localStorage.getItem('iprint_show_console') === 'true');

  const resetProject = () => {
    setSelectedImage(null);
    setActiveMultiCrops([]);
    setSelectedZoneId(null);
    setActiveProfileId(null);
    setIsCropping(false);
    logger.info('Proje temizlendi');
  };

  useEffect(() => {
    localStorage.setItem('iprint_dark_mode', isDarkMode.toString());
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('iprint_show_console', showConsole.toString());
  }, [showConsole]);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const toggleLanguage = () => {
    const newLang = i18n.language === 'tr' ? 'en' : 'tr';
    i18n.changeLanguage(newLang);
  };

  const handleSwitchChannel = () => {
    logger.info('Kanal değiştiriliyor...');
    printer.switchCharacteristic();
  };

  const handleAdvancePaper = async (amount: number = 50) => {
    if (!isConnected) {
      logger.warn('Kağıt sürme: Yazıcı bağlı değil');
      return;
    }
    try {
      // 1. Standard ESC/POS Feed (n dots)
      await printer.sendData(new Uint8Array([0x1B, 0x4A, Math.min(255, amount)]));
      
      // 2. Standard ESC/POS Feed (n lines) - Backup
      await printer.sendData(new Uint8Array([0x1B, 0x64, Math.min(255, Math.ceil(amount / 20))]));

      // 3. Luck Jingle Specific Feed Command (0xBD)
      const feedData = new Uint8Array([Math.min(255, Math.floor(amount/2))]);
      await printer.sendData(PrinterService.createLuckJinglePacket(0xBD, 0x00, feedData));

      // 4. Luck Jingle Specific Feed Command (0xBE) - Backup
      await printer.sendData(PrinterService.createLuckJinglePacket(0xBE, 0x00, feedData));
      
      logger.info(`Gelişmiş Kağıt Sürme: ${amount} birim (Çoklu protokol gönderildi)`);
    } catch (err) {
      logger.error('Kağıt sürme hatası:', err);
    }
  };

  const onTestDarkness = async () => {
    if (!isConnected) {
      logger.warn('Yazıcıya bağlanın!');
      return;
    }
    
    logger.info('Koyuluk testi başlatılıyor...');
    const encoder = new TextEncoder();
    
    // 1. Varsayılan (Normal)
    await printer.sendData(PrinterService.setIntensity(50));
    await printer.sendData(PrinterService.init());
    await printer.sendData(encoder.encode('\r\nTON: VARSAYILAN\r\n'));
    await printer.sendData(PrinterService.printAndFeed(2));
    
    // 2. Koyu (Extra)
    await printer.sendData(PrinterService.setIntensity(100));
    await printer.sendData(encoder.encode('TON: KOYU\r\n'));
    await printer.sendData(PrinterService.printAndFeed(4));
    
    // Reset to user's setting
    await printer.sendData(PrinterService.setIntensity(darkness));
    logger.info('Test bitti.');
  };

  const handleConnect = async () => {
    await printer.initialize();
    const success = await printer.connect();
    setIsConnected(success);
    if (success) {
      printer.setBatteryCallback((level) => setBatteryLevel(level));
      const level = await printer.getBatteryLevel();
      setBatteryLevel(level);
    }
  };


  useEffect(() => {
    if (useArchitect && selectedImage && architectCanvasRef.current) {
      const container = architectCanvasRef.current.parentElement;
      if (!container || container.clientWidth === 0) {
        logger.warn('Architect container not ready or zero-size, retrying...');
        return;
      }
      
      const fc = new fabric.Canvas(architectCanvasRef.current, {
        width: container.clientWidth,
        height: container.clientHeight,
        backgroundColor: '#0a0a0a',
        preserveObjectStacking: true
      });
      fabricRef.current = fc;

      fabric.Image.fromURL(selectedImage, (img) => {
        // Center and scale image to fit
        const scale = Math.min(fc.width! / img.width!, fc.height! / img.height!) * 0.9;
        img.scale(scale);
        img.set({
          left: (fc.width! - img.width! * scale) / 2,
          top: (fc.height! - img.height! * scale) / 2,
          selectable: false,
          hoverCursor: 'default'
        });
        fc.add(img);
        fc.sendToBack(img);

        // Add rectangles for activeMultiCrops
        activeMultiCrops.forEach((zone, idx) => {
          const rect = new fabric.Rect({
            left: img.left! + (zone.percent.x * img.getScaledWidth()) / 100,
            top: img.top! + (zone.percent.y * img.getScaledHeight()) / 100,
            width: (zone.percent.width * img.getScaledWidth()) / 100,
            height: (zone.percent.height * img.getScaledHeight()) / 100,
            angle: zone.rotation || 0,
            fill: 'rgba(16,185,129,0.2)',
            stroke: '#10b981',
            strokeWidth: 2,
            cornerColor: '#10b981',
            cornerSize: 8,
            transparentCorners: false,
            data: { id: zone.id }
          });
          fc.add(rect);
        });

        fc.renderAll();
      });

      const syncFromFabric = () => {
        const bgImg = fc.getObjects('image')[0] as fabric.Image;
        if (!bgImg) return;

        const updatedCrops = fc.getObjects('rect').map(r => {
          const rect = r as fabric.Rect;
          const imgW = bgImg.getScaledWidth();
          const imgH = bgImg.getScaledHeight();
          
          return {
            id: (rect as any).data?.id || Math.random().toString(36).substr(2, 9),
            rotation: rect.angle,
            percent: {
              x: ((rect.left! - bgImg.left!) / imgW) * 100,
              y: ((rect.top! - bgImg.top!) / imgH) * 100,
              width: (rect.getScaledWidth() / imgW) * 100,
              height: (rect.getScaledHeight() / imgH) * 100
            },
            // Fallback pixels for backward compatibility
            width: rect.getScaledWidth(),
            height: rect.getScaledHeight(),
            x: rect.left! - bgImg.left!,
            y: rect.top! - bgImg.top!
          };
        });
        setActiveMultiCrops(updatedCrops);
      };

      fc.on('object:modified', syncFromFabric);
      fc.on('object:added', syncFromFabric);
      fc.on('object:removed', syncFromFabric);

      return () => {
        // Critical: Fabric wraps the canvas in a .canvas-container div.
        // We must dispose and ensure the actual DOM nodes are handled before React's cleanup.
        logger.debug('Cleaning up Architect canvas...');
        try {
          fc.dispose();
        } catch (e) {
          logger.error('Fabric dispose error', e);
        }
        fabricRef.current = null;
      };
    }
  }, [useArchitect, selectedImage]);

  useEffect(() => {
    let interval: any;
    if (isConnected) {
      const pollBattery = async () => {
        const level = await printer.getBatteryLevel();
        if (level !== null) setBatteryLevel(level);
        else {
          try { 
            // Send multiple status requests to increase response chance
            await printer.sendData(PrinterService.createLuckJinglePacket(0xA8, 0x00)); 
            await printer.sendData(PrinterService.createLuckJinglePacket(0xA3, 0x00)); 
          } catch (_) {}
        }
      };
      pollBattery();
      interval = setInterval(pollBattery, 30000);
    }
    return () => clearInterval(interval);
  }, [isConnected]);

  const addArchitectZone = () => {
    if (!fabricRef.current) return;
    const fc = fabricRef.current;
    const bgImg = fc.getObjects('image')[0] as fabric.Image;
    if (!bgImg) return;

    const rect = new fabric.Rect({
      left: bgImg.left! + bgImg.getScaledWidth() * 0.25,
      top: bgImg.top! + bgImg.getScaledHeight() * 0.25,
      width: bgImg.getScaledWidth() * 0.5,
      height: bgImg.getScaledHeight() * 0.2,
      fill: 'rgba(16,185,129,0.2)',
      stroke: '#10b981',
      strokeWidth: 2,
      cornerColor: '#10b981',
      cornerSize: 8,
      transparentCorners: false,
      data: { id: Math.random().toString(36).substr(2, 9) }
    });
    fc.add(rect);
    fc.setActiveObject(rect);
    fc.renderAll();
    
    // Trigger initial sync for the new zone
    const imgW = bgImg.getScaledWidth();
    const imgH = bgImg.getScaledHeight();
    const newZone = {
      id: (rect as any).data.id,
      rotation: 0,
      percent: {
        x: ((rect.left! - bgImg.left!) / imgW) * 100,
        y: ((rect.top! - bgImg.top!) / imgH) * 100,
        width: (rect.getScaledWidth() / imgW) * 100,
        height: (rect.getScaledHeight() / imgH) * 100
      },
      width: rect.getScaledWidth(),
      height: rect.getScaledHeight(),
      x: rect.left! - bgImg.left!,
      y: rect.top! - bgImg.top!
    };
    setActiveMultiCrops([...activeMultiCrops, newZone]);
  };

  const handleDisconnect = () => {
    printer.disconnect();
    setIsConnected(false);
    setBatteryLevel(null);
  };


  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
        setIsCropping(false); // Changed: Don't start cropping automatically
        e.target.value = '';
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePdfSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPdfFiles(prev => [...prev, file]);
      e.target.value = '';
    }
  };

  const onCropComplete = (croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPercentages(croppedArea);
    setCroppedAreaPixels(croppedAreaPixels);
  };

  const applyCrop = async () => {
    if (!selectedImage) return;
    
    // If we have multi-crops, we'll join them all vertically
    const cropsToApply = activeMultiCrops.length > 0 
      ? activeMultiCrops 
      : (croppedAreaPixels ? [{ ...croppedAreaPixels, id: 'temp' }] : []);

    if (cropsToApply.length === 0) return;

    const img = new Image();
    img.src = selectedImage;
    await new Promise(resolve => img.onload = resolve);

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Calculate total layout
    let totalHeight = 0;
    let maxWidth = 0;
    
    if (multiCropLayout === 'vertical') {
      totalHeight = cropsToApply.reduce((acc, c) => acc + c.height, 0);
      maxWidth = Math.max(...cropsToApply.map(c => c.width));
    } else if (multiCropLayout === 'horizontal') {
      totalHeight = Math.max(...cropsToApply.map(c => c.height));
      maxWidth = cropsToApply.reduce((acc, c) => acc + c.width, 0);
    } else {
      // Grid: 2 columns
      const rows = Math.ceil(cropsToApply.length / 2);
      maxWidth = Math.max(...cropsToApply.map(c => c.width)) * 2;
      totalHeight = rows * Math.max(...cropsToApply.map(c => c.height));
    }

    canvas.width = maxWidth;
    canvas.height = totalHeight;

    let currentX = 0;
    let currentY = 0;
    
    cropsToApply.forEach((zone, idx) => {
      // Calculate absolute pixels from normalized percentages if available, otherwise fallback to pixels
      const x = zone.percent ? (img.width * zone.percent.x) / 100 : zone.x;
      const y = zone.percent ? (img.height * zone.percent.y) / 100 : zone.y;
      const w = zone.percent ? (img.width * zone.percent.width) / 100 : zone.width;
      const h = zone.percent ? (img.height * zone.percent.height) / 100 : zone.height;
      const rotation = zone.rotation || 0;

      ctx.save();
      
      let targetX = 0;
      let targetY = 0;
      
      if (multiCropLayout === 'vertical') {
        targetX = (maxWidth - w) / 2;
        targetY = currentY;
        currentY += h;
      } else if (multiCropLayout === 'horizontal') {
        targetX = currentX;
        targetY = (totalHeight - h) / 2;
        currentX += w;
      } else {
        const col = idx % 2;
        const row = Math.floor(idx / 2);
        const cellW = maxWidth / 2;
        const cellH = totalHeight / Math.ceil(cropsToApply.length / 2);
        targetX = col * cellW + (cellW - w) / 2;
        targetY = row * cellH + (cellH - h) / 2;
      }

      // Draw rotated crop
      ctx.translate(targetX + w/2, targetY + h/2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(img, x, y, w, h, -w/2, -h/2, w, h);
      ctx.restore();
    });
    
    if (isPdfCropping) {
      setSelectedImage(canvas.toDataURL());
      setActiveView('image');
      setIsPdfCropping(false);
    } else {
      setSelectedImage(canvas.toDataURL());
    }
    
    // Explicitly set these to ensure UI updates after DOM is stable
    setTimeout(() => {
      setIsCropping(false);
      setActiveMultiCrops([]);
      setSelectedZoneId(null);
      setUseArchitect(false); // Force exit architect mode on apply
      logger.info('Kırpma başarıyla uygulandı ve görsele aktarıldı');
    }, 100);
  };

  const handleRemoveBackground = async () => {
    if (!selectedImage) return;
    setIsRemovingBg(true);
    try {
      const result = await removeBackground(selectedImage);
      setSelectedImage(result);
      logger.info('Arkaplan başarıyla silindi');
    } catch (err) {
      logger.error('Arkaplan silme hatası');
    } finally {
      setIsRemovingBg(false);
    }
  };

  const handleOCR = async () => {
    if (!selectedImage) return;
    setIsOcrLoading(true);
    try {
      const text = await performOCR(selectedImage);
      setText(prev => prev + (prev ? '\n' : '') + text);
      setActiveView('editor');
      logger.info('OCR başarıyla tamamlandı, metin editöre eklendi');
    } catch (err) {
      logger.error('OCR hatası');
    } finally {
      setIsOcrLoading(false);
    }
  };

  const startPdfCrop = async () => {
    const activePdf = pdfFiles[activePdfIndex];
    if (!activePdf) return;
    try {
      const arrayBuffer = await activePdf.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      const pageNum = parseInt(pdfPageRange) || 1;
      const page = await pdf.getPage(pageNum);
      const viewport = page.getViewport({ scale: 2 }); // High res for crop
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await (page as any).render({ canvasContext: ctx, viewport }).promise;
      
      setSelectedImage(canvas.toDataURL());
      setIsPdfCropping(true);
      setIsCropping(true);
      setActiveView('image'); // Switch to image view to show the cropper
    } catch (err) {
      logger.error('PDF Crop Hatası: ' + err);
    }
  };

  const handleFontUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fontName = file.name.split('.')[0];
    const reader = new FileReader();
    reader.onload = async (event) => {
      const url = event.target?.result as string;
      const fontFace = new FontFace(fontName, `url(${url})`);
      try {
        await fontFace.load();
        (document as any).fonts.add(fontFace);
        setCustomFonts(prev => [...prev, { name: fontName, url }]);
        setFontFamily(fontName);
        logger.info(`Font yüklendi: ${fontName}`);
      } catch (err) {
        logger.error('Font yükleme hatası');
      }
    };
    reader.readAsDataURL(file);
  };

  const addCropZone = () => {
    if (!croppedAreaPixels || !croppedAreaPercentages) return;
    const newZone = {
      id: Math.random().toString(36).substr(2, 9),
      ...croppedAreaPixels,
      percent: croppedAreaPercentages // Precision storage
    };
    setActiveMultiCrops([...activeMultiCrops, newZone]);
  };

  const removeCropZone = (id: string) => {
    setActiveMultiCrops(activeMultiCrops.filter(z => z.id !== id));
    if (selectedZoneId === id) setSelectedZoneId(null);
  };

  const updateCropZone = () => {
    if (!selectedZoneId || !croppedAreaPixels || !croppedAreaPercentages) return;
    setActiveMultiCrops(activeMultiCrops.map(z => 
      z.id === selectedZoneId ? { ...z, ...croppedAreaPixels, percent: croppedAreaPercentages } : z
    ));
    logger.info('Bölge güncellendi');
  };

  const saveCurrentCrop = () => {
    const list = activeMultiCrops.length > 0 ? activeMultiCrops : (croppedAreaPixels ? [croppedAreaPixels] : []);
    if (list.length === 0) {
      alert('Önce bir kırpma alanı belirleyin veya bölge ekleyin!');
      return;
    }

    const name = prompt('Bu kırpma profiline bir isim verin:', `Profil ${savedCrops.length + 1}`);
    if (name) {
      const newProfile = { 
        id: Date.now().toString(), 
        name, 
        crops: list.map(({id, ...rest}: any) => rest) 
      };
      const updated = [...savedCrops, newProfile];
      setSavedCrops(updated);
      localStorage.setItem('iprint_saved_crops_v3', JSON.stringify(updated));
      setActiveProfileId(newProfile.id);
    }
  };

  const applySavedProfile = (profileId: string) => {
    const profile = savedCrops.find(p => p.id === profileId);
    if (profile) {
      // Add profile crops to current session, preserving layout
      const profileCropsWithIds = profile.crops.map(c => ({
        ...c,
        id: Math.random().toString(36).substr(2, 9)
      }));
      setActiveMultiCrops(profileCropsWithIds);
      setActiveProfileId(profileId);
      logger.info(`"${profile.name}" profili uygulandı`);
    }
  };

  const deleteSavedProfile = (id: string) => {
    const updated = savedCrops.filter(p => p.id !== id);
    setSavedCrops(updated);
    localStorage.setItem('iprint_saved_crops_v3', JSON.stringify(updated));
    if (activeProfileId === id) setActiveProfileId(null);
  };

  const movePdf = (index: number, direction: 'up' | 'down') => {
    const newFiles = [...pdfFiles];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newFiles.length) return;
    const temp = newFiles[index];
    newFiles[index] = newFiles[targetIndex];
    newFiles[targetIndex] = temp;
    setPdfFiles(newFiles);
    setActivePdfIndex(targetIndex);
  };

  const generatePreview = async (silent: boolean = false) => {
    const canvas = canvasRef.current;
    if (!canvas) {
      logger.error('Canvas bulunamadı!');
      return;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      logger.error('Canvas context alınamadı!');
      return;
    }

    logger.info(`Önizleme oluşturuluyor: ${activeView} (silent: ${silent})`);

    let height = 100;
    
    if (activeView === 'editor') {
      let textToRender = text;
      let renderMode: 'plain' | 'html' = 'plain';
      
      // Check if HTML template is being used
      if (showHtmlEditor && htmlTemplate && htmlTemplate.trim().length > 0 && htmlTemplate.includes('{{')) {
        renderMode = 'html';
        const now = new Date();
        const formattedDate = now.toLocaleDateString('tr-TR');
        const formattedTime = now.toLocaleTimeString('tr-TR');
        
        // Replace all variables in HTML template
        let processedHtml = htmlTemplate
          .replace(/{{BASLIK}}/g, text.split('\n')[0] || 'Başlık')
          .replace(/{{METIN}}/g, text.replace(/\n/g, '<br>'))
          .replace(/{{TARIH}}/g, formattedDate)
          .replace(/{{SAAT}}/g, formattedTime);
        
        // Extract plain text from HTML for canvas rendering
        // Handle tables by converting to multiline text
        textToRender = processedHtml
          .replace(/<table[^>]*>[\s\S]*?<\/table>/gi, (match) => {
            let tableText = '';
            // Extract rows
            const rows = match.match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
            rows.forEach((row, i) => {
              const cells = row.match(/<td[^>]*>[\s\S]*?<\/td>/gi) || [];
              cells.forEach((cell, j) => {
                tableText += cell.replace(/<[^>]*>/g, '').trim();
                if (j < cells.length - 1) tableText += ' | ';
              });
              tableText += '\n';
            });
            return tableText;
          })
          .replace(/<div[^>]*>|<\/div>/gi, '\n')
          .replace(/<br\s*\/?>/gi, '\n')
          .replace(/<hr\s*\/?>/gi, '\n' + '─'.repeat(20) + '\n')
          .replace(/<p[^>]*>|<\/p>/gi, '\n')
          .replace(/<h[1-6][^>]*>|<\/h[1-6]>/gi, '\n')
          .replace(/<b>|<\/b>|<strong>|<\/strong>/gi, '')
          .replace(/<small[^>]*>|<\/small>/gi, '')
          .replace(/<[^>]*>/g, '')
          .replace(/&nbsp;/g, ' ')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/\n\s*\n/g, '\n')
          .trim();
      }
      
      ctx.font = `${isBold ? 'bold ' : ''}${isItalic ? 'italic ' : ''}${isUnderline ? 'underline ' : ''}${fontSize}px ${fontFamily}`;
      const lines = textToRender.split('\n');
      const maxWidth = pageWidth - 20;
      const wrappedLines: string[] = [];
      lines.forEach(line => {
        let currentLine = '';
        const words = line.split(' ');
        words.forEach(word => {
          const testLine = currentLine ? currentLine + ' ' + word : word;
          if (ctx.measureText(testLine).width > maxWidth) {
            wrappedLines.push(currentLine);
            currentLine = word;
          } else {
            currentLine = testLine;
          }
        });
        wrappedLines.push(currentLine);
      });

      const calculatedHeight = wrappedLines.length * fontSize * 1.3 + 40;
      height = pageHeight > 0 ? pageHeight : calculatedHeight;
      canvas.width = pageWidth;
      canvas.height = height;
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, pageWidth, height);
      ctx.fillStyle = 'black';
      ctx.font = `${isBold ? 'bold ' : ''}${isItalic ? 'italic ' : ''}${isUnderline ? 'underline ' : ''}${fontSize}px ${fontFamily}`;
      ctx.textBaseline = 'top';
      ctx.textAlign = alignment === 'justify' ? 'left' : alignment;
      const padding = 10;
      const x = alignment === 'center' ? pageWidth / 2 : alignment === 'right' ? pageWidth - padding : padding;
      wrappedLines.forEach((line, i) => {
        const y = 20 + i * fontSize * 1.3;
        if (alignment === 'justify' && i < wrappedLines.length - 1) {
          const words = line.split(' ');
          if (words.length > 1) {
            const totalWordsWidth = words.reduce((acc, word) => acc + ctx.measureText(word).width, 0);
            const spaceWidth = (pageWidth - 2 * padding - totalWordsWidth) / (words.length - 1);
            let currentX = padding;
            words.forEach((word) => {
              ctx.fillText(word, currentX, y);
              currentX += ctx.measureText(word).width + spaceWidth;
            });
          } else { ctx.fillText(line, padding, y); }
        } else { ctx.fillText(line, x, y); }
      });
      setPreviewImage(canvas.toDataURL());
      if (!silent) setIsPreviewOpen(true);
    } else if (activeView === 'image' && selectedImage) {
      const img = new Image();
      img.onload = () => {
        const cropsToPreview = activeMultiCrops.length > 0 ? activeMultiCrops : (croppedAreaPixels ? [croppedAreaPixels] : []);
        
        if (cropsToPreview.length > 0) {
          // Join all crops based on layout
          let totalH = 0;
          let totalW = 0;
          
          if (multiCropLayout === 'vertical') {
            totalH = cropsToPreview.reduce((acc, c) => acc + (c.percent ? (img.height * c.percent.height)/100 : c.height), 0);
            totalW = Math.max(...cropsToPreview.map(c => c.percent ? (img.width * c.percent.width)/100 : c.width));
          } else if (multiCropLayout === 'horizontal') {
            totalH = Math.max(...cropsToPreview.map(c => c.percent ? (img.height * c.percent.height)/100 : c.height));
            totalW = cropsToPreview.reduce((acc, c) => acc + (c.percent ? (img.width * c.percent.width)/100 : c.width), 0);
          } else {
            const rows = Math.ceil(cropsToPreview.length / 2);
            totalW = Math.max(...cropsToPreview.map(c => c.percent ? (img.width * c.percent.width)/100 : c.width)) * 2;
            totalH = rows * Math.max(...cropsToPreview.map(c => c.percent ? (img.height * c.percent.height)/100 : c.height));
          }
          
          const tempCanvas = document.createElement('canvas');
          const tempCtx = tempCanvas.getContext('2d');
          if (!tempCtx) return;
          tempCanvas.width = totalW;
          tempCanvas.height = totalH;
          
          let curX = 0, curY = 0;
          cropsToPreview.forEach((z, idx) => {
            const x = z.percent ? (img.width * z.percent.x) / 100 : z.x;
            const y = z.percent ? (img.height * z.percent.y) / 100 : z.y;
            const w = z.percent ? (img.width * z.percent.width) / 100 : z.width;
            const h = z.percent ? (img.height * z.percent.height) / 100 : z.height;
            const rot = z.rotation || 0;
            
            tempCtx.save();
            let tx = 0, ty = 0;
            if (multiCropLayout === 'vertical') {
              tx = (totalW - w) / 2; ty = curY; curY += h;
            } else if (multiCropLayout === 'horizontal') {
              tx = curX; ty = (totalH - h) / 2; curX += w;
            } else {
              const rows = Math.ceil(cropsToPreview.length / 2);
              const row = Math.floor(idx / 2);
              const col = idx % 2; 
              const cw = totalW / 2; 
              const ch = totalH / rows;
              tx = col * cw + (cw - w) / 2; ty = row * ch + (ch - h) / 2;
            }
            
            tempCtx.translate(tx + w/2, ty + h/2);
            tempCtx.rotate((rot * Math.PI) / 180);
            tempCtx.drawImage(img, x, y, w, h, -w/2, -h/2, w, h);
            tempCtx.restore();
          });
          
          const scale = pageWidth / totalW;
          canvas.width = pageWidth;
          canvas.height = totalH * scale;
          ctx.fillStyle = 'white';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(tempCanvas, 0, 0, canvas.width, canvas.height);
        } else {
          const scale = pageWidth / img.width;
          canvas.width = pageWidth;
          canvas.height = img.height * scale;
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        }
        setPreviewImage(canvas.toDataURL());
        if (!silent) setIsPreviewOpen(true);
      };
      img.src = selectedImage;
    } else if (activeView === 'document' && pdfFiles.length > 0) {
      const activePdf = pdfFiles[activePdfIndex];
      try {
        const arrayBuffer = await activePdf.arrayBuffer();
        const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
        const pdf = await loadingTask.promise;
        const pageNum = parseInt(pdfPageRange.split(',')[0]) || 1;
        const page = await pdf.getPage(pageNum > pdf.numPages ? 1 : pageNum);
        const viewport = page.getViewport({ scale: 1, rotation: pdfRotation });
        const scale = (pageWidth / viewport.width) * pdfScale;
        const scaledViewport = page.getViewport({ scale, rotation: pdfRotation });
        height = pageHeight > 0 ? pageHeight : scaledViewport.height;
        canvas.width = pageWidth;
        canvas.height = height;
        await (page as any).render({ canvasContext: ctx, viewport: scaledViewport }).promise;
        setPreviewImage(canvas.toDataURL());
        if (!silent) setIsPreviewOpen(true);
      } catch (err) {
        logger.error('PDF işleme hatası: ' + err);
        setPrintStatus('PDF Yüklenemedi! İnternet veya dosya formatı sorunu olabilir.');
        setTimeout(() => setPrintStatus(''), 3000);
      }
    } else if (activeView === 'banner' && bannerText) {
      if (bannerType === 'etiket') {
        canvas.width = pageWidth;
        canvas.height = bannerFontSize + 40;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.font = `bold ${bannerFontSize}px Outfit`;
        ctx.fillStyle = 'black';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(bannerText, pageWidth / 2, canvas.height / 2);
      } else {
        ctx.font = `bold ${bannerFontSize}px Outfit`;
        if (bannerOrientation === 'horizontal') {
          const textWidth = ctx.measureText(bannerText).width;
          canvas.width = pageWidth;
          canvas.height = textWidth + 40;
          ctx.fillStyle = 'white';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.save();
          ctx.translate(pageWidth / 2, canvas.height / 2);
          ctx.rotate(Math.PI / 2);
          ctx.font = `bold ${bannerFontSize}px Outfit`;
          ctx.fillStyle = 'black';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(bannerText, 0, 0);
          ctx.restore();
        } else {
          const chars = bannerText.split('');
          canvas.width = pageWidth;
          canvas.height = chars.length * bannerFontSize * 1.1 + 40;
          ctx.fillStyle = 'white';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.font = `bold ${bannerFontSize}px Outfit`;
          ctx.fillStyle = 'black';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          chars.forEach((char, i) => {
            ctx.fillText(char, pageWidth / 2, 20 + i * bannerFontSize * 1.1);
          });
        }
      }
      setPreviewImage(canvas.toDataURL());
      if (!silent) setIsPreviewOpen(true);
    }
  };

  // Auto-preview for banner
  useEffect(() => {
    if (activeView === 'banner' && bannerText) {
      const timer = setTimeout(() => generatePreview(true), 300);
      return () => clearTimeout(timer);
    }
  }, [bannerText, bannerType, bannerOrientation, bannerFontSize, activeView]);

  const handlePrint = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !isConnected) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsPrinting(true);
    setPrintProgress(0);
    setPrintStatus('Hazırlanıyor...');
    
    try {
      await printer.wake();
      const isGB = printer.getDeviceName()?.includes('GB');
      printer.setCustomDelay(printDelay);

      if (isConnected && prePrintFeed > 0) {
        setPrintStatus('Hazırlanıyor (Boşluk)...');
        await handleAdvancePaper(prePrintFeed * 10);
      }

      // Recursive helper for printing a single bitmap
      const printBitmap = async (bitmap: Uint8Array, w: number, h: number) => {
        if (isGB) {
          const minPower = 26;
          const maxPower = 95;
          const b = Math.floor(minPower + (darkness/100) * (maxPower - minPower));
          const power = [b, darkness > 80 ? 0xFF : (darkness > 50 ? 0xE0 : 0x00)];
          await printer.sendData(PrinterService.createLuckJinglePacket(0xA2, 0x00, new Uint8Array(power)));
          const q = Math.floor(17 + (darkness/100) * 136);
          await printer.sendData(new Uint8Array([0x51, 0x78, 0xA4, 0x00, 0x01, 0x00, q, 0x99, 0xFF]));
          await printer.sendData(new Uint8Array([0x51, 0x78, 0xBE, 0x00, 0x01, 0x00, 0x00, 0x00, 0xFF]));
          const bpl = w / 8;
          for (let y = 0; y < h; y++) {
            if ((printer as any).isCancelled) break;
            const lineData = bitmap.slice(y * bpl, (y + 1) * bpl);
            await printer.sendData(PrinterService.createLuckJinglePacket(0xA2, 0x00, lineData), printDelay);
            await printer.sendData(new Uint8Array([0x51, 0x78, 0xBD, 0x00, 0x01, 0x00, 0x19, 0x07, 0xFF]), 0);
            setPrintProgress(Math.round(((y + 1) / h) * 100));
          }
          await printer.sendData(new Uint8Array([0x51, 0x78, 0xA1, 0x00, 0x02, 0x00, 0x30, 0x00, 0xF9, 0xFF]));
        } else {
          await printer.sendData(PrinterService.init());
          const bpl = w / 8;
          for (let y = 0; y < h; y++) {
            if ((printer as any).isCancelled) break;
            const lineData = bitmap.slice(y * bpl, (y + 1) * bpl);
            const cmd = new Uint8Array(8 + lineData.length);
            cmd.set([0x1D, 0x76, 0x30, 0x00, bpl, 0x00, 0x01, 0x00]);
            cmd.set(lineData, 8);
            await printer.sendData(cmd, printDelay);
            setPrintProgress(Math.round(((y + 1) / h) * 100));
          }
          await printer.sendData(PrinterService.printAndFeed(3));
        }
      };

      if (activeView === 'document' && pdfFiles.length > 0) {
        const filesToPrint = printAllFiles ? pdfFiles : [pdfFiles[activePdfIndex]];
        
        for (let fIdx = 0; fIdx < filesToPrint.length; fIdx++) {
          const activePdf = filesToPrint[fIdx];
          const arrayBuffer = await activePdf.arrayBuffer();
          const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
          const pageList = pdfPageRange.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n) && n > 0 && n <= pdf.numPages);
          const finalPages = pageList.length > 0 ? pageList : [1];

          for (const pageNum of finalPages) {
            const page = await pdf.getPage(pageNum);
            const viewport = page.getViewport({ scale: 1, rotation: pdfRotation });
            const scale = (pageWidth / viewport.width) * pdfScale;
            const scaledViewport = page.getViewport({ scale, rotation: pdfRotation });
            canvas.width = pageWidth;
            canvas.height = scaledViewport.height;
            await (page as any).render({ canvasContext: ctx, viewport: scaledViewport }).promise;
            const bitmap = processImage(ctx, canvas.width, canvas.height, dithering);

            for (let c = 0; c < printCopies; c++) {
              setPrintStatus(`Belge ${fIdx+1}/${filesToPrint.length} - Sayfa ${pageNum} [${c + 1}/${printCopies}]`);
              await printBitmap(bitmap, canvas.width, canvas.height);
              if (c < printCopies - 1 || pageNum !== finalPages[finalPages.length-1] || fIdx !== filesToPrint.length-1) {
                await new Promise(r => setTimeout(r, 1000));
              }
            }
          }
        }
      } else {
        const bitmap = processImage(ctx, canvas.width, canvas.height, dithering);
        for (let c = 0; c < printCopies; c++) {
          setPrintStatus(printCopies > 1 ? `Yazdırılıyor: Kopya ${c + 1}/${printCopies}` : 'Yazdırılıyor...');
          await printBitmap(bitmap, canvas.width, canvas.height);
          if (c < printCopies - 1) await new Promise(r => setTimeout(r, 1000));
        }
      }

      if (isConnected && postPrintFeed > 0) {
        setPrintStatus('Kağıt sürülüyor...');
        await handleAdvancePaper(postPrintFeed * 10);
      }

      setPrintStatus('Tamamlandı!');
      setTimeout(() => setIsPrinting(false), 1000);
    } catch (error: any) {
      setPrintStatus('Hata oluştu!');
      setTimeout(() => setIsPrinting(false), 2000);
    }
    setIsPreviewOpen(false);
  };

  const handleCancelPrint = () => printer.cancelPrint();

  const MenuCard = ({ icon: Icon, title, color, onClick }: { icon: any, title: string, color: string, onClick: () => void }) => (
    <motion.div whileHover={{ scale: 1.02, y: -2 }} whileTap={{ scale: 0.98 }} onClick={onClick} className={`menu-grid-item ${color} dark:bg-slate-900 dark:border-slate-800 cursor-pointer group shadow-sm hover:shadow-xl transition-all duration-300`}>
      <div className="bg-white/50 dark:bg-white/10 p-3 rounded-2xl mb-2 group-hover:bg-white/80 dark:group-hover:bg-white/15 transition-colors">
        <Icon size={24} className="text-slate-700 dark:text-slate-200" />
      </div>
      <span className="font-bold text-slate-800 dark:text-slate-200 text-center text-xs tracking-tight">{title}</span>
    </motion.div>
  );

  return (
    <div className={`min-h-screen flex flex-col md:flex-row max-w-6xl mx-auto relative font-outfit transition-colors duration-500 ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Hidden canvas used for all preview/print rendering — MUST stay in DOM */}
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
      <AnimatePresence>
        {isPrinting && (
          <motion.div initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }} className="fixed bottom-6 left-6 right-6 z-[100] md:left-auto md:right-10 md:w-80">
            <Card className="p-4 rounded-3xl shadow-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="bg-teal-100 dark:bg-teal-900/30 p-2 rounded-xl"><Printer className="text-teal-600 dark:text-teal-400 animate-pulse" size={20} /></div>
                  <div>
                    <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{printStatus}</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Yazdırma Sürüyor...</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={handleCancelPrint} className="rounded-full hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/20"><X size={20} /></Button>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold text-slate-400"><span>İlerleme</span><span>%{isNaN(printProgress) ? 0 : printProgress}</span></div>
                <Progress value={isNaN(printProgress) ? 0 : printProgress} className="h-1.5" />
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 border-r border-slate-100 dark:border-slate-800 p-6 space-y-8 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="bg-teal-600 p-2.5 rounded-2xl shadow-lg shadow-teal-500/20"><Printer className="text-white" size={24} /></div>
          <h1 className="text-xl font-black tracking-tight text-slate-800 dark:text-white">iPrint Pro</h1>
        </div>
        
        <nav className="space-y-2">
          <Button variant={activeView === 'menu' ? 'default' : 'ghost'} onClick={() => setActiveView('menu')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><Layout size={18}/> {t('menu.home') || 'Ana Sayfa'}</Button>
          <Button variant={activeView === 'editor' ? 'default' : 'ghost'} onClick={() => setActiveView('editor')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><Type size={18}/> {t('menu.text')}</Button>
          <Button variant={activeView === 'image' ? 'default' : 'ghost'} onClick={() => setActiveView('image')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><ImageIcon size={18}/> {t('menu.image')}</Button>
          <Button variant={activeView === 'templates' ? 'default' : 'ghost'} onClick={() => setActiveView('templates')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><Library size={18}/> Şablonlar</Button>
          <Button variant={activeView === 'tools' ? 'default' : 'ghost'} onClick={() => setActiveView('tools')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><QrCode size={18}/> Araçlar</Button>
          <Button variant={activeView === 'document' ? 'default' : 'ghost'} onClick={() => setActiveView('document')} className="w-full justify-start gap-3 rounded-xl h-12 font-bold"><FileText size={18}/> {t('menu.document')}</Button>
        </nav>

        <div className="mt-auto space-y-4">
          <Card className={`p-4 rounded-2xl border-none ${isConnected ? 'bg-green-50 dark:bg-green-900/20' : 'bg-slate-100 dark:bg-slate-800'}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-black uppercase text-slate-500">{isConnected ? 'BAĞLI' : 'BAĞLI DEĞİL'}</span>
              {isConnected && <Battery size={14} className="text-green-600"/>}
            </div>
            <Button onClick={isConnected ? handleDisconnect : handleConnect} className="w-full rounded-xl h-9 text-xs font-bold">{isConnected ? 'KOPAR' : 'BAĞLAN'}</Button>
          </Card>
          
          <div className="flex items-center justify-between px-2">
            <Button variant="ghost" size="icon" onClick={() => setIsDarkMode(!isDarkMode)} className="rounded-xl h-10 w-10">
               {isDarkMode ? <Zap size={18} className="text-amber-400 fill-amber-400" /> : <Monitor size={18} />}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)} className="rounded-xl h-10 w-10 text-slate-400"><Settings2 size={18}/></Button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col max-w-sm md:max-w-none mx-auto w-full">
        {/* Mobile Header (Hidden on Desktop) */}
        <header className="md:hidden p-3 sm:p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="bg-teal-50 dark:bg-teal-900/30 p-2 rounded-xl"><Printer className="text-teal-600 dark:text-teal-400" size={20} /></div>
            <h1 className="text-lg font-bold tracking-tight text-slate-800 dark:text-white">{t('app_name')}</h1>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => setIsDarkMode(!isDarkMode)} className="rounded-full h-8 w-8 text-slate-600 dark:text-slate-300">
               {isDarkMode ? <Zap size={16} className="text-amber-400 fill-amber-400" /> : <Monitor size={16} />}
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleLanguage} className="rounded-full h-8 w-8 dark:text-slate-300"><Languages size={16} /></Button>
            <Button variant="ghost" size="icon" onClick={() => setShowConsole(!showConsole)} className={`rounded-full h-8 w-8 ${showConsole ? 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400' : 'text-slate-400'}`}><Terminal size={16}/></Button>
          </div>
        </div>
        <Card className="p-3 rounded-2xl border-none shadow-sm bg-white/80 dark:bg-slate-900/60 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-1.5 rounded-full ${isConnected ? 'bg-green-100 dark:bg-green-900/30' : 'bg-slate-100 dark:bg-slate-800'}`}>{isConnected ? <Bluetooth className="text-green-600 dark:text-green-400" size={14} /> : <BluetoothOff className="text-slate-400" size={14} />}</div>
              <div>
                <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">{isConnected ? t('connected') : t('disconnected')}</p>
                {isConnected && (
                  <div className="flex items-center gap-1 mt-0.5">
                    <Battery size={10} className={batteryLevel !== null ? 'text-green-600 dark:text-green-400' : 'text-slate-400'} />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{batteryLevel !== null ? `${batteryLevel}%` : 'N/A'}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex gap-1">
              <Button onClick={isConnected ? handleDisconnect : handleConnect} variant={isConnected ? 'outline' : 'default'} className="flex-1 rounded-xl h-8 font-semibold text-xs px-3">{isConnected ? t('disconnect') : t('connect')}</Button>
              <Button onClick={() => setShowDiagnostics(!showDiagnostics)} variant="ghost" size="icon" className={`rounded-xl h-8 w-8 ${showDiagnostics ? 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400' : 'text-slate-400'}`}><Bug size={14}/></Button>
            </div>
          </div>
          <AnimatePresence>{showDiagnostics && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden mt-3">
              <DiagnosticsPanel 
                printer={printer} 
                isConnected={isConnected} 
                onSwitchChannel={handleSwitchChannel}
                feedAmount={feedAmount}
                setFeedAmount={setFeedAmount}
                onAdvancePaper={handleAdvancePaper} 
                isExtraDark={isExtraDark}
                setIsExtraDark={setIsExtraDark}
                onTestDarkness={onTestDarkness}
              />
            </motion.div>
          )}</AnimatePresence>
        </Card>
      </header>

      <main className="flex-1 p-3 sm:p-4 overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeView === 'menu' && (
            <motion.div key="menu" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="grid grid-cols-2 gap-2 sm:gap-3">
              <MenuCard icon={FileText} title={t('menu.document')} color="bg-blue-50" onClick={() => setActiveView('document')} />
              <MenuCard icon={Type} title={t('menu.text')} color="bg-teal-50" onClick={() => setActiveView('editor')} />
              <MenuCard icon={ImageIcon} title={t('menu.image')} color="bg-orange-50" onClick={() => setActiveView('image')} />
              <MenuCard icon={Library} title="Şablonlar" color="bg-blue-50" onClick={() => setActiveView('templates')} />
              <MenuCard icon={QrCode} title="Araçlar" color="bg-red-50" onClick={() => setActiveView('tools')} />
              <MenuCard icon={Tag} title={t('menu.banner')} color="bg-green-50" onClick={() => setActiveView('banner')} />
              <MenuCard icon={Settings2} title="Ayarlar" color="bg-slate-100 dark:bg-slate-800" onClick={() => setIsSettingsOpen(true)} />
              <MenuCard icon={Layers} title="Kolaj" color="bg-purple-50" onClick={() => setActiveView('collage')} />
            </motion.div>
          )}

          {activeView === 'editor' && (() => {
            const textAreaStyle: React.CSSProperties = {
              fontSize: `${fontSize}px`,
              textAlign: alignment === 'justify' ? 'left' : alignment,
              fontWeight: isBold ? 'bold' : 'normal',
              fontStyle: isItalic ? 'italic' : 'normal',
              textDecoration: isUnderline ? 'underline' : 'none',
              fontFamily,
              lineHeight: 1.3
            };
            
            return (
            <motion.div key="editor" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <Button variant="ghost" size="sm" onClick={() => setActiveView('menu')} className="rounded-full text-xs"><X size={14} className="mr-1" /> {t('cancel')}</Button>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" onClick={() => setShowHtmlEditor(!showHtmlEditor)} className={`h-8 w-8 rounded-lg ${showHtmlEditor ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400' : 'text-slate-400'}`} title="HTML Şablon"><Code size={14}/></Button>
                  <Button onClick={() => generatePreview()} className="rounded-full bg-teal-600 hover:bg-teal-700 text-xs px-3 h-8">{t('print_preview')}</Button>
                </div>
              </div>
              
              {showHtmlEditor && (
                <div className="p-2 bg-indigo-50 dark:bg-indigo-950/50 rounded-xl border border-indigo-200 dark:border-indigo-800 space-y-2">
                  <div className="flex items-center gap-2 mb-1">
                    <FileCode size={12} className="text-indigo-600 dark:text-indigo-400"/>
                    <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300">HTML Editor</span>
                    <Button variant="ghost" size="sm" onClick={() => setShowHtmlEditor(false)} className="ml-auto h-5 w-5 rounded-full p-0"><X size={10}/></Button>
                  </div>
                  <textarea 
                    value={htmlTemplate}
                    onChange={(e) => setHtmlTemplate(e.target.value)}
                    className="w-full h-28 text-[10px] p-2 rounded-lg border border-indigo-200 dark:border-indigo-800 dark:bg-slate-900 dark:text-slate-200 font-mono resize-none leading-tight"
                    placeholder="Full HTML desteklenir - {{BASLIK}}, {{METIN}}, {{TARIH}} değişkenleri"
                  />
                  <div className="flex flex-wrap gap-1">
                    <Button variant="outline" size="sm" onClick={() => setHtmlTemplate(`<html><body style="text-align: center;"><h1>{{BASLIK}}</h1><p>{{METIN}}</p></body></html>`)} className="text-[9px] h-6 px-1.5 rounded">Basit</Button>
                    <Button variant="outline" size="sm" onClick={() => setHtmlTemplate(`<html><body><table style="width:100%;border:1px solid #000;border-collapse:collapse;"><tr><th style="border:1px solid #000;padding:8px;">{{BASLIK}}</th></tr><tr><td style="border:1px solid #000;padding:8px;">{{METIN}}</td></tr></table></body></html>`)} className="text-[9px] h-6 px-1.5 rounded">Tablo</Button>
                    <Button variant="outline" size="sm" onClick={() => setHtmlTemplate(`<html><body style="font-family: monospace;"><div style="border:2px solid #000;padding:10px;"><b>{{BASLIK}}</b><br>{{METIN}}<br><small>{{TARIH}}</small></div></body></html>`)} className="text-[9px] h-6 px-1.5 rounded">Kutu</Button>
                    <Button variant="outline" size="sm" onClick={() => setHtmlTemplate(`<html><body style="text-align:center;padding:20px;"><h2>{{BASLIK}}</h2><p>{{METIN}}</p><hr/><small>{{TARIH}}</small></body></html>`)} className="text-[9px] h-6 px-1.5 rounded">Resmi</Button>
                    <Button variant="outline" size="sm" onClick={() => setHtmlTemplate(`<html><body style="font-family:Arial;"><div style="background:#f5f5f5;padding:15px;border-radius:10px;"><h3>{{BASLIK}}</h3><p>{{METIN}}</p><small>{{TARIH}}</small></div></body></html>`)} className="text-[9px] h-6 px-1.5 rounded">Kart</Button>
                  </div>
                  <div className="flex items-center gap-1 flex-wrap">
                    <Label className="text-[9px] text-indigo-600 dark:text-indigo-400">Değişkenler:</Label>
                    <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{BASLIK}}'}</span>
                    <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{METIN}}'}</span>
                    <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{TARIH}}'}</span>
                    <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{SAAT}}'}</span>
                  </div>
                </div>
              )}
              
              <div className="flex flex-col items-center px-2">
                <Card className="rounded-xl border border-teal-200 dark:border-teal-800 shadow-md bg-white dark:bg-slate-900 w-full" style={{ maxWidth: `${Math.min(pageWidth, window.innerWidth - 40)}px` }}>
                  <textarea 
                    value={text} 
                    onChange={(e) => setText(e.target.value)} 
                    onSelect={(e) => {
                      const target = e.target as HTMLTextAreaElement;
                      const start = target.selectionStart;
                      const end = target.selectionEnd;
                      if (start !== end) {
                        setSelectedText(text.substring(start, end));
                      }
                    }}
                    placeholder={t('editor.placeholder')} 
                    className="w-full bg-transparent border-none focus:ring-0 resize-none p-3 dark:text-slate-200 dark:placeholder:text-slate-600 text-xs leading-relaxed"
                    style={{ ...textAreaStyle, minHeight: '100px', maxHeight: '150px' }} 
                  />
                </Card>
              </div>
              <div className="space-y-1.5 text-xs px-2">
                <div className="flex items-center justify-between"><Label className="font-bold text-slate-600 dark:text-slate-400 text-xs">Boyut</Label><span className="text-xs font-black text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30 px-2 py-0.5 rounded-full">{fontSize}px</span></div>
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="icon" className="h-6 w-6 rounded-lg dark:border-slate-700 dark:bg-slate-800" onClick={() => setFontSize(p => Math.max(12, p - 1))}><Minus size={10}/></Button>
                  <Input type="number" value={fontSize} onChange={e => setFontSize(Number(e.target.value)||24)} className="flex-1 text-center font-bold dark:bg-slate-800 dark:border-slate-700 dark:text-white h-6 text-xs" />
                  <Button variant="outline" size="icon" className="h-6 w-6 rounded-lg dark:border-slate-700 dark:bg-slate-800" onClick={() => setFontSize(p => Math.min(200, p + 1))}><Plus size={10}/></Button>
                </div>
                <div className="grid grid-cols-5 gap-1">
                  <Button variant={alignment==='left'?'default':'outline'} onClick={()=>setAlignment('left')} className="rounded-lg h-6 text-xs p-0"><AlignLeft size={12}/></Button>
                  <Button variant={alignment==='center'?'default':'outline'} onClick={()=>setAlignment('center')} className="rounded-lg h-6 text-xs p-0"><AlignCenter size={12}/></Button>
                  <Button variant={alignment==='right'?'default':'outline'} onClick={()=>setAlignment('right')} className="rounded-lg h-6 text-xs p-0"><AlignRight size={12}/></Button>
                  <Button variant={alignment==='justify'?'default':'outline'} onClick={()=>setAlignment('justify')} className="rounded-lg h-6 text-xs p-0"><AlignJustify size={12}/></Button>
                  <Button variant={isUnderline?'default':'outline'} onClick={()=>setIsUnderline(!isUnderline)} className="rounded-lg h-6 text-xs p-0"><Underline size={12}/></Button>
                </div>
                <div className="flex gap-1">
                   <Button variant={isBold?'default':'outline'} onClick={()=>setIsBold(!isBold)} className="flex-1 rounded-lg h-6 text-xs"><Bold size={10}/></Button>
                   <Button variant={isItalic?'default':'outline'} onClick={()=>setIsItalic(!isItalic)} className="flex-1 rounded-lg h-6 text-xs"><Italic size={10}/></Button>
                   <Select value={fontFamily} onValueChange={(v) => v && setFontFamily(v)}><SelectTrigger className="flex-[2] rounded-lg font-bold h-6 text-[10px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Outfit">Outfit</SelectItem><SelectItem value="JetBrains Mono">Mono</SelectItem><SelectItem value="serif">Serif</SelectItem>{customFonts.map(f => (<SelectItem key={f.name} value={f.name}>{f.name}</SelectItem>))}</SelectContent></Select>                </div>
                <div className="relative"><Button variant="outline" className="w-full rounded-lg border-dashed text-[10px] h-6">Font Yükle</Button><input type="file" accept=".ttf,.woff" onChange={handleFontUpload} title="Font Yükle" className="absolute inset-0 opacity-0 cursor-pointer"/></div>
              </div>
            </motion.div>
          );
          })()}

          {activeView === 'image' && (
            <motion.div key="image" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button>
                <Button onClick={() => generatePreview()} disabled={!selectedImage} className="rounded-full bg-teal-600 dark:bg-teal-700 text-white font-bold text-xs h-8 px-3">{t('print_preview')}</Button>
              </div>

              {isCropping ? (
                <div className="space-y-2">
                   <div className="relative h-[200px] bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-lg">
                      <div className="absolute top-2 right-2 z-30 flex gap-1">
                        <Button variant="ghost" onClick={() => setUseArchitect(!useArchitect)} className={`h-6 rounded-lg px-2 text-[9px] font-black border transition-all ${useArchitect ? 'bg-teal-500 text-white border-teal-400 shadow-lg' : 'bg-white/10 text-white/70 border-white/10'}`}>
                          {useArchitect ? 'MİMAR' : 'MİMARA'}
                        </Button>
                      </div>

                      {useArchitect ? (
                        <div className="w-full h-full flex justify-center items-center bg-slate-200 dark:bg-slate-950 overflow-hidden ring-4 ring-inset ring-slate-800/20">
                           <ArchitectWorkspace 
                             image={selectedImage!} 
                             crops={activeMultiCrops} 
                             onSync={setActiveMultiCrops} 
                             parentFabricRef={fabricRef}
                           />
                        </div>
                      ) : selectedZoneId ? (
                        <Cropper 
                          image={selectedImage!} 
                          crop={crop} 
                          zoom={zoom} 
                          aspect={isFreeCrop ? undefined : (activeMultiCrops.find(z => z.id === selectedZoneId)?.width! / activeMultiCrops.find(z => z.id === selectedZoneId)?.height!)} 
                          onCropChange={setCrop} 
                          onCropComplete={onCropComplete} 
                          onZoomChange={setZoom} 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
                           <img 
                             src={selectedImage!} 
                             alt="Full Preview" 
                                 className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
                                 style={{ pointerEvents: 'none' }}
                               />
                            </div>
                         )}
                      
                      {/* Ghost Frames Overlay (Only in simple mode) */}
                      {!useArchitect && (
                        <div className="absolute inset-0 pointer-events-none overflow-hidden">
                          {activeMultiCrops.map((zone, idx) => {
                            if (!zone.percent) return null;
                            const isActive = zone.id === selectedZoneId;
                            return (
                              <div 
                                key={zone.id}
                                className={`absolute cursor-crosshair pointer-events-auto transition-all duration-300 rounded-sm ${isActive ? 'border-4 border-teal-500 bg-teal-500/10 shadow-2xl z-20' : 'border-2 border-dashed border-white/40 bg-white/5 z-10'}`}
                                style={{
                                  left: `${zone.percent.x}%`,
                                  top: `${zone.percent.y}%`,
                                  width: `${zone.percent.width}%`,
                                  height: `${zone.percent.height}%`,
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedZoneId(zone.id);
                                  if (zone.percent) {
                                     setCrop({ x: zone.percent.x + zone.percent.width / 2 - 50, y: zone.percent.y + zone.percent.height / 2 - 50 });
                                     setZoom(Math.max(1, 100 / Math.max(zone.percent.width, zone.percent.height) * 0.8));
                                  }
                                }}
                              >
                                <div className={`absolute top-0 left-0 -translate-y-full flex items-center gap-1 px-1.5 py-0.5 rounded-t-md text-[9px] font-black shadow-sm ${isActive ? 'bg-teal-500 text-white' : 'bg-white/20 text-white/70'}`}>
                                  <Layers size={10}/> BÖLGE #{idx + 1}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                   </div>

                   <div className="flex flex-col gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
                     {/* Controls Grid */}
                     <div className="grid grid-cols-2 gap-3">
                        <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 p-3 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <Label className="text-[10px] font-black text-slate-500 uppercase">Serbest Kırpma</Label>
                          <Switch checked={isFreeCrop} onCheckedChange={setIsFreeCrop} />
                        </div>
                        {!isFreeCrop && (
                          <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-950 p-3 rounded-2xl border border-slate-100 dark:border-slate-800">
                            <Label className="text-[10px] font-black text-slate-500 uppercase">Oran Kilidi</Label>
                            <Button variant="ghost" size="icon" onClick={() => setCropLocked(p => !p)} className={`h-6 w-6 rounded-lg ${cropLocked ? 'bg-amber-100 text-amber-700' : 'text-slate-400'}`}>
                              {cropLocked ? <Lock size={12} /> : <Unlock size={12} />}
                            </Button>
                          </div>
                        )}
                     </div>

                     {!isFreeCrop && (
                       <div className="grid grid-cols-2 gap-3">
                         <div className="space-y-1.5">
                           <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Genişlik (px)</Label>
                           <Input type="number" value={cropCustomW} onChange={e => { const nw = Number(e.target.value) || 384; if (cropLocked) setCropCustomH(Math.round(nw * cropCustomH / cropCustomW)); setCropCustomW(nw); }} className="h-10 rounded-xl bg-slate-50 dark:bg-slate-950 border-none font-black text-center" />
                         </div>
                         <div className="space-y-1.5">
                           <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Yükseklik (px)</Label>
                           <Input type="number" value={cropCustomH} onChange={e => { const nh = Number(e.target.value) || 200; if (cropLocked) setCropCustomW(Math.round(nh * cropCustomW / cropCustomH)); setCropCustomH(nh); }} className="h-10 rounded-xl bg-slate-50 dark:bg-slate-950 border-none font-black text-center" />
                         </div>
                       </div>
                     )}

                      {/* Zoom */}
                      <div className="flex items-center justify-between">
                        <Label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">Yakınlaştırma (Zoom)</Label>
                        <div className="flex items-center gap-1">
                          <Button variant="outline" size="icon" className="h-8 w-8 rounded-xl shadow-sm dark:bg-slate-900 dark:border-slate-800" onClick={() => setZoom(p => Math.max(1, +(p - 0.1).toFixed(1)))}><Minus size={14}/></Button>
                          <Input type="number" step="0.1" value={zoom} onChange={e => setZoom(Number(e.target.value)||1)} className="w-14 h-8 text-center text-xs font-black p-0 border-none bg-slate-50 dark:bg-slate-900 dark:text-teal-400" />
                          <Button variant="outline" size="icon" className="h-8 w-8 rounded-xl shadow-sm dark:bg-slate-900 dark:border-slate-800" onClick={() => setZoom(p => Math.min(5, +(p + 0.1).toFixed(1)))}><Plus size={14}/></Button>
                        </div>
                      </div>

                      {/* Professional Multi-Crop Architect */}
                       <div className="bg-teal-50/50 dark:bg-slate-950/20 p-4 rounded-3xl border-2 border-slate-200 dark:border-slate-800 border-dashed space-y-3">
                         <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <Label className="text-[11px] font-black text-slate-800 dark:text-teal-400 uppercase tracking-widest flex items-center gap-1.5"><Layers size={14} className="text-teal-600"/> Bölgeler ({activeMultiCrops.length})</Label>
                              <div className="flex items-center gap-2 mt-0.5">
                                <Switch checked={useArchitect} onCheckedChange={(v) => { setUseArchitect(v); if(v) setIsCropping(true); }} className="data-[state=checked]:bg-indigo-600 h-4 w-7" />
                                <span className="text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase italic">Architect Mode</span>
                              </div>
                            </div>
                            <div className="flex gap-1.5">
                              {activeMultiCrops.length > 0 && (
                                <Button size="sm" onClick={saveCurrentCrop} className="h-7 px-2 text-[9px] bg-amber-500/10 text-amber-600 border border-amber-200 rounded-xl font-bold hover:bg-amber-50 shadow-none"><Save size={12} className="mr-1"/> KAYDET</Button>
                              )}
                              {useArchitect ? (
                                <Button size="sm" onClick={addArchitectZone} className="h-7 text-[10px] bg-indigo-600 text-white rounded-xl font-black shadow-lg shadow-indigo-100">+ YENİ ALAN</Button>
                              ) : (
                                selectedZoneId ? (
                                  <Button size="sm" onClick={updateCropZone} className="h-7 text-[10px] bg-emerald-500 text-white rounded-xl font-black shadow-lg shadow-emerald-100 italic">GÜNCELLE</Button>
                                ) : (
                                  <Button size="sm" onClick={addCropZone} className="h-7 text-[10px] bg-teal-600 text-white rounded-xl font-black shadow-lg shadow-teal-100">+ EKLE</Button>
                                )
                              )}
                            </div>
                         </div>
                         
                         <div className="flex bg-white dark:bg-slate-900 shadow-inner p-1 rounded-2xl border border-slate-100 dark:border-slate-800">
                             <Button variant={multiCropLayout === 'vertical' ? 'default' : 'ghost'} size="sm" onClick={() => setMultiCropLayout('vertical')} className={`flex-1 h-8 rounded-xl text-[10px] font-black gap-1.5 ${multiCropLayout === 'vertical' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400'}`}><ChevronDown size={14}/> DIKEY</Button>
                             <Button variant={multiCropLayout === 'horizontal' ? 'default' : 'ghost'} size="sm" onClick={() => setMultiCropLayout('horizontal')} className={`flex-1 h-8 rounded-xl text-[10px] font-black gap-1.5 ${multiCropLayout === 'horizontal' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400'}`}><ChevronUp size={14} className="rotate-90"/> YATAY</Button>
                             <Button variant={multiCropLayout === 'grid' ? 'default' : 'ghost'} size="sm" onClick={() => setMultiCropLayout('grid')} className={`flex-1 h-8 rounded-xl text-[10px] font-black gap-1.5 ${multiCropLayout === 'grid' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-400'}`}><Layout size={14}/> GRID</Button>
                         </div>
                         <ScrollArea className={activeMultiCrops.length > 0 ? "h-32 w-full" : "h-0"}>
                           <div className="space-y-2 pr-2">
                             {activeMultiCrops.map((zone, idx) => (
                               <div 
                                 key={zone.id} 
                                 onClick={() => {
                                   setSelectedZoneId(zone.id === selectedZoneId ? null : zone.id);
                                   if (useArchitect && fabricRef.current) {
                                      const obj = fabricRef.current.getObjects('rect').find(o => (o as any).data?.id === zone.id);
                                      if (obj) { fabricRef.current.setActiveObject(obj); fabricRef.current.renderAll(); }
                                   } else if (zone.percent) {
                                      // Sync back to simple cropper: calculate crop and zoom to match this percent
                                      // This is a rough estimation but good for focus
                                      setCrop({ x: zone.percent.x + zone.percent.width / 2 - 50, y: zone.percent.y + zone.percent.height / 2 - 50 });
                                      setZoom(Math.max(1, 100 / Math.max(zone.percent.width, zone.percent.height) * 0.8));
                                      setIsCropping(true);
                                   }
                                 }}
                                 className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${selectedZoneId === zone.id ? 'bg-teal-600 border-teal-600 text-white shadow-lg' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-300'}`}
                               >
                                 <div className="flex items-center gap-3">
                                   <span className={`text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center ${selectedZoneId === zone.id ? 'bg-white/20' : 'bg-slate-100 dark:bg-slate-800'}`}>{idx + 1}</span>
                                   <div className="flex flex-col">
                                      <span className="text-[10px] font-black uppercase tracking-tight">({Math.round(zone.width)}x{Math.round(zone.height)}px)</span>
                                      {zone.rotation && zone.rotation !== 0 && <span className="text-[8px] font-bold opacity-70">⟳ {Math.round(zone.rotation)}°</span>}
                                   </div>
                                 </div>
                                 <div className="flex items-center gap-1">
                                   <Button variant="ghost" size="icon" className={`h-7 w-7 rounded-lg ${selectedZoneId === zone.id ? 'text-white hover:bg-white/10' : 'text-red-400 hover:bg-red-50'}`} onClick={(e) => { e.stopPropagation(); 
                                      removeCropZone(zone.id);
                                      if (useArchitect && fabricRef.current) {
                                        const obj = fabricRef.current.getObjects('rect').find(o => (o as any).data?.id === zone.id);
                                        if (obj) { fabricRef.current.remove(obj); fabricRef.current.renderAll(); }
                                      }
                                   }}><Trash2 size={13}/></Button>
                                 </div>
                               </div>
                             ))}
                           </div>
                         </ScrollArea>
                         {activeMultiCrops.length === 0 && <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center italic py-2 font-medium">Henüz bir kəsim bölgesi tanımlanmadı.</p>}
                       </div>

                      <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
                        <div className="flex justify-between items-center px-1"><Label className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Kayıtlı Multi-Profiller</Label><Button variant="ghost" size="sm" onClick={saveCurrentCrop} className="h-7 px-3 text-[10px] text-teal-700 bg-white dark:bg-slate-900 border border-teal-100 dark:border-slate-800 rounded-xl font-black hover:bg-teal-50 shadow-sm transition-all active:scale-95">PROFİLİ KAYDET</Button></div>
                        <ScrollArea className="h-32 w-full">
                          <div className="grid grid-cols-1 gap-2.5 pr-2">
                            {savedCrops.map(sc => (
                              <div key={sc.id} onClick={() => { setActiveProfileId(sc.id); setActiveMultiCrops(sc.crops.map(c => ({...c, id: Math.random().toString(36).substr(2,9)}))); }} className={`group flex items-center justify-between p-3.5 rounded-[1.5rem] border-2 cursor-pointer transition-all ${activeProfileId === sc.id ? 'border-teal-500 bg-teal-50 dark:bg-teal-900/10 shadow-md ring-2 ring-teal-500/10' : 'border-slate-50 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-200 dark:hover:border-slate-700'}`}>
                                <div className="flex flex-col">
                                  <span className="text-[11px] font-black text-slate-800 dark:text-slate-200 uppercase tracking-tight">{sc.name}</span>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[9px] font-black bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-300 px-1.5 py-0.5 rounded-md">{sc.crops.length} BÖLGE</span>
                                    {sc.crops.length > 0 && <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500">({sc.crops[0].width}px Genişlik)</span>}
                                  </div>
                                </div>
                                <div className="flex items-center gap-1">
                                   <Button variant="ghost" size="icon" className="h-8 w-8 text-red-300 hover:text-white hover:bg-red-500 opacity-0 group-hover:opacity-100 transition-all rounded-xl" onClick={(e) => { e.stopPropagation(); deleteSavedProfile(sc.id); }}><Trash2 size={14}/></Button>
                                   <div className={`p-1.5 rounded-full ${activeProfileId === sc.id ? 'bg-teal-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-transparent'}`}><Check size={12} /></div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                   </div>
                   <div className="flex gap-3 mt-4">
                     <Button variant="outline" onClick={() => {
                        setIsCropping(false);
                        setSelectedImage(null);
                        setActiveView('menu');
                        logger.info('Kırpma iptal edildi');
                     }} className="flex-1 rounded-2xl h-12 shadow-sm font-bold text-slate-600 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800">İptal</Button>
                     <Button onClick={applyCrop} className="flex-1 rounded-2xl h-12 bg-teal-600 shadow-xl shadow-teal-100 dark:shadow-teal-900/20 font-bold text-lg text-white">Onayla</Button>
                   </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <Card className="p-8 rounded-3xl border-dashed border-2 border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/50 backdrop-blur flex flex-col items-center justify-center min-h-[350px] transition-all hover:bg-white dark:hover:bg-slate-900 relative">
                    {selectedImage ? (
                      <div className="text-center w-full">
                         <img src={selectedImage} alt="Selected" className="max-h-[250px] rounded-2xl shadow-2xl mx-auto mb-6 transition-transform hover:scale-105" />
                         <div className="absolute top-4 left-4 flex gap-2">
                            <Button 
                              variant="ghost" 
                              onClick={handleRemoveBackground} 
                              disabled={isRemovingBg}
                              className="rounded-full bg-white dark:bg-slate-800 shadow-xl border border-slate-100 dark:border-slate-700 h-10 px-4 font-black text-[10px] gap-2 transition-all active:scale-95"
                            >
                              {isRemovingBg ? <Loader2 size={16} className="animate-spin text-teal-600"/> : <Sparkles size={16} className="text-amber-500 fill-amber-500"/>}
                              {isRemovingBg ? 'TEMİZLENİYOR...' : 'ARKAPLAN SİL'}
                            </Button>
                            <Button 
                              variant="ghost" 
                              onClick={handleOCR} 
                              disabled={isOcrLoading}
                              className="rounded-full bg-white dark:bg-slate-800 shadow-xl border border-slate-100 dark:border-slate-700 h-10 px-4 font-black text-[10px] gap-2 transition-all active:scale-95"
                            >
                              {isOcrLoading ? <Loader2 size={16} className="animate-spin text-teal-600"/> : <OcrIcon size={16} className="text-blue-500"/>}
                              {isOcrLoading ? 'OKUNUYOR...' : 'METNİ TANI (OCR)'}
                            </Button>
                            <Button 
                              variant="ghost" 
                              onClick={resetProject} 
                              className="rounded-full bg-white dark:bg-slate-800 shadow-xl border border-slate-100 dark:border-slate-700 h-10 px-4 font-black text-[10px] gap-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all active:scale-95 uppercase"
                            >
                              <Trash2 size={16}/> PROJEYİ TEMİZLE
                            </Button>
                         </div>
                      </div>
                    ) : (
                      <div className="text-center animate-pulse">
                         <div className="bg-slate-100 dark:bg-slate-800 p-6 rounded-3xl inline-block mb-4"><ImageIcon size={64} className="text-teal-200 dark:text-teal-900" /></div>
                         <p className="text-slate-500 dark:text-slate-400 font-extrabold uppercase tracking-tighter">Görsel Seçin veya Panodan Yapıştırın</p>
                      </div>
                    )}
                    <div className="relative mt-4">
                      <Button variant="default" className="rounded-2xl h-14 px-10 font-black bg-slate-900 dark:bg-white dark:text-slate-900 text-white shadow-2xl transition-all hover:translate-y-[-2px]">
                        {selectedImage ? "Görseli Değiştir" : "Görsel Yükle / Seç"}
                      </Button>
                      <input type="file" accept="image/*" onChange={handleImageSelect} title="Görsel Seç" className="absolute inset-0 opacity-0 cursor-pointer"/>
                    </div>
                  </Card>

                  {selectedImage && (
                    <div className="grid grid-cols-3 gap-3">
                       <Button onClick={() => { setCroppedAreaPixels(null); generatePreview(); }} className="flex flex-col h-24 rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/20 shadow-sm transition-all group p-2">
                          <Maximize2 size={24} className="mb-2 text-slate-400 group-hover:text-teal-600" />
                          <span className="text-[10px] font-black uppercase">Tam Sayfa</span>
                       </Button>
                       <Button onClick={() => { setCropCustomW(384); setCropCustomH(200); setIsFreeCrop(false); setIsCropping(true); }} className="flex flex-col h-24 rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/20 shadow-sm transition-all group p-2">
                          <Layout size={24} className="mb-2 text-slate-400 group-hover:text-teal-600" />
                          <span className="text-[10px] font-black uppercase">Standart</span>
                       </Button>
                       <Button onClick={() => { setIsFreeCrop(true); setIsCropping(true); }} className="flex flex-col h-24 rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-teal-500 hover:bg-teal-50 dark:hover:bg-teal-900/20 shadow-sm transition-all group p-2">
                          <Zap size={24} className="mb-2 text-slate-400 group-hover:text-teal-600" />
                          <span className="text-[10px] font-black uppercase">Özel (Multi)</span>
                       </Button>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {activeView === 'document' && (
            <motion.div key="document" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
              <div className="flex items-center justify-between">
                <Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 shadow-sm dark:text-slate-200"><X size={20} className="mr-2" /> {t('cancel')}</Button>
                <Button onClick={() => generatePreview()} disabled={pdfFiles.length === 0} className="rounded-2xl bg-teal-600 dark:bg-teal-700 text-white shadow-lg font-bold px-6">{t('print_preview')}</Button>
              </div>

              {pdfFiles.length === 0 ? (
                <Card className="p-8 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 flex flex-col items-center justify-center min-h-[250px] transition-all hover:bg-white dark:hover:bg-slate-900 overflow-hidden">
                  <div className="relative group cursor-pointer text-center">
                    <div className="bg-slate-100 dark:bg-slate-800 p-6 rounded-3xl inline-block mb-4 group-hover:bg-teal-50 dark:group-hover:bg-teal-900/20 transition-colors">
                      <FileText size={64} className="text-slate-400 dark:text-slate-600 group-hover:text-teal-500" />
                    </div>
                    <p className="font-black text-slate-500 dark:text-slate-400 uppercase tracking-tighter">PDF veya Metin Belgesi Seç</p>
                    <input type="file" accept=".pdf,.txt" onChange={handlePdfSelect} title="Dosya Seç" className="absolute inset-0 opacity-0 cursor-pointer"/>
                  </div>
                </Card>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-2">
                    <Label className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Belge Listesi ({pdfFiles.length})</Label>
                    <div className="relative">
                      <Button variant="outline" size="sm" className="h-8 rounded-xl bg-teal-50 text-teal-600 border-teal-100 font-bold">+ Ekle</Button>
                      <input type="file" accept=".pdf,.txt" onChange={handlePdfSelect} title="Dosya Ekle" className="absolute inset-0 opacity-0 cursor-pointer"/>
                    </div>
                  </div>
                  
                  <ScrollArea className="h-40 w-full rounded-2xl border border-slate-100 bg-slate-50/50 p-2">
                    <div className="space-y-2">
                      {pdfFiles.map((file, idx) => (
                        <div key={idx} onClick={() => setActivePdfIndex(idx)} className={`flex items-center gap-2 p-3 rounded-xl border transition-all cursor-pointer ${activePdfIndex === idx ? 'bg-white border-teal-200 shadow-sm ring-1 ring-teal-100' : 'bg-transparent border-transparent hover:bg-white/50'}`}>
                          <div className={`p-2 rounded-lg ${activePdfIndex === idx ? 'bg-teal-500 text-white' : 'bg-slate-200 text-slate-500'}`}><FileText size={16} /></div>
                          <div className="flex-1 min-w-0"><p className="text-xs font-bold text-slate-700 truncate">{file.name}</p><p className="text-[10px] text-slate-400 font-medium">{(file.size/1024).toFixed(1)} KB</p></div>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-teal-600" onClick={(e) => { e.stopPropagation(); movePdf(idx, 'up'); }} disabled={idx === 0}><ChevronUp size={14}/></Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-teal-600" onClick={(e) => { e.stopPropagation(); movePdf(idx, 'down'); }} disabled={idx === pdfFiles.length - 1}><ChevronDown size={14}/></Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-300 hover:text-red-500" onClick={(e) => { e.stopPropagation(); setPdfFiles(prev => prev.filter((_, i) => i !== idx)); if(activePdfIndex >= idx) setActivePdfIndex(prev => Math.max(0, prev - 1)); }}><Trash2 size={14}/></Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 space-y-6">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-50 dark:border-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black text-teal-600 uppercase">Yazdırma Sırası</span>
                        <div className="flex items-center gap-1 ml-2 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full cursor-pointer hover:bg-teal-50 dark:hover:bg-teal-900/30" onClick={() => setPrintAllFiles(!printAllFiles)}>
                           <div className={`w-3 h-3 rounded-full border border-slate-300 dark:border-slate-700 flex items-center justify-center ${printAllFiles ? 'bg-teal-500 border-teal-500' : 'bg-white dark:bg-slate-900'}`}>{printAllFiles && <Check size={8} className="text-white" />}</div>
                           <span className="text-[9px] font-bold text-slate-500 dark:text-slate-400">Kuyruğu Yazdır</span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" onClick={startPdfCrop} className="h-8 rounded-xl border-red-200 dark:border-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/10 font-bold px-4 gap-2">✂️ Sayfayı Kırp</Button>
                    </div>

                    {/* PDF Automation/Profile Selector */}
                    {savedCrops.length > 0 && (
                      <div className="space-y-2">
                         <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kırpma Otomasyonu (Profil Seç)</Label>
                         <div className="flex gap-2 flex-wrap">
                            {savedCrops.map(profile => (
                              <Button 
                                key={profile.id} 
                                variant="outline" 
                                size="sm" 
                                onClick={async () => {
                                  await startPdfCrop();
                                  applySavedProfile(profile.id);
                                }}
                                className={`h-8 rounded-xl border-dashed text-[10px] font-bold ${activeProfileId === profile.id ? 'bg-teal-50 border-teal-500 text-teal-600 dark:bg-teal-900/20' : 'bg-slate-50 dark:bg-slate-900 dark:border-slate-800 text-slate-500'}`}
                              >
                                {profile.name}
                              </Button>
                            ))}
                         </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4 pt-2">
                       <div className="space-y-2">
                          <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kopya Sayısı</Label>
                          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-1 rounded-2xl">
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl dark:text-slate-300" onClick={()=>setPrintCopies(Math.max(1, printCopies-1))}><Minus size={14}/></Button>
                            <Input type="number" value={printCopies} onChange={e=>setPrintCopies(Math.max(1, parseInt(e.target.value)||1))} className="flex-1 border-none bg-transparent text-center font-bold h-8 p-0 dark:text-white" />
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl dark:text-slate-300" onClick={()=>setPrintCopies(printCopies+1)}><Plus size={14}/></Button>
                          </div>
                       </div>
                       <div className="space-y-2">
                          <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ölçeklenme (%)</Label>
                          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-1 rounded-2xl">
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl dark:text-slate-300" onClick={()=>setPdfScale(Math.max(0.1, +(pdfScale-0.1).toFixed(1)))}><Minus size={14}/></Button>
                            <span className="flex-1 text-center font-bold text-sm dark:text-white">%{Math.round(pdfScale*100)}</span>
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-xl dark:text-slate-300" onClick={()=>setPdfScale(Math.min(5, +(pdfScale+0.1).toFixed(1)))}><Plus size={14}/></Button>
                          </div>
                       </div>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sayfa Aralığı / Döndürme</Label>
                      <div className="flex items-center gap-3">
                        <Input value={pdfPageRange} onChange={e=>setPdfPageRange(e.target.value)} placeholder="Örn: 1,2,5" className="rounded-2xl bg-slate-50 dark:bg-slate-800 dark:text-white border-none font-bold h-11" />
                        <Button variant="outline" onClick={()=>setPdfRotation(r => (r + 90) % 360)} className="rounded-2xl h-11 px-4 border-slate-200 dark:border-slate-700 dark:text-slate-300"><RotateCw size={18} /></Button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeView === 'banner' && (
            <motion.div key="banner" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
              <div className="flex items-center justify-between"><Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 shadow-sm dark:text-slate-200 text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button><Button onClick={() => generatePreview()} disabled={!bannerText} className="rounded-full bg-teal-600 dark:bg-teal-700 text-white font-bold text-xs h-8 px-3">{t('print_preview')}</Button></div>
              <Card className="p-4 rounded-2xl border-none shadow-md bg-white/90 dark:bg-slate-900/90">
                <Input value={bannerText} onChange={e => setBannerText(e.target.value)} placeholder="YAZI GİRİN" className="w-full bg-transparent border-none text-xl font-black text-center uppercase tracking-widest placeholder:text-slate-300 dark:placeholder:text-slate-700 dark:text-white focus-visible:ring-0" />
              </Card>
              
              <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-bold text-slate-400">Karakter Büyüklüğü</Label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg dark:border-slate-700" onClick={() => setBannerFontSize(p => Math.max(12, p - 4))}><Minus size={14}/></Button>
                    <Input type="number" value={bannerFontSize} onChange={e => setBannerFontSize(Number(e.target.value)||48)} className="flex-1 text-center font-bold h-8 text-sm bg-slate-50 dark:bg-slate-800 border-none dark:text-white" />
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg dark:border-slate-700" onClick={() => setBannerFontSize(p => Math.min(400, p + 4))}><Plus size={14}/></Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label className="text-[9px] font-bold text-slate-400">Mod</Label>
                    <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                      <Button variant={bannerType === 'banner' ? 'default' : 'ghost'} onClick={() => setBannerType('banner')} className={`flex-1 rounded h-7 text-[10px] font-bold ${bannerType === 'banner' ? 'bg-white dark:bg-slate-700' : 'text-slate-500'}`}>Banner</Button>
                      <Button variant={bannerType === 'etiket' ? 'default' : 'ghost'} onClick={() => setBannerType('etiket')} className={`flex-1 rounded h-7 text-[10px] font-bold ${bannerType === 'etiket' ? 'bg-white dark:bg-slate-700' : 'text-slate-500'}`}>Etiket</Button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[9px] font-bold text-slate-400">Yön</Label>
                    <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                      <Button variant={bannerOrientation === 'horizontal' ? 'default' : 'ghost'} onClick={() => setBannerOrientation('horizontal')} className={`flex-1 rounded h-7 text-[10px] font-bold ${bannerOrientation === 'horizontal' ? 'bg-white dark:bg-slate-700' : 'text-slate-500'}`}>Yatay</Button>
                      <Button variant={bannerOrientation === 'vertical' ? 'default' : 'ghost'} onClick={() => setBannerOrientation('vertical')} className={`flex-1 rounded h-7 text-[10px] font-bold ${bannerOrientation === 'vertical' ? 'bg-white dark:bg-slate-700' : 'text-slate-500'}`}>Dikey</Button>
                    </div>
                  </div>
                </div>
              </div>

              {previewImage && <div className="p-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl flex flex-col items-center overflow-hidden"><img src={previewImage} alt="Preview" className="max-w-full h-auto" /></div>}
            </motion.div>
          )}

          {activeView === 'collage' && (
            <motion.div key="collage" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-2">
              <div className="flex items-center justify-between">
                <Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 shadow-sm dark:text-slate-200 text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button>
              </div>
              <CollageEditor 
                pageWidth={pageWidth} 
                onPreview={(img) => { 
                  setPreviewImage(img); 
                  const canvas = canvasRef.current;
                  if (canvas) {
                    const ctx = canvas.getContext('2d');
                    const imageObj = new Image();
                    imageObj.onload = () => {
                      canvas.width = imageObj.width;
                      canvas.height = imageObj.height;
                      ctx?.drawImage(imageObj, 0, 0);
                      setIsPreviewOpen(true);
                    };
                    imageObj.src = img;
                  }
                }} 
              />
            </motion.div>
          )}

          {activeView === 'tools' && (
            <motion.div key="tools" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              <div className="flex items-center justify-between">
                <Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 shadow-sm dark:text-slate-200 text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button>
              </div>
              <QRGenerator 
                onGenerate={(img) => {
                  setSelectedImage(img);
                  setActiveView('image');
                  logger.info('QR/Barkod oluşturuldu ve görsele aktarıldı');
                }} 
              />
            </motion.div>
          )}

          {activeView === 'templates' && (
            <motion.div key="templates" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              <div className="flex items-center justify-between">
                <Button variant="ghost" onClick={() => setActiveView('menu')} className="rounded-full bg-white dark:bg-slate-900 shadow-sm dark:text-slate-200 text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button>
              </div>
              <TemplateLibrary 
                onSelect={(template) => {
                  if (template.type === 'editor') {
                    setText(template.content);
                    setActiveView('editor');
                  } else if (template.type === 'tools') {
                    setActiveView('tools');
                  }
                  logger.info(`${template.name} şablonu seçildi`);
                }} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>

      <Dialog open={showDiagnostics} onOpenChange={setShowDiagnostics}>
        <DialogContent className="max-w-sm mx-3 rounded-2xl p-3 border-none shadow-xl dark:bg-slate-950 dark:border-slate-800">
          <DiagnosticsPanel 
            printer={printer} 
            isConnected={isConnected} 
            onSwitchChannel={handleSwitchChannel}
            feedAmount={feedAmount}
            setFeedAmount={setFeedAmount}
            onAdvancePaper={handleAdvancePaper}
            isExtraDark={isExtraDark}
            setIsExtraDark={setIsExtraDark}
            onTestDarkness={onTestDarkness}
          />
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
        <DialogContent className="max-w-xs mx-4 rounded-xl p-3 overflow-hidden shadow-xl border-0 bg-white dark:bg-slate-950 max-h-[85vh]">
          <DialogHeader className="pb-2 border-b border-slate-100 dark:border-slate-800">
            <DialogTitle className="font-bold flex items-center gap-2 text-sm text-slate-800 dark:text-slate-100">
              <Settings2 className="text-indigo-600 dark:text-indigo-400" size={16} /> Ayarlar
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[55vh]">
            <div className="p-2 space-y-2 bg-slate-50/50 dark:bg-slate-950/50">
                {/* 1. Sayfa Başı ve Sonu Boşluk */}
                <div className="p-3 bg-teal-500 dark:bg-teal-600 rounded-xl shadow-lg space-y-4">
                   <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-[10px] font-bold text-white uppercase">Çıktı Başı Boşluk</Label>
                        <span className="text-[9px] font-bold text-teal-600 bg-white px-1.5 py-0.5 rounded-full">{prePrintFeed} Birim</span>
                      </div>
                      <div className="flex items-center gap-1">
                         <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 bg-white/20 text-white hover:bg-white/30 rounded-lg" onClick={() => setPrePrintFeed(p => Math.max(0, p - 10))}><Minus size={12}/></Button>
                         <Slider value={[prePrintFeed]} onValueChange={(v) => Array.isArray(v) && setPrePrintFeed(v[0])} max={100} step={5} className="flex-1" />
                         <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 bg-white/20 text-white hover:bg-white/30 rounded-lg" onClick={() => setPrePrintFeed(p => Math.min(100, p + 10))}><Plus size={12}/></Button>
                      </div>
                   </div>
                   <div className="space-y-2 border-t border-white/20 pt-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-[10px] font-bold text-white uppercase">Çıktı Sonu Boşluk</Label>
                        <span className="text-[9px] font-bold text-teal-600 bg-white px-1.5 py-0.5 rounded-full">{postPrintFeed} Birim</span>
                      </div>
                      <div className="flex items-center gap-1">
                         <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 bg-white/20 text-white hover:bg-white/30 rounded-lg" onClick={() => setPostPrintFeed(p => Math.max(0, p - 10))}><Minus size={12}/></Button>
                         <Slider value={[postPrintFeed]} onValueChange={(v) => Array.isArray(v) && setPostPrintFeed(v[0])} max={100} step={5} className="flex-1" />
                         <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 bg-white/20 text-white hover:bg-white/30 rounded-lg" onClick={() => setPostPrintFeed(p => Math.min(100, p + 10))}><Plus size={12}/></Button>
                      </div>
                   </div>
                </div>
               
                {/* 2. Gecikme */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between"><Label className="text-[9px] font-bold text-slate-500 dark:text-slate-400">Gecikme</Label><span className="text-[8px] font-bold bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 px-1.5 py-0.5 rounded">{printDelay} ms</span></div>
                  <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-100 dark:border-slate-800">
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" onClick={() => setPrintDelay(p => Math.max(0, p - 1))}><Minus size={12}/></Button>
                    <Input type="number" value={printDelay} onChange={e => setPrintDelay(Number(e.target.value)||0)} className="flex-1 text-center font-bold text-xs border-none bg-transparent dark:text-white h-7" />
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" onClick={() => setPrintDelay(p => Math.min(100, p + 1))}><Plus size={12}/></Button>
                  </div>
                </div>
                
                {/* 3. Hassas Koyuluk */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between"><Label className="text-[9px] font-bold text-slate-500 dark:text-slate-400">Koyuluk</Label><span className="text-[8px] font-bold bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 px-1.5 py-0.5 rounded">%{darkness}</span></div>
                  <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-100 dark:border-slate-800">
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" onClick={() => setDarkness(p => Math.max(0, p - 5))}><Minus size={12}/></Button>
                    <Input type="number" value={darkness} onChange={e => setDarkness(Number(e.target.value)||0)} className="flex-1 text-center font-bold text-xs border-none bg-transparent text-teal-700 dark:text-teal-400 h-7" />
                    <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" onClick={() => setDarkness(p => Math.min(100, p + 5))}><Plus size={12}/></Button>
                  </div>
                </div>

                {/* 4. Sayfa Boyutu */}
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800">
                  <Label className="text-[9px] font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider block mb-2 flex items-center gap-1"><Layout size={14} className="text-slate-400"/> Sayfa Boyutu</Label>
                  <div className="flex gap-1.5 mb-2">
                    <Button variant={pageWidth===384 ? 'default' : 'outline'} size="sm" onClick={()=>setPageWidth(384)} className="flex-1 text-[9px] h-8 rounded-lg font-bold dark:border-slate-700 border">57mm</Button>
                    <Button variant={pageWidth===576 ? 'default' : 'outline'} size="sm" onClick={()=>setPageWidth(576)} className="flex-1 text-[9px] h-8 rounded-lg font-bold border dark:border-slate-700">80mm</Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-0.5">
                      <Label className="text-[8px] font-bold text-slate-400 uppercase">Genişlik</Label>
                      <div className="flex items-center gap-0.5 bg-slate-50 dark:bg-slate-800 p-0.5 rounded-lg">
                        <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg dark:text-slate-400" onClick={() => setPageWidth(p => Math.max(128, p - 8))}><Minus size={10}/></Button>
                        <Input type="number" value={pageWidth} onChange={e => {
                          const val = Number(e.target.value) || 384;
                          setPageWidth(Math.ceil(val / 8) * 8);
                        }} className="flex-1 text-center font-black text-xs h-6 px-0.5 border-none bg-transparent dark:text-white" />
                        <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg dark:text-slate-400" onClick={() => setPageWidth(p => p + 8)}><Plus size={10}/></Button>
                      </div>
                    </div>
                    <div className="space-y-0.5">
                      <Label className="text-[8px] font-bold text-slate-400 uppercase">Uzunluk</Label>
                      <div className="flex items-center gap-0.5 bg-slate-50 dark:bg-slate-800 p-0.5 rounded-lg">
                        <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg dark:text-slate-400" onClick={() => setPageHeight(p => Math.max(0, p - 10))}><Minus size={10}/></Button>
                        <Input type="number" value={pageHeight} onChange={e => setPageHeight(Number(e.target.value)||0)} className="flex-1 text-center font-black text-xs h-6 px-0.5 border-none bg-transparent dark:text-white" />
                        <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg dark:text-slate-400" onClick={() => setPageHeight(p => p + 10)}><Plus size={10}/></Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 5. Dithering Profil */}
                <div className="space-y-1"><Label className="text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">Dithering</Label>
                  <Select value={dithering} onValueChange={(v:any)=>setDithering(v)}>
                    <SelectTrigger className="rounded-xl h-9 text-xs font-bold bg-white dark:bg-slate-900 shadow-sm border-slate-200 dark:border-slate-800 dark:text-slate-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl shadow-lg dark:bg-slate-950 dark:border-slate-800">
                      <SelectItem value="floyd-steinberg" className="text-xs font-medium dark:text-slate-200">Floyd-Steinberg</SelectItem>
                      <SelectItem value="atkinson" className="text-xs font-medium dark:text-slate-200">Atkinson</SelectItem>
                      <SelectItem value="stucki" className="text-xs font-medium dark:text-slate-200">Stucki</SelectItem>
                      <SelectItem value="bayer" className="text-xs font-medium dark:text-slate-200">Bayer</SelectItem>
                      <SelectItem value="jarvis-judice-ninke" className="text-xs font-medium dark:text-slate-200">Jarvis-Judice</SelectItem>
                      <SelectItem value="fast-print" className="text-xs font-bold text-teal-600 dark:text-teal-400">Hızlı</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
            </div>
           </ScrollArea>
           <DialogFooter className="p-2 bg-white dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 z-10">
             <Button onClick={()=>setIsSettingsOpen(false)} className="w-full h-9 rounded-lg bg-indigo-600 hover:bg-indigo-700 font-bold text-xs">Tamam</Button>
           </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-xs mx-2 sm:max-w-sm rounded-xl p-2 overflow-hidden border-none text-slate-800 dark:text-slate-100 shadow-xl bg-white dark:bg-slate-950 max-h-[70vh]">
          <DialogHeader className="p-2 pb-1 bg-gradient-to-b from-slate-900 to-slate-800 dark:from-black dark:to-slate-900 rounded-t-lg">
            <DialogTitle className="flex items-center gap-1.5 text-white font-bold text-xs">
              <PrinterCheck className="text-teal-400" size={14} /> Önizleme
            </DialogTitle>
          </DialogHeader>
          {/* Scrollable preview area mimicking thermal paper */}
          <div className="bg-slate-100 dark:bg-black/40 p-2">
            <div className="bg-white dark:bg-white/95 shadow-inner rounded-lg overflow-auto flex justify-center max-h-[35vh]">
              {previewImage ? (
                <div className="flex flex-col items-center">
                  <img src={previewImage} alt="Preview" className="max-w-full w-full [image-rendering:pixelated]" />
                </div>
              ) : <p className="text-slate-400 italic p-2 text-xs">Hazırlanıyor...</p>}
            </div>
          </div>
           <div className="p-3 space-y-2 bg-white dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800">
             <div className="flex items-center justify-between gap-2">
               <Label className="text-[10px] font-bold text-slate-600 dark:text-slate-400">Döndür</Label>
               <Button variant="outline" size="icon" className="h-7 w-7 rounded-lg dark:border-slate-700 dark:bg-slate-800" onClick={()=>{setPdfRotation(r=>(r+90)%360); generatePreview();}}><RotateCw size={12} /></Button>
             </div>
             <Select value={printQuality} onValueChange={(v:any)=>setPrintQuality(v)}>
               <SelectTrigger className="rounded-lg h-8 font-bold text-[10px] dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"><SelectValue /></SelectTrigger>
               <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
                 <SelectItem value="draft" className="dark:text-slate-200 text-[10px]">Taslak</SelectItem>
                 <SelectItem value="normal" className="dark:text-slate-200 text-[10px]">Normal</SelectItem>
                 <SelectItem value="fine" className="dark:text-slate-200 text-[10px]">Kalite</SelectItem>
               </SelectContent>
             </Select>
              <Button onClick={handlePrint} disabled={!isConnected} className="w-full h-9 rounded-xl bg-gradient-to-r from-teal-600 to-teal-500 text-white font-bold text-xs">
               {isConnected ? 'YAZDIR' : 'Bağlantı Gerekli'}
              </Button>
           </div>
        </DialogContent>
      </Dialog>

      <DebugConsole onSwitchChannel={handleSwitchChannel} activeView={activeView} visible={showConsole} />
    </div>
  );
}

// Add these to global CSS or index.css for smooth animations
/*
@keyframes bounce-subtle {
  0%, 100% { transform: translate(-50%, 0); }
  50% { transform: translate(-50%, -5px); }
}
.animate-bounce-subtle {
  animation: bounce-subtle 2s infinite ease-in-out;
}
*/
