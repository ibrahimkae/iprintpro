# iPrint Pro - Project Documentation

## Current State (29 Nisan 2026)

- **Web Build**: Fixed and building correctly (`npm run build`).
- **macOS Build (Electron)**: Fixed and building correctly (`cd electron && npm run build`).
- **Linting**: Core project (`src/`) is now 100% lint-free.
- **Dependencies**: Added missing types (`@types/react`, `@types/react-dom`, `@types/fabric`, `@types/bwip-js`) and `onnxruntime-web`.

## Recent Improvements & Fixes

1. **DiagnosticsPanel Props**: Fixed a type error where `DiagnosticsPanel` was missing `isExtraDark`, `setIsExtraDark`, and `onTestDarkness` props in the header usage.
2. **Characteristic Switching**: Implemented `switchCharacteristic` in `PrinterService.ts` to allow cycling through writable characteristics, replacing the previous placeholder.
3. **Printer Compatibility**: Modified `pageWidth` input and controls to ensure the width is always a multiple of 8, which is required for correct ESC/POS bitmap alignment.
4. **Capacitor Sync**: Verified and synced Android platform assets.

## iOS Preparation Guide

To complete the iOS version setup, follow these steps:

### 1. Environment Setup
The current environment is missing **CocoaPods**, which is required for Capacitor iOS development.
- Install CocoaPods: `sudo gem install cocoapods` or `brew install cocoapods`.

### 2. Adding iOS Platform
Once CocoaPods is installed, run:
```bash
npm install @capacitor/ios@7.6.1
npx cap add ios
npx cap sync ios
```

### 3. Permissions (Info.plist)
The app uses Bluetooth for thermal printing. You MUST add the following keys to `ios/App/App/Info.plist`:
- `NSBluetoothAlwaysUsageDescription`: "Yazıcıya bağlanmak için Bluetooth erişimi gereklidir."
- `NSBluetoothPeripheralUsageDescription`: "Yazıcıya bağlanmak için Bluetooth erişimi gereklidir."

### 4. App Assets (Icons & Splash)
You can use `@capacitor/assets` to generate all required iOS icons from your high-res logo:
```bash
npx @capacitor/assets generate --ios
```
Recommended source: `electron/assets/appIcon.png`.

## Fixed Issues

1. **Syntax Error in App.tsx**: Fixed a missing `</div>` tag that was causing the JSX parser to fail at the end of the file.
2. **Type Errors in Select/Slider**: Fixed mismatches between `@base-ui/react` component expectations and state setters.
3. **Import Paths**: Corrected `QRGenerator.tsx` import path for the logger.
4. **Build Errors**: Resolved missing `onnxruntime-web` dependency for background removal.
5. **Config**: Excluded `electron` and `dist` folders from core `tsconfig.json` to improve IDE performance and linting accuracy.
