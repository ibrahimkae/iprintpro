import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { PrintHistoryItem, SavedDraftItem } from '../types';
import { historyStorage } from '../lib/history-storage';
import { 
  History, 
  Trash2, 
  Printer, 
  Download, 
  Bookmark, 
  Calendar, 
  Layers, 
  FileText, 
  ImageIcon, 
  QrCode, 
  Tag, 
  Clock,
  ArrowRight,
  Sparkles,
  Search
} from 'lucide-react';
import { Input } from './ui/input';

interface PrintHistoryModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectReprint: (dataUrl: string, title: string) => void;
}

export const PrintHistoryModal: React.FC<PrintHistoryModalProps> = ({
  isOpen,
  onOpenChange,
  onSelectReprint
}) => {
  const [activeTab, setActiveTab] = useState<'history' | 'drafts'>('history');
  const [historyItems, setHistoryItems] = useState<PrintHistoryItem[]>([]);
  const [draftItems, setDraftItems] = useState<SavedDraftItem[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const loadData = () => {
    setHistoryItems(historyStorage.getHistory());
    setDraftItems(historyStorage.getDrafts());
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
      setSearchQuery('');
    }
  }, [isOpen]);

  const handleDeleteHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    historyStorage.deleteHistoryItem(id);
    setHistoryItems(historyStorage.getHistory());
  };

  const handleClearAllHistory = () => {
    if (window.confirm('Tüm yazdırma geçmişini silmek istediğinize emin misiniz?')) {
      historyStorage.clearHistory();
      setHistoryItems([]);
    }
  };

  const handleDeleteDraft = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    historyStorage.deleteDraft(id);
    setDraftItems(historyStorage.getDrafts());
  };

  const handleDownload = (dataUrl: string, title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `${title.replace(/\s+/g, '_')}_iprint.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatTime = (timestamp: number) => {
    const d = new Date(timestamp);
    return `${d.toLocaleDateString('tr-TR')} ${d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}`;
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'image':
        return { icon: ImageIcon, label: 'Görsel', color: 'bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-300' };
      case 'document':
        return { icon: FileText, label: 'Belge', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300' };
      case 'template':
        return { icon: Tag, label: 'Şablon', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300' };
      case 'collage':
        return { icon: Layers, label: 'Kolaj', color: 'bg-teal-100 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300' };
      case 'tools':
        return { icon: QrCode, label: 'Barkod/QR', color: 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-300' };
      default:
        return { icon: FileText, label: 'Metin', color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' };
    }
  };

  const filteredHistory = historyItems.filter(item => 
    !searchQuery || item.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredDrafts = draftItems.filter(draft => 
    !searchQuery || draft.title.toLowerCase().includes(searchQuery.toLowerCase()) || draft.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg w-[94vw] sm:w-full rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-2xl bg-white dark:bg-slate-950 max-h-[88vh] flex flex-col">
        <DialogHeader className="pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <DialogTitle className="font-bold flex items-center gap-2 text-sm sm:text-base text-slate-800 dark:text-slate-100">
              <div className="p-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400">
                <History size={18} />
              </div>
              <span>Yazdırma Geçmişi & Taslaklar</span>
            </DialogTitle>
          </div>
        </DialogHeader>

        {/* Tab switcher */}
        <div className="flex bg-slate-100 dark:bg-slate-900 rounded-xl p-1 gap-1 my-2 border border-slate-200/60 dark:border-slate-800">
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'history'
                ? 'bg-white dark:bg-slate-800 text-teal-700 dark:text-teal-300 shadow-xs font-black'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <History size={14} /> Geçmiş ({historyItems.length})
          </button>
          <button
            onClick={() => setActiveTab('drafts')}
            className={`flex-1 text-xs font-bold py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'drafts'
                ? 'bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 shadow-xs font-black'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <Bookmark size={14} /> Taslaklar ({draftItems.length})
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative mb-2">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <Input 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={activeTab === 'history' ? 'Geçmişte ara...' : 'Taslaklarda ara...'}
            className="pl-8 h-8 text-xs bg-slate-50 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800 rounded-lg"
          />
        </div>

        {/* Content area */}
        <ScrollArea className="flex-1 max-h-[52vh] pr-1.5">
          {activeTab === 'history' && (
            <div className="space-y-2">
              {filteredHistory.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-full w-12 h-12 flex items-center justify-center mx-auto text-slate-400">
                    <Clock size={24} />
                  </div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {searchQuery ? 'Aramanıza uygun baskı bulunamadı' : 'Henüz yazdırılmış bir belge yok'}
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    {searchQuery ? 'Farklı bir arama terimi deneyin.' : 'Yazdırdığınız tüm belgeler burada saklanır ve dilediğiniz an tek tıkla tekrar basılabilir.'}
                  </p>
                </div>
              ) : (
                filteredHistory.map((item) => {
                  const badge = getTypeBadge(item.type);
                  const BadgeIcon = badge.icon;
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectReprint(item.previewDataUrl, item.title);
                        onOpenChange(false);
                      }}
                      className="p-3 bg-slate-50/80 dark:bg-slate-900/70 hover:bg-teal-50/60 dark:hover:bg-teal-950/20 rounded-xl border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer transition-all group shadow-xs hover:border-teal-300 dark:hover:border-teal-800"
                    >
                      {/* Left: Thumbnail & Info */}
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div className="w-12 h-14 bg-white dark:bg-slate-950 rounded-lg p-0.5 border border-slate-200 dark:border-slate-800 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                          <img
                            src={item.previewDataUrl}
                            alt={item.title}
                            className="max-h-full max-w-full object-contain [image-rendering:pixelated]"
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-bold ${badge.color}`}>
                              <BadgeIcon size={10} /> {badge.label}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">
                              {item.width}×{item.height}px
                            </span>
                          </div>
                          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate mt-1">
                            {item.title || 'İsimsiz Baskı'}
                          </h4>
                          <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                            <Calendar size={10} /> {formatTime(item.timestamp)}
                          </p>
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center justify-end gap-1.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60 dark:border-slate-800">
                        <Button
                          size="icon"
                          variant="ghost"
                          title="Görseli İndir (PNG)"
                          onClick={(e) => handleDownload(item.previewDataUrl, item.title, e)}
                          className="h-8 w-8 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800"
                        >
                          <Download size={13} />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          title="Geçmişten Sil"
                          onClick={(e) => handleDeleteHistory(item.id, e)}
                          className="h-8 w-8 rounded-lg text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                        >
                          <Trash2 size={13} />
                        </Button>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectReprint(item.previewDataUrl, item.title);
                            onOpenChange(false);
                          }}
                          className="h-8 px-3 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold gap-1.5 shadow-xs"
                        >
                          <Printer size={12} /> Tekrar Yazdır
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'drafts' && (
            <div className="space-y-2">
              {filteredDrafts.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <div className="p-3 bg-purple-50 dark:bg-purple-950/50 rounded-full w-12 h-12 flex items-center justify-center mx-auto text-purple-500">
                    <Bookmark size={24} />
                  </div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {searchQuery ? 'Aramanıza uygun taslak bulunamadı' : 'Henüz kayıtlı taslak bulunmuyor'}
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    Şablon Stüdyosu'ndan tasarımlarınızı taslak olarak kaydedebilir ve istediğinizde düzenleyebilirsiniz.
                  </p>
                </div>
              ) : (
                filteredDrafts.map((draft) => (
                  <div
                    key={draft.id}
                    onClick={() => {
                      if (draft.previewDataUrl) {
                        onSelectReprint(draft.previewDataUrl, draft.title);
                        onOpenChange(false);
                      }
                    }}
                    className="p-3 bg-slate-50/80 dark:bg-slate-900/70 hover:bg-purple-50/60 dark:hover:bg-purple-950/20 rounded-xl border border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer transition-all shadow-xs hover:border-purple-300 dark:hover:border-purple-800"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {draft.previewDataUrl && (
                        <div className="w-12 h-14 bg-white dark:bg-slate-950 rounded-lg p-0.5 border border-slate-200 dark:border-slate-800 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                          <img
                            src={draft.previewDataUrl}
                            alt={draft.title}
                            className="max-h-full max-w-full object-contain [image-rendering:pixelated]"
                          />
                        </div>
                      )}

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-purple-100 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300">
                            <Sparkles size={10} /> {draft.category.toUpperCase()}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate mt-1">
                          {draft.title}
                        </h4>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Calendar size={10} /> {formatTime(draft.timestamp)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-1.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60 dark:border-slate-800">
                      <Button
                        size="icon"
                        variant="ghost"
                        title="Taslağı Sil"
                        onClick={(e) => handleDeleteDraft(draft.id, e)}
                        className="h-8 w-8 rounded-lg text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                      >
                        <Trash2 size={13} />
                      </Button>
                      <Button
                        size="sm"
                        className="h-8 px-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold gap-1.5 shadow-xs"
                      >
                        <ArrowRight size={12} /> Yükle & Aç
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </ScrollArea>

        {activeTab === 'history' && historyItems.length > 0 && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
            <span className="text-[11px] text-slate-400 font-medium">Toplam {historyItems.length} kayıt</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearAllHistory}
              className="text-xs text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg h-8 font-bold gap-1.5"
            >
              <Trash2 size={13} /> Tüm Geçmişi Temizle
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
