import React, { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ScrollArea } from './ui/scroll-area';
import { QRCodeSVG } from 'qrcode.react';
import bwipjs from 'bwip-js';
import { 
  ListChecks, 
  Tag, 
  Wifi, 
  Receipt, 
  Package, 
  DollarSign, 
  FileText, 
  Plus, 
  Trash2, 
  PrinterCheck, 
  Sparkles, 
  CheckSquare, 
  Clock, 
  Calendar, 
  User, 
  MapPin, 
  Phone,
  BookmarkPlus,
  RefreshCw,
  Eye,
  ShoppingBag,
  Store
} from 'lucide-react';
import { logger } from '../lib/logger';
import { historyStorage } from '../lib/history-storage';

interface TemplateStudioProps {
  pageWidth: number;
  onPreviewAndPrint: (dataUrl: string, title: string) => void;
}

type TemplateCategory = 'todo' | 'shipping' | 'wifi' | 'receipt' | 'pantry' | 'price' | 'article';

export const TemplateStudio: React.FC<TemplateStudioProps> = ({ pageWidth, onPreviewAndPrint }) => {
  const [category, setCategory] = useState<TemplateCategory>('todo');
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const [livePreviewUrl, setLivePreviewUrl] = useState<string>('');

  // 1. To-Do / Checklist State
  const [todoTitle, setTodoTitle] = useState('GÜNLÜK PLAN & HEDEFLER');
  const [todoDate, setTodoDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [todoStyle, setTodoStyle] = useState<'checkbox' | 'circle' | 'numbered'>('checkbox');
  const [todoItems, setTodoItems] = useState<string[]>([
    'Sabah kahvesi ve e-postalar',
    'Termal yazıcı test çıktıları',
    'Müşteri kargo etiketlerini hazırla',
    'Akşam toplantı notlarını toparla'
  ]);

  // 2. Shipping Label State
  const [senderName, setSenderName] = useState('iPrint Pro Store');
  const [senderPhone, setSenderPhone] = useState('+90 555 123 45 67');
  const [senderAddress, setSenderAddress] = useState('Merkez Mah. Teknoloji Cad. No: 12/A İstanbul');
  const [receiverName, setReceiverName] = useState('Ahmet Yılmaz');
  const [receiverPhone, setReceiverPhone] = useState('+90 532 987 65 43');
  const [receiverAddress, setReceiverAddress] = useState('Atatürk Bulvarı Papatya Sokak No: 8 Daire: 4 Kadıköy / İstanbul');
  const [trackingNumber, setTrackingNumber] = useState('KP048291038TR');
  const [isFragile, setIsFragile] = useState(true);

  // 3. Wi-Fi Card State
  const [wifiSsid, setWifiSsid] = useState('iPrint-Misafir-WiFi');
  const [wifiPassword, setWifiPassword] = useState('HızlıBaskı2026!');
  const [wifiSecurity, setWifiSecurity] = useState<'WPA' | 'WEP' | 'nopass'>('WPA');
  const [wifiMessage, setWifiMessage] = useState('Kameranızla QR kodu taratarak ağa otomatik bağlanabilirsiniz.');

  // 4. POS Receipt State
  const [storeName, setStoreName] = useState('İPRİNT KAFE & MARKET');
  const [storeSub, setStoreSub] = useState('Fatih Mah. İstiklal Cad. No:44');
  const [receiptNumber, setReceiptNumber] = useState('NO: 004829');
  const [receiptItems, setReceiptItems] = useState([
    { name: 'Filtre Kahve', qty: 2, price: 65 },
    { name: 'Kruvasan Sade', qty: 1, price: 80 },
    { name: 'Termal Rulo Kağıt (3lü)', qty: 1, price: 120 }
  ]);
  const [receiptTax, setReceiptTax] = useState(10); // %10 KDV
  const [receiptFooter, setReceiptFooter] = useState('Bizi tercih ettiğiniz için teşekkür ederiz! Yine bekleriz.');

  // 5. Pantry / Organizer State
  const [pantryItem, setPantryItem] = useState('Kuru Fasulye (Dermason)');
  const [pantryCategory, setPantryCategory] = useState('Bakliyat');
  const [pantryPackDate, setPantryPackDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [pantryExpiryDate, setPantryExpiryDate] = useState('2027-08-30');
  const [pantryStorage, setPantryStorage] = useState('Serin, Kuru & Işıksız Ortam');

  // 6. Price & Sale Tag State
  const [productName, setProductName] = useState('Premium Termal Çıkartma Kağıdı');
  const [oldPrice, setOldPrice] = useState('149.90');
  const [newPrice, setNewPrice] = useState('99.50');
  const [currency, setCurrency] = useState('TL');
  const [promoBadge, setPromoBadge] = useState('SÜPER İNDİRİM');
  const [productBarcode, setProductBarcode] = useState('869012345678');

  // 7. Article / Reader State
  const [articleTitle, setArticleTitle] = useState('Termal Yazıcı Teknolojisi ve Verimlilik');
  const [articleAuthor, setArticleAuthor] = useState('iPrint Pro Araştırma');
  const [articleContent, setArticleContent] = useState(
    'Termal baskı teknolojisi mürekkep veya kartuş gerektirmeden, ısıya duyarlı özel termal kağıt üzerine mikroskobik ısıtıcı pinler ile mikrosaniyeler içinde yüksek kontrastlı baskı sağlar.\n\nTaşınabilir Bluetooth termal yazıcılar günümüzde lojistik, kargo, perakende fişleri, ajanda tutma ve fotoğraf hatıra çıktılarında vazgeçilmez bir yer edinmiştir.'
  );

  // Re-render the canvas whenever state changes
  useEffect(() => {
    renderCurrentTemplate();
  }, [
    category,
    pageWidth,
    todoTitle, todoDate, todoStyle, todoItems,
    senderName, senderPhone, senderAddress, receiverName, receiverPhone, receiverAddress, trackingNumber, isFragile,
    wifiSsid, wifiPassword, wifiSecurity, wifiMessage,
    storeName, storeSub, receiptNumber, receiptItems, receiptTax, receiptFooter,
    pantryItem, pantryCategory, pantryPackDate, pantryExpiryDate, pantryStorage,
    productName, oldPrice, newPrice, currency, promoBadge, productBarcode,
    articleTitle, articleAuthor, articleContent
  ]);

  const renderCurrentTemplate = async () => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = pageWidth || 384;
    canvas.width = w;

    if (category === 'todo') {
      renderTodo(ctx, w, canvas);
    } else if (category === 'shipping') {
      await renderShipping(ctx, w, canvas);
    } else if (category === 'wifi') {
      await renderWifi(ctx, w, canvas);
    } else if (category === 'receipt') {
      renderReceipt(ctx, w, canvas);
    } else if (category === 'pantry') {
      renderPantry(ctx, w, canvas);
    } else if (category === 'price') {
      await renderPrice(ctx, w, canvas);
    } else if (category === 'article') {
      renderArticle(ctx, w, canvas);
    }

    setLivePreviewUrl(canvas.toDataURL('image/png'));
  };

  // 1. Render To-Do
  const renderTodo = (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 16;
    const lineHeight = 32;
    const estimatedHeight = 110 + todoItems.length * lineHeight + 50;
    canvas.height = estimatedHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Header Box
    ctx.fillRect(pad, 14, w - pad * 2, 34);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 15px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(todoTitle, w / 2, 36);

    // Date Subtitle
    ctx.fillStyle = '#000000';
    ctx.font = '11px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`TARİH: ${todoDate}`, w / 2, 64);

    // Divider
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(pad, 74);
    ctx.lineTo(w - pad, 74);
    ctx.stroke();
    ctx.setLineDash([]);

    // Items
    ctx.textAlign = 'left';
    ctx.font = '13px sans-serif';
    let y = 104;

    todoItems.forEach((item, idx) => {
      // Checkbox icon / circle / number
      if (todoStyle === 'checkbox') {
        ctx.lineWidth = 2;
        ctx.strokeRect(pad + 4, y - 14, 16, 16);
      } else if (todoStyle === 'circle') {
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(pad + 12, y - 6, 8, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText(`${idx + 1}.`, pad + 4, y);
      }

      ctx.font = '13px sans-serif';
      ctx.fillText(item, pad + 30, y);
      y += lineHeight;
    });

    // Bottom Decorative Bar
    ctx.fillRect(pad, y + 6, w - pad * 2, 3);
  };

  // 2. Render Shipping
  const renderShipping = async (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 12;
    const totalHeight = 390;
    canvas.height = totalHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Outer border with safe margins
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, w - pad * 2, totalHeight - pad * 2);

    // Top Header: EXPRESS CARGO
    ctx.fillRect(pad, pad, w - pad * 2, 34);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('HIZLI KARGO / TESLİMAT', w / 2, pad + 22);

    // Sender Section
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'left';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('GÖNDERİCİ (FROM):', pad + 8, pad + 48);
    ctx.font = '11px sans-serif';
    ctx.fillText(`${senderName} - ${senderPhone}`, pad + 8, pad + 63);
    wrapText(ctx, senderAddress, pad + 8, pad + 78, w - pad * 2 - 16, 13);

    // Divider
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, pad + 104);
    ctx.lineTo(w - pad, pad + 104);
    ctx.stroke();

    // Receiver Section (Highlighted)
    ctx.fillRect(pad, pad + 104, w - pad * 2, 22);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('ALICI (TO):', pad + 8, pad + 119);

    ctx.fillStyle = '#000000';
    ctx.font = 'bold 13px sans-serif';
    ctx.fillText(receiverName, pad + 8, pad + 142);
    ctx.font = 'bold 11px monospace';
    ctx.fillText(`Tel: ${receiverPhone}`, pad + 8, pad + 158);
    ctx.font = '11px sans-serif';
    wrapText(ctx, receiverAddress, pad + 8, pad + 174, w - pad * 2 - 16, 14);

    // Divider
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, pad + 220);
    ctx.lineTo(w - pad, pad + 220);
    ctx.stroke();

    // Fragile badge if checked (clean text, no color emoji)
    if (isFragile) {
      ctx.lineWidth = 2;
      ctx.strokeRect(w - pad - 100, pad + 226, 92, 22);
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('! KIRILACAK', w - pad - 54, pad + 241);
    }

    // Barcode Section with aspect-ratio preservation
    ctx.textAlign = 'left';
    ctx.font = 'bold 11px monospace';
    ctx.fillText(`TAKİP NO: ${trackingNumber}`, pad + 8, pad + 240);

    try {
      const barcodeCanvas = document.createElement('canvas');
      bwipjs.toCanvas(barcodeCanvas, {
        bcid: 'code128',
        text: trackingNumber,
        scale: 3,
        height: 10,
        includetext: false
      });
      const bw = Math.min(240, w - 40);
      const bh = Math.round((bw * barcodeCanvas.height) / barcodeCanvas.width);
      ctx.drawImage(barcodeCanvas, (w - bw) / 2, pad + 252, bw, bh);

      ctx.textAlign = 'center';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(trackingNumber, w / 2, pad + 252 + bh + 16);
      ctx.font = '11px sans-serif';
      ctx.fillText('İmza / Teslim Alan: .......................................', w / 2, pad + 252 + bh + 38);
    } catch (e) {
      logger.error('Shipping barcode failed', e);
    }

    // Ensure bottom outer border is reinforced
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, w - pad * 2, totalHeight - pad * 2);
  };

  // 3. Render Wi-Fi Card
  const renderWifi = async (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 14;
    const totalHeight = 390;
    canvas.height = totalHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Decorative outer frame
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, w - pad * 2, totalHeight - pad * 2);
    ctx.lineWidth = 1;
    ctx.strokeRect(pad + 4, pad + 4, w - pad * 2 - 8, totalHeight - pad * 2 - 8);

    // Title
    ctx.textAlign = 'center';
    ctx.font = 'bold 15px sans-serif';
    ctx.fillText('MİSAFİR Wİ-Fİ AĞI', w / 2, pad + 28);

    // Subtitle
    ctx.font = '11px sans-serif';
    ctx.fillText('Kameranızı QR koda tutarak bağlanın', w / 2, pad + 44);

    // Draw QR Code
    const wifiString = `WIFI:T:${wifiSecurity};S:${wifiSsid};P:${wifiPassword};;`;
    const qrSize = 150;
    const qrX = (w - qrSize) / 2;
    const qrY = pad + 56;

    // Render SVG QR to canvas
    const qrCanvas = document.createElement('canvas');
    try {
      bwipjs.toCanvas(qrCanvas, {
        bcid: 'qrcode',
        text: wifiString,
        scale: 4,
        paddingwidth: 1,
        paddingheight: 1
      });
      ctx.drawImage(qrCanvas, qrX, qrY, qrSize, qrSize);
    } catch (e) {
      logger.error('Wifi QR render error', e);
    }

    // Wi-Fi Details Box (Pure white background to prevent dithering noise)
    const boxY = qrY + qrSize + 12;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(pad + 14, boxY, w - (pad + 14) * 2, 64);
    ctx.lineWidth = 1.5;
    ctx.strokeRect(pad + 14, boxY, w - (pad + 14) * 2, 64);

    ctx.fillStyle = '#000000';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`AĞ ADI (SSID):`, pad + 22, boxY + 20);
    ctx.font = 'bold 13px monospace';
    ctx.fillText(wifiSsid, pad + 22, boxY + 36);

    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(`ŞİFRE:`, pad + 22, boxY + 52);
    ctx.font = 'bold 13px monospace';
    ctx.fillText(wifiPassword, pad + 65, boxY + 52);

    // Footer note
    ctx.textAlign = 'center';
    ctx.font = '11px sans-serif';
    wrapText(ctx, wifiMessage, w / 2, boxY + 84, w - pad * 2 - 20, 14);
  };

  // 4. Render Receipt
  const renderReceipt = (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 14;
    const rowHeight = 22;
    const totalLines = receiptItems.length;
    canvas.height = 200 + totalLines * rowHeight + 120;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Store Name Header
    ctx.textAlign = 'center';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(storeName, w / 2, 28);
    ctx.font = '11px sans-serif';
    ctx.fillText(storeSub, w / 2, 44);

    const now = new Date();
    const dateStr = `${now.toLocaleDateString('tr-TR')}  ${now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}`;
    ctx.font = 'bold 11px monospace';
    ctx.fillText(dateStr, w / 2, 60);
    ctx.fillText(receiptNumber, w / 2, 74);

    // Dotted Divider
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(pad, 86);
    ctx.lineTo(w - pad, 86);
    ctx.stroke();

    // Table Header
    ctx.setLineDash([]);
    ctx.textAlign = 'left';
    ctx.font = 'bold 11px monospace';
    ctx.fillText('ÜRÜN', pad, 102);
    ctx.textAlign = 'center';
    ctx.fillText('ADET', w - pad - 100, 102);
    ctx.textAlign = 'right';
    ctx.fillText('TUTAR', w - pad, 102);

    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(pad, 110);
    ctx.lineTo(w - pad, 110);
    ctx.stroke();
    ctx.setLineDash([]);

    // Rows
    let curY = 128;
    let subtotal = 0;

    receiptItems.forEach((item) => {
      const itemTotal = item.qty * item.price;
      subtotal += itemTotal;

      ctx.textAlign = 'left';
      ctx.font = '12px sans-serif';
      ctx.fillText(item.name, pad, curY);

      ctx.textAlign = 'center';
      ctx.font = '12px monospace';
      ctx.fillText(`${item.qty}x`, w - pad - 100, curY);

      ctx.textAlign = 'right';
      ctx.font = 'bold 12px monospace';
      ctx.fillText(`${itemTotal.toFixed(2)} TL`, w - pad, curY);

      curY += rowHeight;
    });

    // Totals Section
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(pad, curY);
    ctx.lineTo(w - pad, curY);
    ctx.stroke();
    ctx.setLineDash([]);

    curY += 20;
    ctx.textAlign = 'left';
    ctx.font = '11px monospace';
    ctx.fillText(`ARA TOPLAM:`, pad, curY);
    ctx.textAlign = 'right';
    ctx.fillText(`${subtotal.toFixed(2)} TL`, w - pad, curY);

    const taxAmount = (subtotal * receiptTax) / 100;
    curY += 18;
    ctx.textAlign = 'left';
    ctx.fillText(`KDV (%${receiptTax}):`, pad, curY);
    ctx.textAlign = 'right';
    ctx.fillText(`${taxAmount.toFixed(2)} TL`, w - pad, curY);

    curY += 24;
    ctx.fillRect(pad, curY - 16, w - pad * 2, 24);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.font = 'bold 13px monospace';
    ctx.fillText(`GENEL TOPLAM:`, pad + 8, curY);
    ctx.textAlign = 'right';
    ctx.fillText(`${(subtotal + taxAmount).toFixed(2)} TL`, w - pad - 8, curY);

    // Footer
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.font = '11px sans-serif';
    curY += 34;
    wrapText(ctx, receiptFooter, w / 2, curY, w - pad * 2 - 10, 14);

    curY += 28;
    ctx.font = 'bold 10px monospace';
    ctx.fillText('*** MALİ DEĞERİ YOKTUR / BİLGİ FİŞİDİR ***', w / 2, curY);
  };

  // 5. Render Pantry / Organizer
  const renderPantry = (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 12;
    const totalHeight = 260;
    canvas.height = totalHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Double frame
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, w - pad * 2, totalHeight - pad * 2);
    ctx.lineWidth = 1;
    ctx.strokeRect(pad + 4, pad + 4, w - pad * 2 - 8, totalHeight - pad * 2 - 8);

    // Category tag
    ctx.fillRect(pad + 12, pad + 12, 100, 20);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(pantryCategory.toUpperCase(), pad + 62, pad + 26);

    // Main item name
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.font = 'bold 17px sans-serif';
    ctx.fillText(pantryItem, w / 2, pad + 62);

    // Divider line with diamond center
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad + 20, pad + 78);
    ctx.lineTo(w - pad - 20, pad + 78);
    ctx.stroke();

    // Dates grid
    ctx.textAlign = 'left';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('PAKETLEME:', pad + 16, pad + 104);
    ctx.font = 'bold 12px monospace';
    ctx.fillText(pantryPackDate, pad + 16, pad + 120);

    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('SON TÜKETİM (TETT):', pad + 16, pad + 148);
    ctx.font = 'bold 14px monospace';
    ctx.fillText(pantryExpiryDate, pad + 16, pad + 166);

    // Storage condition box (Pure white background)
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(pad + 14, pad + 184, w - pad * 2 - 28, 28);
    ctx.lineWidth = 1.5;
    ctx.strokeRect(pad + 14, pad + 184, w - pad * 2 - 28, 28);

    ctx.fillStyle = '#000000';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`[SAKLAMA] ${pantryStorage}`, w / 2, pad + 203);
  };

  // 6. Render Price Tag
  const renderPrice = async (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 12;
    const maxWidth = w - pad * 2 - 16;
    
    // Dynamic product title calculation
    ctx.font = 'bold 14px sans-serif';
    const titleLines = getLines(ctx, productName || 'Ürün Adı', maxWidth);
    const titleHeight = Math.max(22, titleLines.length * 19);
    
    const ribbonHeight = 28;
    const productTitleY = pad + ribbonHeight + 10;
    const priceBoxY = productTitleY + titleHeight + 10;
    const barcodeStartY = priceBoxY + 68;

    // Generate Barcode with crisp bwip-js text and bars
    let barcodeCanvas: HTMLCanvasElement | null = null;
    const cleanBarcode = (productBarcode || '').trim();
    if (cleanBarcode) {
      try {
        barcodeCanvas = document.createElement('canvas');
        const isNumeric = /^\d+$/.test(cleanBarcode);
        const isEan13 = isNumeric && (cleanBarcode.length === 12 || cleanBarcode.length === 13);
        bwipjs.toCanvas(barcodeCanvas, {
          bcid: isEan13 ? 'ean13' : 'code128',
          text: cleanBarcode,
          scale: 3,
          height: 12,
          includetext: true,
          textsize: 11,
          textxalign: 'center',
        });
      } catch (e) {
        try {
          barcodeCanvas = document.createElement('canvas');
          bwipjs.toCanvas(barcodeCanvas, {
            bcid: 'code128',
            text: cleanBarcode,
            scale: 3,
            height: 12,
            includetext: true,
            textsize: 11,
            textxalign: 'center',
          });
        } catch (err2) {
          logger.error('Price tag barcode render error', err2);
        }
      }
    }

    let bw = 0;
    let bh = 0;
    let barcodeSectionHeight = 0;
    if (barcodeCanvas && barcodeCanvas.width > 0) {
      bw = Math.min(260, w - pad * 2 - 16);
      bh = Math.round((bw * barcodeCanvas.height) / barcodeCanvas.width);
      barcodeSectionHeight = bh + 8;
    }

    const totalHeight = Math.max(280, barcodeStartY + barcodeSectionHeight + pad + 14);
    canvas.height = totalHeight;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Promo Ribbon (clean text, high contrast)
    ctx.fillRect(pad, pad, w - pad * 2, ribbonHeight);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(promoBadge || 'SÜPER İNDİRİM', w / 2, pad + 19);

    // Product Title
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    titleLines.forEach((l, idx) => {
      ctx.fillText(l, w / 2, productTitleY + (idx + 1) * 19 - 4);
    });

    // Price Box
    ctx.textAlign = 'center';
    if (oldPrice) {
      ctx.font = '13px monospace';
      const oldPriceText = `${oldPrice} ${currency}`;
      ctx.fillText(oldPriceText, w / 2, priceBoxY + 14);
      const textW = ctx.measureText(oldPriceText).width;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(w / 2 - textW / 2 - 4, priceBoxY + 10);
      ctx.lineTo(w / 2 + textW / 2 + 4, priceBoxY + 10);
      ctx.stroke();
    }

    // New Price Huge
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(`${newPrice} ${currency}`, w / 2, priceBoxY + 46);

    // Draw Barcode with natural aspect ratio
    if (barcodeCanvas && bw > 0 && bh > 0) {
      ctx.drawImage(barcodeCanvas, (w - bw) / 2, barcodeStartY, bw, bh);
    }

    // Outer frame with safe bottom padding
    ctx.lineWidth = 2.5;
    ctx.strokeRect(pad, pad, w - pad * 2, totalHeight - pad * 2);
  };

  // 7. Render Long Article
  const renderArticle = (ctx: CanvasRenderingContext2D, w: number, canvas: HTMLCanvasElement) => {
    const pad = 16;
    const maxWidth = w - pad * 2;
    
    ctx.font = 'bold 16px sans-serif';
    const titleLines = getLines(ctx, articleTitle, maxWidth);
    const titleHeight = titleLines.length * 22;

    ctx.font = '13px sans-serif';
    const paragraphs = articleContent.split('\n');
    let totalBodyLines = 0;
    paragraphs.forEach(p => {
      const lines = getLines(ctx, p, maxWidth);
      totalBodyLines += lines.length + 1;
    });

    const subTitleY = 30 + titleHeight + 10;
    const dividerY = subTitleY + 16;
    const bodyStartY = dividerY + 22;
    const totalHeight = bodyStartY + totalBodyLines * 20 + 60;
    canvas.height = totalHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, canvas.height);
    ctx.fillStyle = '#000000';

    // Title (multi-line supported)
    ctx.textAlign = 'center';
    ctx.font = 'bold 16px sans-serif';
    titleLines.forEach((line, idx) => {
      ctx.fillText(line, w / 2, 30 + idx * 22);
    });

    // Subtitle & Date (dynamically positioned under the title)
    const now = new Date().toLocaleDateString('tr-TR');
    ctx.font = '11px sans-serif';
    ctx.fillText(`${articleAuthor} • ${now}`, w / 2, subTitleY);

    // Divider
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, dividerY);
    ctx.lineTo(w - pad, dividerY);
    ctx.stroke();

    // Body
    ctx.textAlign = 'left';
    ctx.font = '13px sans-serif';
    let curY = bodyStartY;

    paragraphs.forEach((para) => {
      if (!para.trim()) {
        curY += 10;
        return;
      }
      const lines = getLines(ctx, para, maxWidth);
      lines.forEach((line) => {
        ctx.fillText(line, pad, curY);
        curY += 20;
      });
      curY += 8;
    });

    // End Marker with safety margin
    ctx.textAlign = 'center';
    ctx.font = 'bold 11px monospace';
    ctx.fillText('■ ■ ■ [SON] ■ ■ ■', w / 2, curY + 16);
  };

  // Helper function to split text into wrapped lines
  function getLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = words[0] || '';

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + ' ' + word).width;
      if (width < maxWidth) {
        currentLine += ' ' + word;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);
    return lines;
  }

  function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
    const lines = getLines(ctx, text, maxWidth);
    lines.forEach((line, index) => {
      ctx.fillText(line, x, y + index * lineHeight);
    });
  }

  const handlePrint = () => {
    if (!livePreviewUrl) return;
    const titles: Record<TemplateCategory, string> = {
      todo: todoTitle,
      shipping: `Kargo - ${receiverName}`,
      wifi: `Wi-Fi Kartı (${wifiSsid})`,
      receipt: `Fiş (${storeName})`,
      pantry: `Etiket - ${pantryItem}`,
      price: `Fiyat - ${productName}`,
      article: articleTitle
    };
    onPreviewAndPrint(livePreviewUrl, titles[category] || 'Şablon Çıktısı');
  };

  const handleSaveDraft = () => {
    historyStorage.saveDraft({
      title: `${category.toUpperCase()} - ${new Date().toLocaleTimeString('tr-TR')}`,
      category,
      previewDataUrl: livePreviewUrl,
      payload: { category, todoTitle, senderName, wifiSsid, storeName, pantryItem, productName, articleTitle }
    });
    logger.info('Şablon taslaklara kaydedildi');
  };

  return (
    <div className="space-y-4">
      {/* Hidden processing canvas */}
      <canvas ref={previewCanvasRef} className="hidden" />

      {/* Category selector chips */}
      <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        {[
          { id: 'todo', label: 'Yapılacak', icon: ListChecks },
          { id: 'shipping', label: 'Kargo', icon: Package },
          { id: 'wifi', label: 'Wi-Fi', icon: Wifi },
          { id: 'receipt', label: 'Fiş/Fatura', icon: Receipt },
          { id: 'pantry', label: 'Düzenleyici', icon: Tag },
          { id: 'price', label: 'Fiyat', icon: DollarSign },
          { id: 'article', label: 'Makale', icon: FileText }
        ].map((item) => {
          const Icon = item.icon;
          const isActive = category === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCategory(item.id as TemplateCategory)}
              className={`flex flex-col items-center justify-center p-2 rounded-lg text-[10px] font-bold transition-all ${
                isActive
                  ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <Icon size={16} className="mb-1" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
        {/* Form Controls Section */}
        <Card className="p-4 rounded-xl space-y-3 dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs">
          {category === 'todo' && (
            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-[11px] font-bold text-slate-500 uppercase">Liste Başlığı</Label>
                <Input value={todoTitle} onChange={e => setTodoTitle(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[11px] font-bold text-slate-500 uppercase">Tarih</Label>
                  <Input type="date" value={todoDate} onChange={e => setTodoDate(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <div>
                  <Label className="text-[11px] font-bold text-slate-500 uppercase">Kutu Stili</Label>
                  <Select value={todoStyle} onValueChange={(v: any) => v && setTodoStyle(v)}>
                    <SelectTrigger className="h-8 text-xs rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="checkbox">Kare Kutucuk [ ]</SelectItem>
                      <SelectItem value="circle">Yuvarlak O</SelectItem>
                      <SelectItem value="numbered">Numaralı 1. 2.</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[11px] font-bold text-slate-500 uppercase">Maddeler ({todoItems.length})</Label>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {todoItems.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-1.5">
                      <Input
                        value={item}
                        onChange={e => {
                          const updated = [...todoItems];
                          updated[idx] = e.target.value;
                          setTodoItems(updated);
                        }}
                        className="h-8 text-xs rounded-lg flex-1"
                      />
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setTodoItems(todoItems.filter((_, i) => i !== idx))}
                        className="h-8 w-8 text-red-500 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 size={13} />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setTodoItems([...todoItems, 'Yeni görev'])}
                  className="w-full text-xs font-bold gap-1 rounded-lg h-8 mt-1"
                >
                  <Plus size={13} /> Madde Ekle
                </Button>
              </div>
            </div>
          )}

          {category === 'shipping' && (
            <div className="space-y-3">
              <div className="p-2.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Gönderici Bilgileri</span>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Ad / Firma" value={senderName} onChange={e => setSenderName(e.target.value)} className="h-8 text-xs rounded-lg" />
                  <Input placeholder="Telefon" value={senderPhone} onChange={e => setSenderPhone(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <Input placeholder="Adres" value={senderAddress} onChange={e => setSenderAddress(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>

              <div className="p-2.5 bg-teal-50/50 dark:bg-teal-950/20 rounded-lg border border-teal-200 dark:border-teal-900/50 space-y-2">
                <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 uppercase">Alıcı Bilgileri</span>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Alıcı Adı" value={receiverName} onChange={e => setReceiverName(e.target.value)} className="h-8 text-xs rounded-lg" />
                  <Input placeholder="Telefon" value={receiverPhone} onChange={e => setReceiverPhone(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <Input placeholder="Tam Adres" value={receiverAddress} onChange={e => setReceiverAddress(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Takip No</Label>
                  <Input value={trackingNumber} onChange={e => setTrackingNumber(e.target.value)} className="h-8 text-xs rounded-lg font-mono" />
                </div>
                <div className="flex items-end pb-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 dark:text-slate-300">
                    <input type="checkbox" checked={isFragile} onChange={e => setIsFragile(e.target.checked)} className="rounded" />
                    ⚠️ Kırılacak Uyarısı
                  </label>
                </div>
              </div>
            </div>
          )}

          {category === 'wifi' && (
            <div className="space-y-3">
              <div>
                <Label className="text-[11px] font-bold text-slate-500 uppercase">Ağ Adı (SSID)</Label>
                <Input value={wifiSsid} onChange={e => setWifiSsid(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[11px] font-bold text-slate-500 uppercase">Wi-Fi Şifresi</Label>
                  <Input value={wifiPassword} onChange={e => setWifiPassword(e.target.value)} className="h-8 text-xs rounded-lg font-mono" />
                </div>
                <div>
                  <Label className="text-[11px] font-bold text-slate-500 uppercase">Güvenlik Türü</Label>
                  <Select value={wifiSecurity} onValueChange={(v: any) => v && setWifiSecurity(v)}>
                    <SelectTrigger className="h-8 text-xs rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="WPA">WPA / WPA2 / WPA3</SelectItem>
                      <SelectItem value="WEP">WEP</SelectItem>
                      <SelectItem value="nopass">Şifresiz (Açık)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-[11px] font-bold text-slate-500 uppercase">Alt Mesaj</Label>
                <Input value={wifiMessage} onChange={e => setWifiMessage(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>
            </div>
          )}

          {category === 'receipt' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">İşletme Adı</Label>
                  <Input value={storeName} onChange={e => setStoreName(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Fiş No</Label>
                  <Input value={receiptNumber} onChange={e => setReceiptNumber(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase">Adres / Alt Başlık</Label>
                <Input value={storeSub} onChange={e => setStoreSub(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>

              <div className="space-y-1.5">
                <Label className="text-[10px] font-bold text-slate-500 uppercase">Kalemler</Label>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {receiptItems.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-1.5">
                      <Input
                        placeholder="Ürün"
                        value={item.name}
                        onChange={e => {
                          const u = [...receiptItems];
                          u[idx].name = e.target.value;
                          setReceiptItems(u);
                        }}
                        className="h-8 text-xs rounded-lg flex-2"
                      />
                      <Input
                        type="number"
                        placeholder="Adet"
                        value={item.qty}
                        onChange={e => {
                          const u = [...receiptItems];
                          u[idx].qty = Number(e.target.value) || 1;
                          setReceiptItems(u);
                        }}
                        className="h-8 text-xs rounded-lg w-14 text-center"
                      />
                      <Input
                        type="number"
                        placeholder="Fiyat"
                        value={item.price}
                        onChange={e => {
                          const u = [...receiptItems];
                          u[idx].price = Number(e.target.value) || 0;
                          setReceiptItems(u);
                        }}
                        className="h-8 text-xs rounded-lg w-16 text-right"
                      />
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setReceiptItems(receiptItems.filter((_, i) => i !== idx))}
                        className="h-8 w-8 text-red-500 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 size={13} />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setReceiptItems([...receiptItems, { name: 'Yeni Kalem', qty: 1, price: 50 }])}
                  className="w-full text-xs font-bold gap-1 rounded-lg h-8"
                >
                  <Plus size={13} /> Kalem Ekle
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">KDV Oranı (%)</Label>
                  <Input type="number" value={receiptTax} onChange={e => setReceiptTax(Number(e.target.value) || 0)} className="h-8 text-xs rounded-lg" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Teşekkür Notu</Label>
                  <Input value={receiptFooter} onChange={e => setReceiptFooter(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
            </div>
          )}

          {category === 'pantry' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Ürün Adı</Label>
                  <Input value={pantryItem} onChange={e => setPantryItem(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Kategori</Label>
                  <Input value={pantryCategory} onChange={e => setPantryCategory(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Paketleme Tarihi</Label>
                  <Input type="date" value={pantryPackDate} onChange={e => setPantryPackDate(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Son Tüketim (TETT)</Label>
                  <Input type="date" value={pantryExpiryDate} onChange={e => setPantryExpiryDate(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase">Saklama Koşulu</Label>
                <Input value={pantryStorage} onChange={e => setPantryStorage(e.target.value)} className="h-8 text-xs rounded-lg" />
              </div>
            </div>
          )}

          {category === 'price' && (
            <div className="space-y-3">
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase">Ürün Adı</Label>
                <Input value={productName} onChange={e => setProductName(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Eski Fiyat</Label>
                  <Input value={oldPrice} onChange={e => setOldPrice(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Yeni Fiyat</Label>
                  <Input value={newPrice} onChange={e => setNewPrice(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Birim</Label>
                  <Input value={currency} onChange={e => setCurrency(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Rozet / Başlık</Label>
                  <Input value={promoBadge} onChange={e => setPromoBadge(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Barkod No</Label>
                  <Input value={productBarcode} onChange={e => setProductBarcode(e.target.value)} className="h-8 text-xs rounded-lg font-mono" />
                </div>
              </div>
            </div>
          )}

          {category === 'article' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Makale Başlığı</Label>
                  <Input value={articleTitle} onChange={e => setArticleTitle(e.target.value)} className="h-8 text-xs rounded-lg font-bold" />
                </div>
                <div>
                  <Label className="text-[10px] font-bold text-slate-500 uppercase">Yazar / Kaynak</Label>
                  <Input value={articleAuthor} onChange={e => setArticleAuthor(e.target.value)} className="h-8 text-xs rounded-lg" />
                </div>
              </div>
              <div>
                <Label className="text-[10px] font-bold text-slate-500 uppercase">İçerik Metni</Label>
                <textarea
                  value={articleContent}
                  onChange={e => setArticleContent(e.target.value)}
                  rows={6}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 dark:bg-slate-950 resize-none font-sans leading-relaxed"
                  placeholder="Yazdırmak istediğiniz uzun metni buraya yapıştırın..."
                />
              </div>
            </div>
          )}

          <div className="pt-2 flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSaveDraft}
              className="flex-1 rounded-lg text-xs font-bold gap-1.5 h-9"
            >
              <BookmarkPlus size={14} /> Taslak Kaydet
            </Button>
            <Button
              onClick={handlePrint}
              className="flex-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold gap-2 h-9 shadow-xs"
            >
              <PrinterCheck size={16} /> Önizle & Yazdır
            </Button>
          </div>
        </Card>

        {/* Live Thermal Paper Preview */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Eye size={13} className="text-teal-500" /> Termal Rulo Canlı Önizleme
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              {pageWidth}px ({pageWidth === 384 ? '57mm' : '80mm'})
            </span>
          </div>

          <div className="bg-slate-900 rounded-xl p-3 shadow-md border border-slate-800 flex justify-center overflow-hidden">
            {livePreviewUrl ? (
              <div className="bg-white rounded-md p-1 shadow-xs max-h-[480px] overflow-y-auto w-full flex justify-center">
                <img
                  src={livePreviewUrl}
                  alt="Thermal preview"
                  className="w-full max-w-[340px] [image-rendering:pixelated] rounded shadow-xs"
                />
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-slate-500 text-xs">
                Yükleniyor...
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
