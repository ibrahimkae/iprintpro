import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { TemplateStudio } from './TemplateStudio';
import { 
  FileText, 
  Tag, 
  ListChecks, 
  QrCode, 
  CreditCard, 
  ShoppingCart,
  Sparkles,
  LayoutGrid,
  Zap
} from 'lucide-react';

import { PRO_TEMPLATES, type ProTemplate } from '../lib/pro-templates';

interface TemplateLibraryProps {
  pageWidth: number;
  onSelect: (template: any) => void;
  onPreviewAndPrint: (dataUrl: string, title: string) => void;
  onOpenPro?: (t: ProTemplate) => void;
}

const quickTextTemplates = [
  { id: 'todo', name: 'Yapılacaklar Listesi', icon: ListChecks, type: 'editor', content: '# GÜNLÜK HEDEFLER\n- [ ] E-postaları kontrol et\n- [ ] Termal yazıcı test çıktıları\n- [ ] Kargo gönderilerini hazırla\n- [ ] Gün sonu raporu' },
  { id: 'label', name: 'Kargo & Adres Etiketi', icon: Tag, type: 'editor', content: '================================\nALICI: Ahmet Yılmaz\nTEL: +90 532 123 45 67\nADRES: Atatürk Cad. No: 12 Kadıköy / İSTANBUL\n================================\nKIRILACAK EŞYA ⚠️' },
  { id: 'shopping', name: 'Haftalık Market Listesi', icon: ShoppingCart, type: 'editor', content: '🛒 MARKET & MUTFAK LİSTESİ\n\n[ ] Süt & Peynir\n[ ] Ekmek & Yumurta\n[ ] Termal Kağıt Rulo\n[ ] Çay & Kahve\n[ ] Meyve / Sebze' },
  { id: 'meeting', name: 'Toplantı Notları', icon: FileText, type: 'editor', content: '📅 TOPLANTI NOTLARI\nKonu:\nKatılımcılar:\n\nAlınan Kararlar:\n1.\n2.\n3.\n\nGörev Dağılımı:' },
];

export const TemplateLibrary: React.FC<TemplateLibraryProps> = ({ 
  pageWidth, 
  onSelect,
  onPreviewAndPrint,
  onOpenPro
}) => {
  const [viewMode, setViewMode] = useState<'studio' | 'quick'>('studio');

  const proSection = (
    <Card className="p-3 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/50 dark:bg-indigo-950/30">
      <div className="flex items-center gap-2 mb-2">
        <Zap size={14} className="text-indigo-600" />
        <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">İşletme Şablonları ({PRO_TEMPLATES.length})</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
        {PRO_TEMPLATES.map(t => (
          <button key={t.id} onClick={() => onOpenPro?.(t)}
            className="text-left p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 transition-colors">
            <span className="block text-[10px] font-bold text-slate-800 dark:text-slate-200 leading-tight">{t.title}</span>
          </button>
        ))}
      </div>
    </Card>
  );

  return (
    <div className="space-y-3">
      {proSection}
      {/* Top Tab Mode Switcher */}
      <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setViewMode('studio')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            viewMode === 'studio'
              ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <Sparkles size={14} /> Şablon Stüdyosu (Görsel & Canlı)
        </button>
        <button
          onClick={() => setViewMode('quick')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            viewMode === 'quick'
              ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <Zap size={14} /> Hızlı Metin Şablonları
        </button>
      </div>

      {viewMode === 'studio' ? (
        <TemplateStudio pageWidth={pageWidth} onPreviewAndPrint={onPreviewAndPrint} />
      ) : (
        <div className="space-y-3">
          <h3 className="text-xs font-black uppercase text-slate-500 tracking-widest px-1">Metin Editörü Şablonları</h3>
          <div className="grid grid-cols-2 gap-2">
            {quickTextTemplates.map((t) => (
              <Card 
                key={t.id} 
                className="p-3.5 rounded-xl flex flex-col items-center gap-2 cursor-pointer hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-all border-slate-200 dark:border-slate-800 shadow-xs"
                onClick={() => onSelect(t)}
              >
                <div className="p-2 bg-white dark:bg-slate-800 rounded-lg shadow-xs border border-slate-100 dark:border-slate-700/60">
                  <t.icon size={20} className="text-teal-600 dark:text-teal-400" />
                </div>
                <span className="text-xs font-bold text-center dark:text-slate-200">{t.name}</span>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
