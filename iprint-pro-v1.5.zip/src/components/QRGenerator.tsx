import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import bwipjs from 'bwip-js';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { logger } from '../lib/logger';
import { QrCode, Barcode, Download, Copy, RefreshCw } from 'lucide-react';

export const QRGenerator = ({ onGenerate }: { onGenerate: (img: string) => void }) => {
  const [type, setType] = useState<'qr' | 'barcode'>('qr');
  const [value, setValue] = useState('https://iprint.pro');
  const [barcodeType, setBarcodeType] = useState('code128');
  const barcodeRef = useRef<HTMLCanvasElement>(null);

  const generate = () => {
    if (type === 'qr') {
      const svg = document.getElementById('qr-gen-svg');
      if (svg) {
        const svgData = new XMLSerializer().serializeToString(svg);
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const size = 384;
          canvas.width = size;
          canvas.height = size;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            // Fill solid white background for 1-bit thermal print clarity
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, size, size);
            
            // Draw centered with safe quiet-zone border
            const pad = 24;
            ctx.drawImage(img, pad, pad, size - pad * 2, size - pad * 2);
            onGenerate(canvas.toDataURL('image/png'));
          }
        };
        img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgData);
      }
    } else {
      try {
        const cleanVal = (value || '12345678').trim();
        const tempCanvas = document.createElement('canvas');
        bwipjs.toCanvas(tempCanvas, {
          bcid: barcodeType,
          text: cleanVal,
          scale: 3,
          height: 12,
          includetext: true,
          textsize: 11,
          textxalign: 'center',
        });

        const finalCanvas = document.createElement('canvas');
        const totalW = 384;
        const padY = 24;
        const bw = Math.min(352, tempCanvas.width);
        const bh = Math.round((bw * tempCanvas.height) / tempCanvas.width);
        finalCanvas.width = totalW;
        finalCanvas.height = bh + padY * 2;
        
        const fCtx = finalCanvas.getContext('2d');
        if (fCtx) {
          fCtx.fillStyle = '#ffffff';
          fCtx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);
          fCtx.drawImage(tempCanvas, (totalW - bw) / 2, padY, bw, bh);
          onGenerate(finalCanvas.toDataURL('image/png'));
        }
      } catch (e) {
        logger.error('Barcode generation failed', e);
      }
    }
  };

  useEffect(() => {
    if (type === 'barcode' && barcodeRef.current) {
      try {
        const cleanVal = (value || '12345678').trim();
        bwipjs.toCanvas(barcodeRef.current, {
          bcid: barcodeType,
          text: cleanVal,
          scale: 2,
          height: 10,
          includetext: true,
          textsize: 10,
          textxalign: 'center',
        });
      } catch (e) {
        // quiet fail on intermediate input
      }
    }
  }, [value, barcodeType, type]);

  return (
    <Card className="p-4 space-y-4 rounded-xl dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex gap-2">
        <Button 
          variant={type === 'qr' ? 'default' : 'outline'} 
          onClick={() => setType('qr')}
          className="flex-1 gap-2 rounded-lg h-9 font-bold text-xs"
        >
          <QrCode size={16}/> QR Kod
        </Button>
        <Button 
          variant={type === 'barcode' ? 'default' : 'outline'} 
          onClick={() => setType('barcode')}
          className="flex-1 gap-2 rounded-lg h-9 font-bold text-xs"
        >
          <Barcode size={16}/> Barkod
        </Button>
      </div>

      <div className="space-y-1.5">
        <Label className="text-[11px] uppercase font-bold text-slate-500">İçerik (Metin veya URL)</Label>
        <Input 
          value={value} 
          onChange={(e) => setValue(e.target.value)}
          placeholder="Metin veya URL girin..."
          className="bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-lg text-xs h-9"
        />
      </div>

      {type === 'barcode' && (
        <div className="space-y-1.5">
          <Label className="text-[11px] uppercase font-bold text-slate-500">Barkod Tipi</Label>
          <Select value={barcodeType} onValueChange={(v) => v && setBarcodeType(v)}>
            <SelectTrigger className="bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-lg text-xs h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-lg">
              <SelectItem value="code128">Code 128 (Standart)</SelectItem>
              <SelectItem value="ean13">EAN-13 (Ürün)</SelectItem>
              <SelectItem value="upca">UPC-A</SelectItem>
              <SelectItem value="qrcode">QR Code</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="flex justify-center items-center p-4 bg-white dark:bg-white rounded-lg border border-slate-200 dark:border-slate-700 min-h-[160px]">
        {type === 'qr' ? (
          <QRCodeSVG 
            id="qr-gen-svg"
            value={value || 'https://iprint.pro'} 
            size={140}
            level="M"
            bgColor="#ffffff"
            fgColor="#000000"
            includeMargin={true}
          />
        ) : (
          <canvas ref={barcodeRef} className="max-w-full" />
        )}
      </div>

      <Button onClick={generate} className="w-full gap-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg h-10 font-bold text-xs shadow-sm">
        <RefreshCw size={15}/> Şablona / Görsele Aktar
      </Button>
    </Card>
  );
};
