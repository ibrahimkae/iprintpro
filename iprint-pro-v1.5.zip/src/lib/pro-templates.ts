/**
 * PROFESYONEL ŞABLON SETI — degisken motoru ile calisir (SPEC-01).
 * Her sablon Toplu Uretim ekranindan TEK veya CSV ile YUZLERCE basilabilir.
 * Barkod tipleri: CODE128 (evrensel) / EAN13 (urun, 12-13 rakam).
 */

export interface ProTemplate {
  id: string;
  title: string;
  tags: string[];
  text: string;
}

export const PRO_TEMPLATES: ProTemplate[] = [
  {
    id: 'pro-kargo-gonderi',
    title: 'Kargo Gonderi Etiketi (Profesyonel)',
    tags: ['kargo', 'gonderi', 'nakliye'],
    text: [
      '=== KARGO ===',
      'ALICI: {Alici}',
      '{Telefon:coksatir}',
      '{Adres:coksatir}',
      '{Ilce} / {Il}',
      'TAKIP: {Takip_No}',
      '{Barkod:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-iade-etiket',
    title: 'Iade Etiketi (E-ticaret)',
    tags: ['iade', 'e-ticaret'],
    text: [
      'IADE GONDERISI',
      'Siparis: {Siparis_No}',
      '{Musteri_Adi}',
      'Sebep: {Sebep:metin=Beden uymadi}',
      'Iade kodu:',
      '{Iade_Kodu:barkod=CODE128}',
      'Depo: {Depo_Adi}'
    ].join('\n')
  },
  {
    id: 'pro-raf-konum',
    title: 'Raf Konum Etiketi (Endustriyel)',
    tags: ['raf', 'depo', 'konum'],
    text: [
      'RAF',
      '{Raf_Kodu}',
      '{Bolum:metin=Ana Depo} - Koridor {Koridor}',
      '{Raf_Kodu:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-parti-skt',
    title: 'Parti / SKT Etiketi (Gida-Kozmetik)',
    tags: ['parti', 'lot', 'skt', 'uretim'],
    text: [
      'PARTI: {Parti_No}',
      'URETIM: {Uretim:tarih=DD.MM.YYYY}',
      'SON KULLANMA: {SKT:tarih=DD.MM.YYYY}',
      '{Parti_No:barkod=CODE128}',
      'Kontrol: {Operator}'
    ].join('\n')
  },
  {
    id: 'pro-seri-imei',
    title: 'Seri No / IMEI Etiketi',
    tags: ['seri', 'imei', 'elektronik'],
    text: [
      'SERI NO / IMEI',
      'Cihaz: {Cihaz:metin=Cihaz modeli}',
      '{Imei:barkod=CODE128}',
      '{Imei}',
      'Garanti bitis: {Garanti:tarih=DD.MM.YYYY}'
    ].join('\n')
  },
  {
    id: 'pro-qr-masa',
    title: 'QR Menu Masa Karti',
    tags: ['qr', 'menu', 'masa', 'restoran'],
    text: [
      'MASA: {Masa_No}',
      '{Isletme_Adi}',
      'Menu icin okutun:',
      '{Menu_Link:qr}'
    ].join('\n')
  },
  {
    id: 'pro-hediye-ceki',
    title: 'Hediye Ceki / Kupon',
    tags: ['kupon', 'hediye', 'ceki'],
    text: [
      'HEDIYE CEKI',
      '{Tutar:para} degerindedir.',
      'KOD: {Kod}',
      '{Kod:barkod=CODE128}',
      'Son gun: {Son_Tarih:tarih=DD.MM.YYYY}',
      '{Isletme_Adi}'
    ].join('\n')
  },
  {
    id: "pro-qc-test",
    title: "Kalite Kontrol (QC) Etiketi",
    tags: ["kalite", "qc", "test", "kontrol"],
    text: [
      "[OK] TEST EDILDI",
      "Urun: {Urun}",
      "Operator: {Operator}",
      "{Test_Tarihi:tarih=DD.MM.YYYY}",
      "Seri: {Seri_No:barkod=CODE128}"
    ].join("\n")
  },
  {
    id: "pro-agirlik-etiket",
    title: "Agirlik / Miktar Etiketi",
    tags: ["agirlik", "kg", "miktar", "manav"],
    text: [
      "{Urun}",
      "MIKTAR: {Miktar:sayi} {Birim:metin=KG}",
      "BIRIM FIYAT: {Birim_Fiyat:para}",
      "TOPLAM: {Toplam:para}",
      "{Lot:barkod=CODE128}"
    ].join("\n")
  },
  {
    id: "pro-palet-nakliye",
    title: "Palet / Nakliye Etiketi",
    tags: ["palet", "nakliye", "lojistik"],
    text: [
      "PALET NO: {Palet_No}",
      "KIMDAN: {Gonderen}",
      "KIME: {Alici}",
      "{Koli_Sayisi:sayi} koli - {Desi:sayi} desi",
      "{Palet_No:barkod=CODE128}"
    ].join("\n")
  },
  {
    id: "pro-stok-sayim",
    title: "Stok Sayim Satiri",
    tags: ["sayim", "stok", "envanter"],
    text: [
      "SAYIM #{Sira_No:sayi}",
      "BARKOD:",
      "{Barkod:barkod=CODE128}",
      "{Urun}",
      "RAF: {Raf}  ADET: ______"
    ].join("\n")
  },
  {
    id: "pro-teknik-bakim",
    title: "Teknik Bakim Etiketi",
    tags: ["bakim", "kombi", "klima", "servis"],
    text: [
      "SONRAKI BAKIM:",
      "{Bakim_Tarihi:tarih=DD.MM.YYYY}",
      "{Cihaz} - {Musteri_Adi}",
      "{Firma_Adi}",
      "Tel: {Firma_Tel}"
    ].join("\n")
  },
  {
    id: 'pro-fis-kdv',
    title: 'KDV\'li Fis Ozeti',
    tags: ['fis', 'kdv', 'kasa'],
    text: [
      'FIS NO: {Fis_No}',
      '{Firma_Adi}',
      'Ara toplam: {Tutar:para}',
      'KDV: {Kdv:para}',
      'GENEL TOPLAM: {Genel_Toplam:para}',
      '{Fis_No:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-picking-satir',
    title: 'Toplama (Picking) Satiri',
    tags: ['toplama', 'picking', 'siparis'],
    text: [
      'SIPARIS: {Siparis_No}',
      'RAF: {Raf}',
      '{Urun}',
      'ADET: ______',
      '{Siparis_No:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-depo-transfer',
    title: 'Depo Transfer Etiketi',
    tags: ['transfer', 'depo'],
    text: [
      'TRANSFER #{Transfer_No}',
      'KAYNAK: {Kaynak_Raf}',
      'HEDEF: {Hedef_Raf}',
      '{Urun} x {Adet:sayi}',
      '{Transfer_No:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-numune-etiket',
    title: 'Numune Etiketi (Satilmaz)',
    tags: ['numune', 'test'],
    text: [
      '** NUMUNE - SATILMAZ **',
      '{Urun}',
      'Verilis: {Tarih:tarih=DD.MM.YYYY}',
      'Sorumlu: {Sorumlu}',
      'Takip: {Kod:barkod=CODE128}'
    ].join('\n')
  },
  {
    id: 'pro-sarf-kutu',
    title: 'Sarf Kutu Acilis Etiketi',
    tags: ['sarf', 'kutu', 'acilis'],
    text: [
      'ICERIK: {Icerik}',
      'ACILIS: {Acilis:tarih=DD.MM.YYYY}',
      'BITIS: {Bitis:tarih=DD.MM.YYYY}',
      'Sorumlu: {Sorumlu}'
    ].join('\n')
  },
  {
    id: 'pro-reklamasyon-fis',
    title: 'Reklamasyon Kayit Fisi',
    tags: ['reklamasyon', 'sikayet'],
    text: [
      'REKLAMASYON KAYDI',
      'Musteri: {Musteri_Adi}',
      'Urun: {Urun}',
      'Sikayet:',
      '{Detay:coksatir}',
      'Kayit: {Kayit_No:barkod=CODE128}'
    ].join('\n')
  }
];

/** Her sablonun formu ORNEK verilerle dolu gelir — canli onizleme icin. */
export const PRO_EXAMPLES: Record<string, Record<string, string>> = {
  'pro-kargo-gonderi': { Alici: 'Ayse Yilmaz', Telefon: '0532 111 22 33', Adres: 'Bagdat Cad. No:112 D:5', Ilce: 'Kadikoy', Il: 'Istanbul', Takip_No: 'TRK7300123', Barkod: '8690123456789' },
  'pro-iade-etiket': { Siparis_No: 'TY-900451', Musteri_Adi: 'Ayse Yilmaz', Sebep: 'Beden uymadi', Iade_Kodu: 'IADE99312', Depo_Adi: 'Merkez Depo' },
  'pro-raf-konum': { Raf_Kodu: 'A-12-03', Bolum: 'Ana Depo', Koridor: '4' },
  'pro-parti-skt': { Parti_No: 'LOT-2026-081', Uretim: '2026-08-01', SKT: '2027-08-01', Operator: 'M. Kaya' },
  'pro-seri-imei': { Cihaz: 'iPhone 15 Pro', Imei: '356938035643809', Garanti: '2027-08-25' },
  'pro-qr-masa': { Masa_No: '7', Isletme_Adi: 'Cafe Merkez', Menu_Link: 'https://ornek.com/menu/7' },
  'pro-hediye-ceki': { Tutar: '250', Kod: 'HEDIYE-2026', Son_Tarih: '2026-12-31', Isletme_Adi: 'Butik Ayse' },
  'pro-qc-test': { Urun: 'Kablosuz Kulaklik X9', Operator: 'QC-2 Hatti', Test_Tarihi: '2026-08-26', Seri_No: 'SN88312004' },
  'pro-agirlik-etiket': { Urun: 'Antep Fistigi', Miktar: '1.5', Birim: 'KG', Birim_Fiyat: '480', Toplam: '720', Lot: 'L77120' },
  'pro-palet-nakliye': { Palet_No: 'PLT-4410', Gonderen: 'Ankara Deposu', Alici: 'Istanbul Magaza', Koli_Sayisi: '18', Desi: '420' },
  'pro-stok-sayim': { Sira_No: '14', Barkod: '8690123456789', Urun: 'Termal Kagit Rulo 57mm', Raf: 'B-03-01' },
  'pro-teknik-bakim': { Bakim_Tarihi: '2027-02-25', Cihaz: 'Kombi Demirdokum', Musteri_Adi: 'Ahmet Demir', Firma_Adi: 'IsiServ', Firma_Tel: '0850 000 00 00' },
  'pro-fis-kdv': { Fis_No: 'FS-00241', Firma_Adi: 'iPrint Market', Tutar: '847.46', Kdv: '152.54', Genel_Toplam: '1000' },
  'pro-picking-satir': { Siparis_No: 'TY-900451', Raf: 'C-07-02', Urun: 'Fotograf Mug Beyaz' },
  'pro-depo-transfer': { Transfer_No: 'TRF-0078', Kaynak_Raf: 'A-01-02', Hedef_Raf: 'D-09-01', Urun: 'LED Ampul E27', Adet: '24' },
  'pro-numune-etiket': { Urun: 'Sabun Numunesi 30g', Tarih: '2026-08-26', Sorumlu: 'Satis Ekibi', Kod: 'NMP-0055' },
  'pro-sarf-kutu': { Icerik: 'Eldiven L Beden', Acilis: '2026-08-26', Bitis: '2026-11-26', Sorumlu: 'Depo Gorevlisi' },
  'pro-reklamasyon-fis': { Musteri_Adi: 'Zeynep K.', Urun: 'Seramik Vazo Buyuk', Detay: 'Kapak kisminda kirik mevcut.', Kayit_No: 'RK-0312' }
};
