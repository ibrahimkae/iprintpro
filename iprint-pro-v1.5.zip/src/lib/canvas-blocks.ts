/**
 * ResolvedBlock[] → canvas çizici (SPEC-01 §5).
 * Metin satırlarını sarar, barkod/QR bloklarını bwip-js ile akış içinde basar.
 */
import bwipjs from 'bwip-js';
import type { ResolvedBlock } from './template-variables';

export interface BlockRenderOptions {
  fontSize?: number;
  fontFamily?: string;
  bold?: boolean;
  align?: 'left' | 'center' | 'right';
  padding?: number;
  /** barkod/qr bloklarının yükseklik çarpanı */
  codeHeightPx?: number;
}

interface Line {
  kind: 'line';
  text: string;
}
interface Code {
  kind: 'code';
  symbology: string; // CODE128 | EAN13 | qrcode
  value: string;
}
type Item = Line | Code;

function flatten(blocks: ResolvedBlock[], maxWidth: number, ctx: CanvasRenderingContext2D): Item[] {
  const items: Item[] = [];
  for (const b of blocks) {
    if (b.kind === 'text') {
      // kelime sarma
      const words = b.value.split(' ');
      let current = '';
      for (const w of words) {
        const test = current ? current + ' ' + w : w;
        if (ctx.measureText(test).width > maxWidth && current) {
          items.push({ kind: 'line', text: current });
          current = w;
        } else {
          current = test;
        }
      }
      if (current || words.length === 0) items.push({ kind: 'line', text: current });
    } else {
      items.push({
        kind: 'code',
        symbology: b.kind === 'qr' ? 'qrcode' : (b.symbology ?? 'CODE128').toUpperCase(),
        value: b.value
      });
    }
  }
  return items;
}

/**
 * Blokları (0,0)'dan itibaren çizer; toplam yüksekliği döndürür.
 * ctx.font/fillStyle çağıran tarafından ayarlanmış olmalı.
 */
export function renderBlocks(
  ctx: CanvasRenderingContext2D,
  width: number,
  blocks: ResolvedBlock[],
  opts: BlockRenderOptions = {}
): number {
  const fontSize = opts.fontSize ?? 24;
  const pad = opts.padding ?? 12;
  const lineHeight = Math.round(fontSize * 1.35);
  const codeH = opts.codeHeightPx ?? Math.round(fontSize * 3);
  const maxWidth = width - pad * 2;

  const alignX = (textWidth: number) => {
    if (opts.align === 'center') return (width - textWidth) / 2;
    if (opts.align === 'right') return width - pad - textWidth;
    return pad;
  };

  const measureLine = (text: string) => ctx.measureText(text).width;

  // Sarma ölçümü doğru fontla yapılsın diye önce font ayarla
  ctx.font = `${opts.bold ? 'bold ' : ''}${fontSize}px ${opts.fontFamily ?? 'sans-serif'}`;
  // KRİTİK: varsayılan 'alphabetic' baz hatta ilk satırın üst yarısı canvas
  // üstünden taşar (yarım satır hatası). 'top' ile y = satırın EN ÜSTÜ olur.
  ctx.textBaseline = 'top';
  const items = flatten(blocks, maxWidth, ctx);

  let y = pad;
  ctx.fillStyle = '#000000';

  for (const item of items) {
    if (item.kind === 'line') {
      ctx.textAlign = 'left';
      ctx.fillText(item.text, alignX(measureLine(item.text)), y);
      y += lineHeight;
    } else {
      try {
        const tmp = document.createElement('canvas');
        const hMm = Math.max(6, Math.round(codeH / 4)); // px→yaklaşık mm
        bwipjs.toCanvas(tmp, {
          bcid: item.symbology,
          text: item.value,
          scale: 2,
          height: hMm,
          includetext: item.symbology !== 'qrcode'
        });
        const scale = Math.min(1, maxWidth / tmp.width);
        const dw = Math.round(tmp.width * scale);
        const dh = Math.round(tmp.height * scale);
        ctx.drawImage(tmp, alignX(dw), y, dw, dh);
        y += dh + Math.round(fontSize * 0.5);
      } catch {
        // Geçersiz değer (ör. EAN13 harf) → değeri metin olarak bas
        ctx.fillText(item.value, pad, y);
        y += lineHeight;
      }
    }
  }

  return y + pad;
}

/**
 * TASARIMLI profesyonel düzen: üstte koyu başlık bandı (beyaz kalın yazı),
 * altında gövde blokları. Tüm işletme şablonlarında tutarlı kurumsal görünüm.
 */
export function renderProDesigned(
  ctx: CanvasRenderingContext2D,
  width: number,
  title: string,
  blocks: import('./template-variables').ResolvedBlock[],
  opts: BlockRenderOptions = {}
): number {
  const bandH = 34;
  ctx.save();
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, width, bandH);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 15px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title.toUpperCase().slice(0, 28), width / 2, bandH / 2);
  ctx.textAlign = 'left';
  ctx.restore();

  ctx.save();
  ctx.translate(0, bandH);
  const bodyH = renderBlocks(ctx, width, blocks, opts);
  ctx.restore();

  // Alt kapanış çizgisi
  ctx.fillStyle = '#000000';
  ctx.fillRect(12, bandH + bodyH - 4, width - 24, 2);

  return bandH + bodyH + 6;
}
