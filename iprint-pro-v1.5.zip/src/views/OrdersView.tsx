import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Label } from '../components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '../components/ui/select';
import { formatMoney, type ResolvedBlock } from '../lib/template-variables';
import { ORDER_STATUS_TR, type NormalizedOrder } from '../lib/trendyol-types';
import {
  ArrowLeft, Printer, RefreshCw, Loader2, AlertTriangle,
  CheckCircle2, Package, FileText
} from 'lucide-react';

export interface OrdersViewProps {
  apiBase: string; // '' for same-origin dev
  pageWidth: number;
  onPrintShippingLabel: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onPrintPackingSlip: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onBack: () => void;
}

const PAGE_SIZE = 50;
const PRINTED_KEY = 'iprint_printed_packages_v1';
const PRINT_CONFIRM_MSG = 'Bu paket için etiket basılmış. Yine de basılsın mı?';

type StatusFilter = '' | 'Created' | 'Picking' | 'Invoiced';

const STATUS_FILTERS: { value: StatusFilter; label: string }[] = [
  { value: '', label: 'Tümü' },
  { value: 'Created', label: 'Yeni' },
  { value: 'Picking', label: 'Hazırlanıyor' },
  { value: 'Invoiced', label: 'Faturalandırıldı' }
];

const STATUS_BADGE: Record<string, string> = {
  Created: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300',
  Picking: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300',
  Invoiced: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200 dark:border-sky-900 text-sky-700 dark:text-sky-300',
  Shipped: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900 text-indigo-700 dark:text-indigo-300',
  Delivered: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-900 text-teal-700 dark:text-teal-300',
  Cancelled: 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-900 text-red-600 dark:text-red-400'
};

export function packageKey(o: NormalizedOrder): string {
  return `${o.orderNumber}:${o.packageId}`;
}

function loadPrintedPackages(): Set<string> {
  try {
    const raw = localStorage.getItem(PRINTED_KEY);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.filter((v): v is string => typeof v === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

function savePrintedPackages(set: Set<string>): void {
  try {
    localStorage.setItem(PRINTED_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // kota dolu / gizli mod — işaret kaybı kabul edilir
  }
}

function formatDateTr(ms: number): string {
  const d = new Date(ms);
  if (Number.isNaN(d.getTime())) return String(ms);
  return d.toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' });
}

async function extractServerMessage(res: Response): Promise<string> {
  let fallback = `HTTP ${res.status}`;
  try {
    const j = await res.json();
    if (typeof j?.message === 'string' && j.message) return j.message;
    if (typeof j?.error === 'string' && j.error) return j.error;
  } catch {
    try {
      const t = await res.text();
      if (t) return t;
    } catch {
      // gövde okunamadı → status kodu
    }
  }
  return fallback;
}

/* ---------- Blok üreticileri (SPEC-03 §3.2) ---------- */

export function buildShippingBlocks(o: NormalizedOrder): ResolvedBlock[] {
  const blocks: ResolvedBlock[] = [
    { kind: 'text', value: 'KARGO ETİKETİ' },
    { kind: 'barcode', value: o.packageId, symbology: 'CODE128' }
  ];

  if (o.customerName.trim()) blocks.push({ kind: 'text', value: o.customerName });
  if (o.customerPhone?.trim()) blocks.push({ kind: 'text', value: o.customerPhone });
  if (o.address.line1.trim()) blocks.push({ kind: 'text', value: o.address.line1 });

  const districtCity = [o.address.district, o.address.city]
    .map(s => s.trim())
    .filter(Boolean)
    .join(' / ');
  if (districtCity) blocks.push({ kind: 'text', value: districtCity });

  const postalCountry = [o.address.postalCode, o.address.country]
    .map(s => s?.trim() ?? '')
    .filter(Boolean)
    .join(' ');
  if (postalCountry) blocks.push({ kind: 'text', value: postalCountry });

  blocks.push({
    kind: 'text',
    value: `${o.items.length} ürün • ${formatMoney(o.totalPrice)}`
  });

  const cargoLine = [o.cargoProviderName, o.cargoTrackingNumber]
    .map(s => s?.trim() ?? '')
    .filter(Boolean)
    .join(' · ');
  if (cargoLine) blocks.push({ kind: 'text', value: cargoLine });

  blocks.push({ kind: 'text', value: formatDateTr(o.createdAt) });
  return blocks;
}

export function buildPackingBlocks(o: NormalizedOrder): ResolvedBlock[] {
  const blocks: ResolvedBlock[] = [
    { kind: 'text', value: 'PAKET İÇİ SİPARİŞ FİŞİ' },
    { kind: 'qr', value: o.orderNumber },
    { kind: 'text', value: `Sipariş: ${o.orderNumber}` }
  ];

  for (const item of o.items) {
    blocks.push({
      kind: 'text',
      value: `${item.quantity}x ${item.name}${item.variant ? ` (${item.variant})` : ''}`
    });
  }

  blocks.push({ kind: 'text', value: 'Bizi tercih ettiğiniz için teşekkürler!' });
  return blocks;
}

/* ---------- Görünüm ---------- */

export function OrdersView(props: OrdersViewProps) {
  const [orders, setOrders] = useState<NormalizedOrder[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('');
  const [days, setDays] = useState<'1' | '7' | '30'>('7');
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [hasMore, setHasMore] = useState(false);

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [printed, setPrinted] = useState<Set<string>>(() => loadPrintedPackages());
  const [printing, setPrinting] = useState(false);

  const serverPageRef = useRef(0);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const fetchPage = useCallback(
    async (page: number, replace: boolean) => {
      if (replace) setLoading(true);
      else setLoadingMore(true);
      setError(null);

      try {
        const params = new URLSearchParams({
          status: statusFilter,
          page: String(page),
          size: String(PAGE_SIZE),
          days
        });
        const res = await fetch(`${props.apiBase}/trendyol/orders?${params.toString()}`);
        if (!res.ok) throw new Error(await extractServerMessage(res));

        const data: unknown = await res.json();
        const list: NormalizedOrder[] = Array.isArray(data)
          ? (data as NormalizedOrder[])
          : Array.isArray((data as { orders?: NormalizedOrder[] })?.orders)
            ? ((data as { orders: NormalizedOrder[] }).orders)
            : [];

        if (!mountedRef.current) return;
        serverPageRef.current = page;
        setHasMore(list.length === PAGE_SIZE);
        setOrders(prev => (replace ? list : [...prev, ...list]));
        if (replace) {
          setSelected(new Set());
          setVisibleCount(PAGE_SIZE);
        } else {
          setVisibleCount(c => c + PAGE_SIZE);
        }
      } catch (e) {
        if (mountedRef.current) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (mountedRef.current) {
          setLoading(false);
          setLoadingMore(false);
        }
      }
    },
    [props.apiBase, statusFilter, days]
  );

  useEffect(() => {
    void fetchPage(0, true);
  }, [fetchPage]);

  const visible = useMemo(() => orders.slice(0, visibleCount), [orders, visibleCount]);
  const selectedCount = useMemo(
    () => orders.filter(o => selected.has(packageKey(o))).length,
    [orders, selected]
  );
  const allVisibleSelected =
    visible.length > 0 && visible.every(o => selected.has(packageKey(o)));

  function toggleRow(key: string) {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleAllVisible() {
    setSelected(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) visible.forEach(o => next.delete(packageKey(o)));
      else visible.forEach(o => next.add(packageKey(o)));
      return next;
    });
  }

  function handleShowMore() {
    if (visibleCount < orders.length) {
      setVisibleCount(c => c + PAGE_SIZE);
      return;
    }
    if (hasMore && !loading && !loadingMore) void fetchPage(serverPageRef.current + 1, false);
  }

  async function runPrint(kind: 'label' | 'slip') {
    const chosen = orders.filter(o => selected.has(packageKey(o)));
    if (chosen.length === 0 || printing) return;

    setPrinting(true);
    const printedSet = new Set(printed);
    const failures: string[] = [];

    try {
      for (const o of chosen) {
        const key = packageKey(o);
        if (printedSet.has(key) && !window.confirm(PRINT_CONFIRM_MSG)) continue;

        try {
          if (kind === 'label') {
            await props.onPrintShippingLabel(buildShippingBlocks(o), 'kargo-etiketi');
          } else {
            await props.onPrintPackingSlip(buildPackingBlocks(o), 'koli-fisi');
          }
          printedSet.add(key);
          savePrintedPackages(printedSet);
          setPrinted(new Set(printedSet));
        } catch (e) {
          failures.push(`${o.packageId}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }
    } finally {
      setPrinting(false);
      if (failures.length > 0) setError(failures.slice(0, 3).join(' • '));
    }
  }

  const showMoreAvailable = visibleCount < orders.length || hasMore;

  return (
    <motion.div
      key="orders"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3 pb-16"
    >
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={props.onBack}
          className="rounded-lg bg-white dark:bg-slate-900 shadow-xs border border-slate-200 dark:border-slate-800 dark:text-slate-200 text-xs h-8"
        >
          <ArrowLeft size={14} className="mr-1.5" /> Geri
        </Button>
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
          Siparişler · Trendyol ~{props.pageWidth} mm
        </span>
      </div>

      <Card className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap gap-1.5">
            {STATUS_FILTERS.map(f => (
              <button
                key={f.value || 'all'}
                type="button"
                onClick={() => setStatusFilter(f.value)}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === f.value
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <Label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider shrink-0">
              Son
            </Label>
            <Select value={days} onValueChange={v => setDays((v ?? '7') as '1' | '7' | '30')}>
              <SelectTrigger className="w-24 h-8 rounded-lg bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-xs font-bold">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1" className="text-xs">1 gün</SelectItem>
                <SelectItem value="7" className="text-xs">7 gün</SelectItem>
                <SelectItem value="30" className="text-xs">30 gün</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              disabled={loading}
              onClick={() => void fetchPage(0, true)}
              className="h-8 rounded-lg text-xs font-bold px-3 dark:border-slate-700"
            >
              {loading ? (
                <Loader2 size={13} className="mr-1.5 animate-spin" />
              ) : (
                <RefreshCw size={13} className="mr-1.5" />
              )}
              Yenile
            </Button>
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-2 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 p-2.5">
            <AlertTriangle size={14} className="mt-0.5 text-red-500 shrink-0" />
            <span className="text-xs font-bold text-red-600 dark:text-red-400">{error}</span>
          </div>
        )}
      </Card>

      {loading ? (
        <Card className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 flex items-center justify-center">
          <Loader2 size={22} className="animate-spin text-teal-600" />
        </Card>
      ) : orders.length === 0 ? (
        <Card className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 text-center">
          <Package size={22} className="mx-auto mb-2 text-slate-300" />
          <div className="text-xs font-bold text-slate-400">Sipariş bulunamadı.</div>
        </Card>
      ) : (
        <Card className="rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 overflow-hidden">
          <label className="flex items-center gap-2 p-2.5 border-b border-slate-100 dark:border-slate-800 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={allVisibleSelected}
              onChange={toggleAllVisible}
              className="h-4 w-4 rounded accent-teal-600"
            />
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Tümünü seç (görünen {visible.length})
            </span>
            <span className="ml-auto text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
              {selectedCount} seçili
            </span>
          </label>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {visible.map(o => {
              const key = packageKey(o);
              const isPrinted = printed.has(key);
              const trStatus = ORDER_STATUS_TR[o.status] ?? o.status;
              return (
                <label
                  key={key}
                  className={`flex items-center gap-2.5 p-2.5 cursor-pointer transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60 ${
                    selected.has(key) ? 'bg-teal-50/60 dark:bg-teal-950/20' : ''
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selected.has(key)}
                    onChange={() => toggleRow(key)}
                    className="h-4 w-4 rounded accent-teal-600 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                        {o.customerName}
                      </span>
                      {isPrinted && (
                        <span className="inline-flex items-center gap-0.5 shrink-0 py-0.5 px-1.5 rounded-md bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 text-[10px] font-bold text-teal-600 dark:text-teal-400">
                          <CheckCircle2 size={10} /> Basıldı
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        #{o.packageId}
                      </span>
                      <span
                        className={`py-0.5 px-1.5 rounded-md border text-[10px] font-bold ${
                          STATUS_BADGE[o.status] ??
                          'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {trStatus}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {o.items.reduce((n, i) => n + i.quantity, 0)} kalem
                      </span>
                    </div>
                  </div>
                  <span className="shrink-0 text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
                    {formatMoney(o.totalPrice)}
                  </span>
                </label>
              );
            })}
          </div>

          {showMoreAvailable && (
            <button
              type="button"
              onClick={handleShowMore}
              disabled={loadingMore}
              className="w-full py-2.5 text-xs font-bold text-teal-600 dark:text-teal-400 border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors disabled:opacity-60 flex items-center justify-center gap-1.5"
            >
              {loadingMore ? (
                <>
                  <Loader2 size={13} className="animate-spin" /> Yükleniyor…
                </>
              ) : (
                <>Daha fazla ({Math.max(orders.length - visibleCount, hasMore ? PAGE_SIZE : 0)})</>
              )}
            </button>
          )}
        </Card>
      )}

      <div className="sticky bottom-3 z-10">
        <Card className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm bg-white/95 dark:bg-slate-900/95 backdrop-blur flex gap-2">
          <Button
            disabled={selectedCount === 0 || printing}
            onClick={() => void runPrint('label')}
            className="flex-1 h-9 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs"
          >
            {printing ? <Loader2 size={14} className="mr-1.5 animate-spin" /> : <Printer size={14} className="mr-1.5" />}
            Etiket Bas ({selectedCount})
          </Button>
          <Button
            variant="outline"
            disabled={selectedCount === 0 || printing}
            onClick={() => void runPrint('slip')}
            className="flex-1 h-9 rounded-xl font-bold text-xs dark:border-slate-700"
          >
            <FileText size={14} className="mr-1.5" /> Koli Fişi Bas ({selectedCount})
          </Button>
        </Card>
      </div>
    </motion.div>
  );
}
