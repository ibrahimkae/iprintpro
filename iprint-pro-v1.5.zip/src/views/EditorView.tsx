import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import {
  X, Code, FileCode, Minus, Plus,
  AlignLeft, AlignCenter, AlignRight, AlignJustify, Underline, Bold, Italic
} from 'lucide-react';

export interface EditorViewProps {
  text: string;
  setText: React.Dispatch<React.SetStateAction<string>>;
  setSelectedText: (s: string) => void;
  fontSize: number;
  setFontSize: React.Dispatch<React.SetStateAction<number>>;
  alignment: 'left' | 'center' | 'right' | 'justify';
  setAlignment: (a: 'left' | 'center' | 'right' | 'justify') => void;
  isBold: boolean;
  setIsBold: React.Dispatch<React.SetStateAction<boolean>>;
  isItalic: boolean;
  setIsItalic: React.Dispatch<React.SetStateAction<boolean>>;
  isUnderline: boolean;
  setIsUnderline: React.Dispatch<React.SetStateAction<boolean>>;
  fontFamily: string;
  setFontFamily: (f: string) => void;
  customFonts: { name: string; url: string }[];
  handleFontUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  showHtmlEditor: boolean;
  setShowHtmlEditor: React.Dispatch<React.SetStateAction<boolean>>;
  htmlTemplate: string;
  setHtmlTemplate: React.Dispatch<React.SetStateAction<string>>;
  pageWidth: number;
  onGeneratePreview: () => void;
  onBack: () => void;
}

export function EditorView(p: EditorViewProps) {
  const { t } = useTranslation();
  const textAreaStyle: React.CSSProperties = {
    fontSize: `${p.fontSize}px`,
    textAlign: p.alignment === 'justify' ? 'left' : p.alignment,
    fontWeight: p.isBold ? 'bold' : 'normal',
    fontStyle: p.isItalic ? 'italic' : 'normal',
    textDecoration: p.isUnderline ? 'underline' : 'none',
    fontFamily: p.fontFamily,
    lineHeight: 1.3
  };

  return (
    <motion.div key="editor" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" onClick={p.onBack} className="rounded-lg text-xs h-8"><X size={14} className="mr-1" /> {t('cancel')}</Button>
        <div className="flex gap-1.5">
          <Button variant="outline" size="icon" onClick={() => p.setShowHtmlEditor(!p.showHtmlEditor)} className={`h-8 w-8 rounded-lg ${p.showHtmlEditor ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 border-indigo-200' : 'text-slate-500 border-slate-200 dark:border-slate-800'}`} title="HTML Şablon"><Code size={14}/></Button>
          <Button onClick={p.onGeneratePreview} className="rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs px-3 h-8 shadow-xs">{t('print_preview')}</Button>
        </div>
      </div>

      {p.showHtmlEditor && (
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/50 rounded-xl border border-indigo-200 dark:border-indigo-800 space-y-2">
          <div className="flex items-center gap-2 mb-1">
            <FileCode size={13} className="text-indigo-600 dark:text-indigo-400"/>
            <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300">HTML Editor</span>
            <Button variant="ghost" size="sm" onClick={() => p.setShowHtmlEditor(false)} className="ml-auto h-5 w-5 rounded-md p-0"><X size={10}/></Button>
          </div>
          <textarea
            value={p.htmlTemplate}
            onChange={(e) => p.setHtmlTemplate(e.target.value)}
            className="w-full h-28 text-[11px] p-2.5 rounded-lg border border-indigo-200 dark:border-indigo-800 dark:bg-slate-900 dark:text-slate-200 font-mono resize-none leading-tight"
            placeholder="Full HTML desteklenir - {{BASLIK}}, {{METIN}}, {{TARIH}} değişkenleri"
          />
          <div className="flex flex-wrap gap-1">
            <Button variant="outline" size="sm" onClick={() => p.setHtmlTemplate(`<html><body style="text-align: center;"><h1>{{BASLIK}}</h1><p>{{METIN}}</p></body></html>`)} className="text-[9px] h-6 px-2 rounded-md">Basit</Button>
            <Button variant="outline" size="sm" onClick={() => p.setHtmlTemplate(`<html><body><table style="width:100%;border:1px solid #000;border-collapse:collapse;"><tr><th style="border:1px solid #000;padding:8px;">{{BASLIK}}</th></tr><tr><td style="border:1px solid #000;padding:8px;">{{METIN}}</td></tr></table></body></html>`)} className="text-[9px] h-6 px-2 rounded-md">Tablo</Button>
            <Button variant="outline" size="sm" onClick={() => p.setHtmlTemplate(`<html><body style="font-family: monospace;"><div style="border:2px solid #000;padding:10px;"><b>{{BASLIK}}</b><br>{{METIN}}<br><small>{{TARIH}}</small></div></body></html>`)} className="text-[9px] h-6 px-2 rounded-md">Kutu</Button>
            <Button variant="outline" size="sm" onClick={() => p.setHtmlTemplate(`<html><body style="text-align:center;padding:20px;"><h2>{{BASLIK}}</h2><p>{{METIN}}</p><hr/><small>{{TARIH}}</small></div></body></html>`)} className="text-[9px] h-6 px-2 rounded-md">Resmi</Button>
            <Button variant="outline" size="sm" onClick={() => p.setHtmlTemplate(`<html><body style="font-family:Arial;"><div style="background:#f5f5f5;padding:15px;border-radius:10px;"><h3>{{BASLIK}}</h3><p>{{METIN}}</p><small>{{TARIH}}</small></div></body></html>`)} className="text-[9px] h-6 px-2 rounded-md">Kart</Button>
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            <Label className="text-[9px] text-indigo-600 dark:text-indigo-400">Değişkenler:</Label>
            <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{BASLIK}}'}</span>
            <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{METIN}}'}</span>
            <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{TARIH}}'}</span>
            <span className="text-[8px] bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{'{{SAAT}}'}</span>
          </div>
        </div>
      )}

      <div className="flex flex-col items-center">
        <Card className="rounded-xl border border-teal-200 dark:border-teal-800 shadow-sm bg-white dark:bg-slate-900 w-full" style={{ maxWidth: `${Math.min(p.pageWidth, window.innerWidth - 32)}px` }}>
          <textarea
            value={p.text}
            onChange={(e) => p.setText(e.target.value)}
            onSelect={(e) => {
              const target = e.target as HTMLTextAreaElement;
              const start = target.selectionStart;
              const end = target.selectionEnd;
              if (start !== end) {
                p.setSelectedText(p.text.substring(start, end));
              }
            }}
            placeholder={t('editor.placeholder')}
            className="w-full bg-transparent border-none focus:ring-0 resize-none p-3.5 dark:text-slate-200 dark:placeholder:text-slate-600 text-xs leading-relaxed"
            style={{ ...textAreaStyle, minHeight: '120px', maxHeight: '180px' }}
          />
        </Card>
      </div>
      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between"><Label className="font-bold text-slate-600 dark:text-slate-400 text-xs">Yazı Boyutu</Label><span className="text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30 px-2 py-0.5 rounded-md">{p.fontSize}px</span></div>
        <div className="flex items-center gap-1.5">
          <Button variant="outline" size="icon" className="h-7 w-7 rounded-lg dark:border-slate-700 dark:bg-slate-800" onClick={() => p.setFontSize(prev => Math.max(12, prev - 1))}><Minus size={12}/></Button>
          <Input type="number" value={p.fontSize} onChange={e => p.setFontSize(Number(e.target.value)||24)} className="flex-1 text-center font-bold dark:bg-slate-800 dark:border-slate-700 dark:text-white h-7 text-xs rounded-lg" />
          <Button variant="outline" size="icon" className="h-7 w-7 rounded-lg dark:border-slate-700 dark:bg-slate-800" onClick={() => p.setFontSize(prev => Math.min(200, prev + 1))}><Plus size={12}/></Button>
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          <Button variant={p.alignment==='left'?'default':'outline'} onClick={()=>p.setAlignment('left')} className="rounded-lg h-7 text-xs p-0"><AlignLeft size={13}/></Button>
          <Button variant={p.alignment==='center'?'default':'outline'} onClick={()=>p.setAlignment('center')} className="rounded-lg h-7 text-xs p-0"><AlignCenter size={13}/></Button>
          <Button variant={p.alignment==='right'?'default':'outline'} onClick={()=>p.setAlignment('right')} className="rounded-lg h-7 text-xs p-0"><AlignRight size={13}/></Button>
          <Button variant={p.alignment==='justify'?'default':'outline'} onClick={()=>p.setAlignment('justify')} className="rounded-lg h-7 text-xs p-0"><AlignJustify size={13}/></Button>
          <Button variant={p.isUnderline?'default':'outline'} onClick={()=>p.setIsUnderline(!p.isUnderline)} className="rounded-lg h-7 text-xs p-0"><Underline size={13}/></Button>
        </div>
        <div className="flex gap-1.5">
           <Button variant={p.isBold?'default':'outline'} onClick={()=>p.setIsBold(!p.isBold)} className="flex-1 rounded-lg h-7 text-xs"><Bold size={12}/></Button>
           <Button variant={p.isItalic?'default':'outline'} onClick={()=>p.setIsItalic(!p.isItalic)} className="flex-1 rounded-lg h-7 text-xs"><Italic size={12}/></Button>
           <Select value={p.fontFamily} onValueChange={(v) => v && p.setFontFamily(v)}>
             <SelectTrigger className="flex-[2] rounded-lg font-bold h-7 text-[11px]"><SelectValue /></SelectTrigger>
             <SelectContent className="rounded-lg">
               <SelectItem value="Outfit">Outfit</SelectItem>
               <SelectItem value="JetBrains Mono">Mono</SelectItem>
               <SelectItem value="serif">Serif</SelectItem>
               {p.customFonts.map(f => (<SelectItem key={f.name} value={f.name}>{f.name}</SelectItem>))}
             </SelectContent>
           </Select>
        </div>
        <div className="relative"><Button variant="outline" className="w-full rounded-lg border-dashed text-[11px] h-7">Özel Font Yükle (.ttf / .woff)</Button><input type="file" accept=".ttf,.woff" onChange={p.handleFontUpload} title="Font Yükle" className="absolute inset-0 opacity-0 cursor-pointer"/></div>
      </div>
    </motion.div>
  );
}
