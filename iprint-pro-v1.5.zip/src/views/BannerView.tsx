import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import {
  X, Minus, Plus, Tag, Columns, Sparkles, Eye,
  AlignHorizontalJustifyCenter, AlignVerticalJustifyCenter
} from 'lucide-react';

export interface BannerViewProps {
  bannerText: string;
  setBannerText: (s: string) => void;
  bannerType: 'banner' | 'etiket';
  setBannerType: (t: 'banner' | 'etiket') => void;
  bannerOrientation: 'horizontal' | 'vertical';
  setBannerOrientation: (o: 'horizontal' | 'vertical') => void;
  bannerFontSize: number;
  setBannerFontSize: React.Dispatch<React.SetStateAction<number>>;
  previewImage: string | null;
  onGeneratePreview: () => void;
  onBack: () => void;
}

export function BannerView(p: BannerViewProps) {
  const { t } = useTranslation();
  return (
    <motion.div key="banner" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={p.onBack} className="rounded-lg bg-white dark:bg-slate-900 shadow-xs border border-slate-200 dark:border-slate-800 dark:text-slate-200 text-xs h-8">
          <X size={14} className="mr-1.5" /> {t('cancel')}
        </Button>
        <Button onClick={p.onGeneratePreview} disabled={!p.bannerText} className="rounded-lg bg-teal-600 hover:bg-teal-700 dark:bg-teal-700 text-white font-bold text-xs h-8 px-4">
          {t('print_preview')}
        </Button>
      </div>

      <Card className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900">
        <Input
          value={p.bannerText}
          onChange={e => p.setBannerText(e.target.value)}
          placeholder="YAZI VEYA ETİKET METNİ GİRİN..."
          className="w-full bg-transparent border-none text-xl font-bold text-center uppercase tracking-wider placeholder:text-slate-400 dark:placeholder:text-slate-600 text-slate-900 dark:text-white focus-visible:ring-0"
        />
      </Card>

      <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-xs">
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <Label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Yazı Boyutu (Punto)</Label>
            <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">{p.bannerFontSize}px</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg dark:border-slate-700" onClick={() => p.setBannerFontSize(prev => Math.max(12, prev - 4))}><Minus size={13}/></Button>
            <Input type="number" value={p.bannerFontSize} onChange={e => p.setBannerFontSize(Number(e.target.value)||48)} className="flex-1 text-center font-bold h-8 text-sm bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white" />
            <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg dark:border-slate-700" onClick={() => p.setBannerFontSize(prev => Math.min(400, prev + 4))}><Plus size={13}/></Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div className="space-y-1.5">
            <Label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Baskı Türü</Label>
            <div className="flex bg-slate-100 dark:bg-slate-800/90 p-1 rounded-xl border border-slate-200 dark:border-slate-700 gap-1">
              <button
                type="button"
                onClick={() => p.setBannerType('banner')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  p.bannerType === 'banner'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Columns size={13} />
                <span>Banner (Şerit)</span>
              </button>
              <button
                type="button"
                onClick={() => p.setBannerType('etiket')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  p.bannerType === 'etiket'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Tag size={13} />
                <span>Etiket (Kutu)</span>
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Yazı Dizilişi</Label>
            <div className="flex bg-slate-100 dark:bg-slate-800/90 p-1 rounded-xl border border-slate-200 dark:border-slate-700 gap-1">
              <button
                type="button"
                onClick={() => p.setBannerOrientation('horizontal')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  p.bannerOrientation === 'horizontal'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <AlignHorizontalJustifyCenter size={13} />
                <span>Yatay (Boydan)</span>
              </button>
              <button
                type="button"
                onClick={() => p.setBannerOrientation('vertical')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  p.bannerOrientation === 'vertical'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <AlignVerticalJustifyCenter size={13} />
                <span>Dikey (Alt Alta)</span>
              </button>
            </div>
          </div>
        </div>

        <div className="text-[11px] text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700/80 flex items-center gap-2">
          <Sparkles size={14} className="text-teal-500 shrink-0" />
          <span>
            {p.bannerType === 'banner'
              ? (p.bannerOrientation === 'horizontal' ? 'Banner Yatay: Metin rulo uzunluğu boyunca dev boyutta 90° açıyla basılır.' : 'Banner Dikey: Harfler yukarıdan aşağıya rulo boyunca alt alta basılır.')
              : (p.bannerOrientation === 'horizontal' ? 'Etiket Yatay: Çerçeveli, kompakt genişlikte yatay etiket.' : 'Etiket Dikey: Kompakt dikey yönlü kutulu etiket çıktısı.')}
          </span>
        </div>
      </div>

      {p.previewImage && (
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex flex-col items-center overflow-hidden shadow-md space-y-2">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
            <Eye size={12} className="text-teal-400" /> Canlı Termal Önizleme
          </div>
          <div className="bg-white p-2 rounded-lg max-h-[300px] overflow-y-auto w-full flex justify-center shadow-inner">
            <img src={p.previewImage} alt="Banner Preview" className="max-w-full h-auto [image-rendering:pixelated] rounded" />
          </div>
        </div>
      )}
    </motion.div>
  );
}
