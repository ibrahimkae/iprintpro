import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { printer as singletonPrinter } from '../lib/printer-instance';
import { logger } from '../lib/logger';
import { DeviceProfile, findDeviceProfile, makeProfileId } from '../lib/device-profiles';

interface PrinterContextValue {
  isConnected: boolean;
  batteryLevel: number | null;
  deviceName: string | null;
  /** Remembered settings for the connected printer (null = first time) */
  activeProfile: DeviceProfile | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  refreshBattery: () => Promise<void>;
}

const PrinterContext = createContext<PrinterContextValue | null>(null);

export function usePrinter(): PrinterContextValue {
  const ctx = useContext(PrinterContext);
  if (!ctx) throw new Error('usePrinter must be used inside <PrinterProvider>');
  return ctx;
}

export function PrinterProvider({ children }: { children: React.ReactNode }) {
  const [isConnected, setIsConnected] = useState(false);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [activeProfile, setActiveProfile] = useState<DeviceProfile | null>(null);
  const printer = singletonPrinter;

  const connect = useCallback(async () => {
    try {
      await printer.initialize();
      const success = await printer.connect();
      setIsConnected(Boolean(success));
      if (success) {
        printer.setBatteryCallback((level) => setBatteryLevel(level));
        await printer.getBatteryLevel().then(setBatteryLevel).catch(() => {});

        // Restore remembered device profile, if any
        const profileId = makeProfileId(printer.getDeviceId(), printer.getDeviceName());
        setActiveProfile(findDeviceProfile(profileId));
      }
    } catch (error: any) {
      const msg = error?.message || String(error);
      const cancelled =
        error?.name === 'NotFoundError' ||
        msg.includes('User cancelled') ||
        msg.includes('cancelled') ||
        msg.includes('requestDevice');
      if (cancelled) {
        logger.info('Bluetooth aygıt seçimi kullanıcı tarafından iptal edildi.');
        return;
      }
      logger.error('Bağlantı hatası:', error);
    }
  }, [printer]);

  const disconnect = useCallback(() => {
    printer.disconnect();
    setIsConnected(false);
    setBatteryLevel(null);
  }, [printer]);

  const refreshBattery = useCallback(async () => {
    const level = await printer.getBatteryLevel();
    setBatteryLevel(level);
  }, [printer]);

  const value = useMemo<PrinterContextValue>(
    () => ({
      isConnected,
      batteryLevel,
      deviceName: printer.getDeviceName(),
      activeProfile,
      connect,
      disconnect,
      refreshBattery
    }),
    [isConnected, batteryLevel, activeProfile, connect, disconnect, refreshBattery]
  );

  return <PrinterContext.Provider value={value}>{children}</PrinterContext.Provider>;
}
