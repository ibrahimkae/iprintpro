import React from 'react';
import { CommunityTemplate, LabelDimension, ThermalPaperStyle } from '../types';
import { ThermalTemplateRenderer } from './ThermalTemplateRenderer';
import { Heart } from 'lucide-react';

interface CommunityCardProps {
  item: CommunityTemplate;
  dimension: LabelDimension;
  paperStyle?: ThermalPaperStyle;
  isLiked?: boolean;
  onToggleLike?: (id: string, e: React.MouseEvent) => void;
  onSelect: (item: CommunityTemplate) => void;
}

export const CommunityCard: React.FC<CommunityCardProps> = ({
  item,
  dimension,
  paperStyle = 'standard',
  isLiked = false,
  onToggleLike,
  onSelect
}) => {
  const tpl = item.template;
  const currentPaperStyle = item.paperStyle || paperStyle;
  const targetWidth = tpl.recommendedWidthMm || dimension.widthMm || 57;

  return (
    <div
      onClick={() => onSelect(item)}
      className="group relative break-inside-avoid mb-3 sm:mb-4 bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800/80 shadow-xs hover:shadow-lg hover:border-slate-300 dark:hover:border-slate-700 transition-all duration-300 cursor-pointer flex flex-col"
    >
      {/* Pure Minimalist Thermal Preview Image Container */}
      <div className="w-full relative flex items-center justify-center p-2.5 sm:p-3 bg-slate-50/70 dark:bg-slate-950/70 overflow-hidden">
        <div className="transform transition-transform duration-300 group-hover:scale-[1.02] w-full flex justify-center">
          <ThermalTemplateRenderer
            template={tpl}
            data={tpl.defaultData}
            widthMm={targetWidth}
            heightMm={tpl.heightMm || dimension.heightMm}
            paperStyle={currentPaperStyle}
            scale={0.9}
          />
        </div>

        {/* Minimal Subtle Like Heart in Top-Right Corner */}
        {onToggleLike && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleLike(item.id, e);
            }}
            className={`absolute top-2.5 right-2.5 w-7 h-7 rounded-full flex items-center justify-center backdrop-blur-md transition-all z-10 ${
              isLiked
                ? 'bg-rose-500 text-white shadow-sm'
                : 'bg-white/80 dark:bg-slate-900/80 text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100'
            }`}
            title="Beğen"
          >
            <Heart size={13} fill={isLiked ? 'currentColor' : 'none'} />
          </button>
        )}
      </div>
    </div>
  );
};
