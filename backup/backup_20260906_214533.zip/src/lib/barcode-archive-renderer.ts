import bwipjs from 'bwip-js';
import { BarcodeArchiveRecord } from './barcode-archive-storage';
import { logger } from './logger';

export interface RenderArchiveLabelOptions {
  width?: number; // 384 (57mm), 576 (80mm), 800 (10x15)
  showItemsList?: boolean; // Etikette maddeler basılsın mı
  maxItemsToShow?: number; // Kaç maddeye kadar basılsın
}

/**
 * İçerik Arşivi (Koli / Kutu / Depo) için yüksek kaliteli siyah-beyaz termal etiket canvas'ı üretir.
 */
export async function renderArchiveLabel(
  record: BarcodeArchiveRecord,
  options: RenderArchiveLabelOptions = {}
): Promise<string | null> {
  try {
    const width = options.width || 384;
    const showItems = options.showItemsList !== false;
    const scaleFactor = width / 384;
    const pad = Math.round(14 * scaleFactor);

    // 1. QR veya Barkod Kodunu bwipjs ile çiz
    const codeCanvas = document.createElement('canvas');
    if (record.codeType === 'qr') {
      bwipjs.toCanvas(codeCanvas, {
        bcid: 'qrcode',
        text: record.code,
        scale: Math.max(3, Math.round(4 * scaleFactor)),
        paddingwidth: 1,
        paddingheight: 1
      });
    } else {
      const bType = record.barcodeFormat || 'code128';
      const effectiveBcid = (bType === 'ean13' && !/^\d{12,13}$/.test(record.code)) ? 'code128' : bType;
      bwipjs.toCanvas(codeCanvas, {
        bcid: effectiveBcid,
        text: record.code,
        scale: Math.max(2, Math.round(2.6 * scaleFactor)),
        height: Math.round(16 * scaleFactor),
        includetext: true,
        textsize: Math.round(11 * scaleFactor),
        textxalign: 'center',
        paddingwidth: 2
      });
    }

    // 2. Etiket yüksekliğini dinamik olarak hesapla
    let calculatedHeight = pad * 2;
    // Başlık + Kategori/Konum alanı
    calculatedHeight += Math.round(46 * scaleFactor);
    // Barkod / QR alanı
    calculatedHeight += codeCanvas.height + Math.round(20 * scaleFactor);

    // İçerik listesi alanı
    const visibleItems = showItems
      ? record.items.slice(0, options.maxItemsToShow || 12)
      : [];

    if (visibleItems.length > 0) {
      calculatedHeight += Math.round(30 * scaleFactor); // Liste başlığı ve ayırıcı çizgi
      calculatedHeight += visibleItems.length * Math.round(20 * scaleFactor);
      if (record.items.length > visibleItems.length) {
        calculatedHeight += Math.round(18 * scaleFactor); // "+ X diğer öğe"
      }
    }

    if (record.note) {
      calculatedHeight += Math.round(24 * scaleFactor);
    }

    // Footer (Tarih)
    calculatedHeight += Math.round(26 * scaleFactor);

    // Canvas oluştur
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = calculatedHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Arka planı beyaz yap
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, calculatedHeight);

    // Çerçeve (Minimalist net siyah çerçeve)
    ctx.lineWidth = Math.max(2, Math.round(2 * scaleFactor));
    ctx.strokeStyle = '#000000';
    ctx.strokeRect(pad / 2, pad / 2, width - pad, calculatedHeight - pad);

    let currentY = pad + Math.round(12 * scaleFactor);

    // Başlık
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.font = `bold ${Math.round(16 * scaleFactor)}px "Plus Jakarta Sans", sans-serif`;
    
    // Uzun başlığı sığdır
    let titleStr = record.title.toUpperCase();
    if (titleStr.length > 28) titleStr = titleStr.slice(0, 26) + '..';
    ctx.fillText(titleStr, width / 2, currentY);
    currentY += Math.round(18 * scaleFactor);

    // Kategori & Konum Rozeti
    ctx.font = `bold ${Math.round(10 * scaleFactor)}px "Plus Jakarta Sans", monospace`;
    const locText = record.location ? `LOKASYON: ${record.location}` : record.category ? `KATEGORİ: ${record.category}` : 'İÇERİK ARŞİVİ';
    ctx.fillText(`[ ${locText.toUpperCase()} ]`, width / 2, currentY);
    currentY += Math.round(14 * scaleFactor);

    // İnce ayırıcı çizgi
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 2]);
    ctx.beginPath();
    ctx.moveTo(pad, currentY);
    ctx.lineTo(width - pad, currentY);
    ctx.stroke();
    ctx.setLineDash([]);
    currentY += Math.round(10 * scaleFactor);

    // QR veya Barkod Çizimi
    const codeX = Math.round((width - codeCanvas.width) / 2);
    ctx.drawImage(codeCanvas, codeX, currentY);
    currentY += codeCanvas.height + Math.round(8 * scaleFactor);

    // QR ise kod numarasını altına yaz
    if (record.codeType === 'qr') {
      ctx.font = `bold ${Math.round(11 * scaleFactor)}px monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(`KOD: ${record.code}`, width / 2, currentY);
      currentY += Math.round(14 * scaleFactor);
    }

    // İçerik Listesi Bölümü
    if (visibleItems.length > 0) {
      // Liste Başlığı Çizgisi
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(pad, currentY);
      ctx.lineTo(width - pad, currentY);
      ctx.stroke();
      ctx.setLineDash([]);
      currentY += Math.round(14 * scaleFactor);

      ctx.textAlign = 'left';
      ctx.font = `bold ${Math.round(11 * scaleFactor)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(`📦 KOLİ İÇİNDEKİLER (${record.items.length} Kalem):`, pad + 4, currentY);
      currentY += Math.round(16 * scaleFactor);

      // Öğeler
      for (const item of visibleItems) {
        ctx.font = `normal ${Math.round(10.5 * scaleFactor)}px "Plus Jakarta Sans", sans-serif`;
        const checkMark = item.checked ? '☑ ' : '☐ ';
        const qtyStr = item.quantity ? ` (${item.quantity})` : '';
        const itemLine = `${checkMark}${item.name}${qtyStr}`;

        // Metin taşma kontrolü
        let displayLine = itemLine;
        if (displayLine.length > 34) {
          displayLine = displayLine.slice(0, 32) + '..';
        }
        ctx.fillText(displayLine, pad + 6, currentY);
        currentY += Math.round(18 * scaleFactor);
      }

      if (record.items.length > visibleItems.length) {
        ctx.font = `italic ${Math.round(9.5 * scaleFactor)}px "Plus Jakarta Sans", sans-serif`;
        ctx.fillText(`... ve ${record.items.length - visibleItems.length} diğer öğe`, pad + 6, currentY);
        currentY += Math.round(16 * scaleFactor);
      }
    }

    // Not (varsa)
    if (record.note) {
      ctx.textAlign = 'center';
      ctx.font = `italic ${Math.round(9.5 * scaleFactor)}px "Plus Jakarta Sans", sans-serif`;
      let noteStr = `Not: ${record.note}`;
      if (noteStr.length > 40) noteStr = noteStr.slice(0, 38) + '..';
      ctx.fillText(noteStr, width / 2, currentY);
      currentY += Math.round(16 * scaleFactor);
    }

    // Dipnot / Tarih
    const dateStr = new Date(record.createdAt).toLocaleDateString('tr-TR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
    ctx.font = `normal ${Math.round(8.5 * scaleFactor)}px monospace`;
    ctx.textAlign = 'center';
    ctx.fillText(`iPrint Arşiv • ${dateStr} • ${record.id}`, width / 2, currentY);

    return canvas.toDataURL('image/png');
  } catch (err) {
    logger.error('Failed to render archive label', err);
    return null;
  }
}
