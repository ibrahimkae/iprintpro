import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '../components/ui/button';
import { type ResolvedBlock } from '../lib/template-variables';
import {
  ArrowLeft, ShoppingCart, LayoutGrid, HeartPulse, Camera,
  Gamepad2, Palette, Music, ShieldCheck, Luggage
} from 'lucide-react';

import { ApplicationsHubCatalog, type SubAppTabId } from '../components/ApplicationsHubCatalog';
import { TrendyolOrdersStudio, buildShippingBlocks, buildPackingBlocks, packageKey } from '../components/TrendyolOrdersStudio';
import { EmergencyHealthCard } from '../components/EmergencyHealthCard';
import { PolaroidGenerator } from '../components/PolaroidGenerator';
import { MiniGamesPrintView } from '../components/MiniGamesPrintView';
import { PixelCanvasStudio } from '../components/PixelCanvasStudio';
import { ChiptuneMusicStudio } from '../components/ChiptuneMusicStudio';
import { CryptoPaperWalletStudio } from '../components/CryptoPaperWalletStudio';
import { LuggageBagTagStudio } from '../components/LuggageBagTagStudio';

export { buildShippingBlocks, buildPackingBlocks, packageKey };

export interface OrdersViewProps {
  apiBase: string;
  pageWidth: number;
  onPrintShippingLabel: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onPrintPackingSlip: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onDirectPrint?: (dataUrl: string, title: string, widthMm?: number) => Promise<void>;
  onPreviewAndPrint?: (dataUrl: string, title: string, widthMm?: number) => void;
  onBack: () => void;
  initialTab?: SubAppTabId;
}

export function OrdersView(props: OrdersViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubAppTabId>(props.initialTab || 'hub');

  return (
    <motion.div
      key="orders"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-3 pb-16"
    >
      {/* Top Bar with Back and Contextual Controls */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <Button
          variant="ghost"
          onClick={props.onBack}
          className="rounded-lg bg-white dark:bg-slate-900 shadow-xs border border-slate-200 dark:border-slate-800 dark:text-slate-200 text-xs h-8"
        >
          <ArrowLeft size={14} className="mr-1.5" /> Geri
        </Button>
      </div>

      {/* Sub-App Tab Switcher Capsule Bar */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 dark:bg-slate-900/90 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto no-scrollbar shadow-xs">
        <button
          onClick={() => setActiveSubTab('hub')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'hub'
              ? 'bg-slate-900 text-white shadow-xs dark:bg-indigo-600'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
          }`}
        >
          <LayoutGrid size={15} className={activeSubTab === 'hub' ? 'text-white' : 'text-slate-500'} />
          Uygulama Kataloğu (Kutucuklar)
        </button>

        <button
          onClick={() => setActiveSubTab('orders')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'orders'
              ? 'bg-orange-500 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <ShoppingCart size={15} className={activeSubTab === 'orders' ? 'text-white' : 'text-orange-500'} />
          Pazaryeri Siparişleri
        </button>

        <button
          onClick={() => setActiveSubTab('ice')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'ice'
              ? 'bg-red-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <HeartPulse size={15} className={activeSubTab === 'ice' ? 'text-white' : 'text-red-500'} />
          Acil Sağlık Kartı (ICE)
        </button>

        <button
          onClick={() => setActiveSubTab('polaroid')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'polaroid'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Camera size={15} className={activeSubTab === 'polaroid' ? 'text-white' : 'text-amber-500'} />
          Retro Polaroid & Canlı Kamera
        </button>

        <button
          onClick={() => setActiveSubTab('games')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'games'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Gamepad2 size={15} className={activeSubTab === 'games' ? 'text-white' : 'text-purple-500'} />
          Termal Oyunlar & Bulmaca
        </button>

        <button
          onClick={() => setActiveSubTab('pixelcanvas')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'pixelcanvas'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Palette size={15} className={activeSubTab === 'pixelcanvas' ? 'text-white' : 'text-indigo-500'} />
          Modül 2: 1-Bit Piksel Studio & Mikro Font
        </button>

        <button
          onClick={() => setActiveSubTab('chiptune')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'chiptune'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Music size={15} className={activeSubTab === 'chiptune' ? 'text-white' : 'text-emerald-500'} />
          8-Bit Chiptune Ses & QR Müzik
        </button>

        <button
          onClick={() => setActiveSubTab('crypto')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'crypto'
              ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <ShieldCheck size={15} className={activeSubTab === 'crypto' ? 'text-white' : 'text-amber-500'} />
          Kripto Soğuk Cüzdan (Paper Wallet)
        </button>

        <button
          onClick={() => setActiveSubTab('luggage')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubTab === 'luggage'
              ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Luggage size={15} className={activeSubTab === 'luggage' ? 'text-white' : 'text-sky-500'} />
          Bavul & Çanta Kayıp Önleme (Smart Tag)
        </button>
      </div>

      {/* Hub (Katalog Kutucukları) */}
      {activeSubTab === 'hub' && (
        <ApplicationsHubCatalog onSelectApp={(tabId) => setActiveSubTab(tabId)} />
      )}

      {/* Sub-App: Pazaryeri / Trendyol Siparişleri */}
      {activeSubTab === 'orders' && (
        <TrendyolOrdersStudio
          apiBase={props.apiBase}
          pageWidth={props.pageWidth}
          onPrintShippingLabel={props.onPrintShippingLabel}
          onPrintPackingSlip={props.onPrintPackingSlip}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Luggage / Bag Smart Tag */}
      {activeSubTab === 'luggage' && (
        <LuggageBagTagStudio
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Crypto Paper Wallet */}
      {activeSubTab === 'crypto' && (
        <CryptoPaperWalletStudio
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Chiptune 8-Bit */}
      {activeSubTab === 'chiptune' && (
        <ChiptuneMusicStudio
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
            else if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: 1-Bit Pixel Canvas */}
      {activeSubTab === 'pixelcanvas' && (
        <PixelCanvasStudio
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Acil Sağlık Kartı ICE */}
      {activeSubTab === 'ice' && (
        <EmergencyHealthCard
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Polaroid Generator */}
      {activeSubTab === 'polaroid' && (
        <PolaroidGenerator
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}

      {/* Sub-App: Mini Games */}
      {activeSubTab === 'games' && (
        <MiniGamesPrintView
          pageWidth={props.pageWidth}
          onPrintImage={(dataUrl, title, widthMm) => {
            if (props.onPreviewAndPrint) props.onPreviewAndPrint(dataUrl, title, widthMm);
            else if (props.onDirectPrint) props.onDirectPrint(dataUrl, title, widthMm);
          }}
          onDirectPrint={props.onDirectPrint}
          onPreviewAndPrint={props.onPreviewAndPrint}
          onBack={() => setActiveSubTab('hub')}
        />
      )}
    </motion.div>
  );
}
