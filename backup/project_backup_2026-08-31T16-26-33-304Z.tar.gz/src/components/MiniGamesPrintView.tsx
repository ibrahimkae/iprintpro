import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Gamepad2, 
  Sparkles, 
  Printer, 
  Dices, 
  Grid, 
  Calculator, 
  Hash,
  KeyRound,
  Brain,
  Compass,
  FileText,
  Search,
  Eye,
  CheckCircle2,
  HelpCircle,
  RotateCcw
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

// Game Engines
import { generateSafePuzzle, SafePuzzle } from '../lib/games-engine/safe-code-generator';
import { generateMatrixIQPuzzle, MatrixIQPuzzle } from '../lib/games-engine/matrix-iq-generator';
import { generateSudoku, generateMaze, SudokuDifficulty } from '../lib/games-engine/sudoku-maze-generator';
import { JUMBLE_PRESETS, generateWordSearch, MINI_CROSSWORD_PRESETS } from '../lib/games-engine/jumble-crossword-generator';
import { SPOT_DIFFERENCE_PRESETS } from '../lib/games-engine/spot-difference-generator';

export interface MiniGamesPrintViewProps {
  pageWidth: number;
  onPrintImage: (dataUrl: string, title: string, widthMm?: number) => void;
  onDirectPrint?: (dataUrl: string, title: string, widthMm?: number) => void;
  onPreviewAndPrint?: (dataUrl: string, title: string, widthMm?: number) => void;
  onBack?: () => void;
}

export type GameCategory = 
  | 'safe_code'       // Kasa Şifresi & Mantık
  | 'matrix_iq'       // Eksik Parçayı Bul (IQ Matrisi)
  | 'sudoku'          // Prosedürel Sudoku
  | 'maze'            // Prosedürel Labirent
  | 'jumble'          // Kelime Karıştırma (Jumble)
  | 'word_search'     // Kelime Arama
  | 'mini_crossword'  // Mini Çapraz Bulmaca
  | 'spot_diff'       // Görsel Dedektif (Mikro 5 Fark)
  | 'tictactoe'       // XOX 4'lü Grid
  | 'math_quiz';      // Matematik Çarpım Fişi

export const MiniGamesPrintView: React.FC<MiniGamesPrintViewProps> = ({
  pageWidth = 384,
  onPrintImage,
  onDirectPrint,
  onPreviewAndPrint,
  onBack
}) => {
  const [selectedGame, setSelectedGame] = useState<GameCategory>('safe_code');
  const [gameSeed, setGameSeed] = useState<number>(1);
  const [sudokuDifficulty, setSudokuDifficulty] = useState<SudokuDifficulty>('easy');
  const [mazeSize, setMazeSize] = useState<number>(17);
  const [wordSearchSize, setWordSearchSize] = useState<number>(8);
  const [showAnswerInPrint, setShowAnswerInPrint] = useState<boolean>(true);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');

  // -------------------------------------------------------------
  // CANVAS RENDER ENGINE FOR ALL GAME TYPES
  // -------------------------------------------------------------
  const renderGameCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const targetW = pageWidth >= 576 ? 576 : 384;
    const is80mm = targetW >= 576;

    // Helper: Draw Inverted (Upside Down) Answer Key at the bottom
    const drawInvertedAnswer = (startY: number, title: string, answerText: string, extraHeight: number = 70) => {
      const boxY = startY + 12;
      const boxH = extraHeight;

      // Divider Line with fold icon
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(15, boxY);
      ctx.lineTo(targetW - 15, boxY);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('✂️ Buradan Katlayın / Ters Çevirin (Cevap Anahtarı) 🔄', targetW / 2, boxY + 12);

      // Draw Upside Down Text Box
      ctx.save();
      ctx.translate(targetW / 2, boxY + 18 + (boxH - 18) / 2);
      ctx.rotate(Math.PI); // Rotate 180 degrees

      ctx.strokeRect(-((targetW - 40) / 2), -((boxH - 24) / 2), targetW - 40, boxH - 24);
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`🔑 ${title}`, 0, -((boxH - 24) / 2) + 14);

      ctx.font = '10px monospace';
      // Word wrap or line break answer text
      const lines = answerText.split('\n');
      lines.forEach((line, idx) => {
        ctx.fillText(line, 0, -((boxH - 24) / 2) + 28 + (idx * 14));
      });

      ctx.restore();
      return boxY + boxH;
    };

    // 1. KASA ŞİFRESİ (CRACK THE SAFE CODE)
    if (selectedGame === 'safe_code') {
      const puzzle: SafePuzzle = generateSafePuzzle(gameSeed);
      const totalH = showAnswerInPrint ? 520 : 430;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔒 KASA ŞİFRESİ: KODU KIR', targetW / 2, 36);

      // Subtitle
      ctx.fillStyle = '#000000';
      ctx.font = 'italic 10px sans-serif';
      ctx.fillText('3 basamaklı gizli sayıyı mantıksal ipuçlarıyla çöz!', targetW / 2, 65);

      // Draw 5 Clues
      let y = 80;
      puzzle.clues.forEach((clue, idx) => {
        // Clue row box
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(16, y, targetW - 32, 42);

        // Guess digits box on left
        ctx.fillStyle = '#000000';
        ctx.fillRect(18, y + 2, 70, 38);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 18px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(clue.guess.split('').join(' '), 53, y + 27);

        // Clue text description on right
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'left';

        // Badge indicator
        let badge = '⚠️';
        if (clue.correctCount === 0) badge = '❌';
        else if (clue.wellPlacedCount > 0) badge = '🎯';
        else badge = '🔄';

        ctx.fillText(`${badge} ${clue.description}`, 96, y + 25);
        y += 48;
      });

      // Player Scratchpad / Guess Area
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('✍️ Tahmininiz (Kasa Şifresi):', 20, y + 16);

      const boxSize = 32;
      const startBoxX = targetW - 20 - (boxSize * 3 + 12);
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.strokeRect(startBoxX + i * (boxSize + 6), y + 2, boxSize, boxSize);
      }

      y += 46;

      if (showAnswerInPrint) {
        drawInvertedAnswer(y, 'KASA ŞİFRE ÇÖZÜMÜ', `Gizli Şifre: [ ${puzzle.secret} ]\n${puzzle.solutionExplanation}`, 80);
      }
    }

    // 2. EKSİK PARÇAYI BUL (IQ MATRİSİ)
    else if (selectedGame === 'matrix_iq') {
      const puzzle: MatrixIQPuzzle = generateMatrixIQPuzzle(gameSeed);
      const totalH = showAnswerInPrint ? 590 : 500;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🧠 IQ MATRİSİ: EKSİK PARÇA', targetW / 2, 36);

      // Subtitle
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(puzzle.title, targetW / 2, 65);
      ctx.font = '10px sans-serif';
      ctx.fillText('9. kutudaki soru işareti yerine hangi seçenek gelmelidir?', targetW / 2, 80);

      // 3x3 Matrix Grid
      const matrixSize = is80mm ? 220 : 190;
      const cellSize = Math.floor(matrixSize / 3);
      const mx = Math.floor((targetW - cellSize * 3) / 2);
      const my = 95;

      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(mx, my, cellSize * 3, cellSize * 3);

      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
          const cx = mx + c * cellSize;
          const cy = my + r * cellSize;
          const idx = r * 3 + c;

          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 1;
          ctx.strokeRect(cx, cy, cellSize, cellSize);

          if (idx < 8) {
            puzzle.cells[idx](ctx, cx, cy, cellSize);
          } else {
            // 9th cell: '?'
            ctx.fillStyle = '#000000';
            ctx.fillRect(cx + 4, cy + 4, cellSize - 8, cellSize - 8);
            ctx.fillStyle = '#FFFFFF';
            ctx.font = 'bold 24px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('?', cx + cellSize / 2, cy + cellSize / 2);
            ctx.textBaseline = 'alphabetic';
          }
        }
      }

      // Options: A, B, C, D
      const optY = my + cellSize * 3 + 20;
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Seçenekler:', targetW / 2, optY);

      const optBoxW = Math.floor((targetW - 50) / 4);
      const optBoxH = is80mm ? 65 : 55;
      const optStartX = Math.floor((targetW - (optBoxW * 4 + 18)) / 2);

      puzzle.options.forEach((opt, idx) => {
        const ox = optStartX + idx * (optBoxW + 6);
        const oy = optY + 10;

        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(ox, oy, optBoxW, optBoxH);

        // Option letter label
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`[ ${opt.id} ]`, ox + optBoxW / 2, oy + 12);

        // Draw shape in option
        opt.draw(ctx, ox + (optBoxW - (optBoxH - 18)) / 2, oy + 14, optBoxH - 18);
      });

      const nextY = optY + optBoxH + 20;
      if (showAnswerInPrint) {
        drawInvertedAnswer(nextY, 'IQ MATRİSİ DOĞRU CEVAP', `Doğru Şık: [ ${puzzle.correctOption} ]\n${puzzle.explanation}`, 76);
      }
    }

    // 3. PROSEDÜREL 9x9 SUDOKU
    else if (selectedGame === 'sudoku') {
      const puzzle = generateSudoku(gameSeed, sudokuDifficulty);
      const totalH = showAnswerInPrint ? 580 : 490;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`🧩 TERMAL SUDOKU (${sudokuDifficulty.toUpperCase()})`, targetW / 2, 36);

      // Info Bar
      ctx.fillStyle = '#000000';
      ctx.font = '10px sans-serif';
      ctx.fillText(`Süre Tutun: [ __ : __ ]  •  Tohum #${gameSeed}`, targetW / 2, 65);

      const gridMargin = is80mm ? 30 : 16;
      const gridW = targetW - (gridMargin * 2);
      const cellSize = Math.floor(gridW / 9);
      const actualGridW = cellSize * 9;
      const startX = Math.floor((targetW - actualGridW) / 2);
      const startY = 75;

      // Draw Grid Lines
      for (let i = 0; i <= 9; i++) {
        ctx.lineWidth = (i % 3 === 0) ? 3 : 1;
        ctx.strokeStyle = '#000000';
        ctx.beginPath();
        ctx.moveTo(startX + i * cellSize, startY);
        ctx.lineTo(startX + i * cellSize, startY + actualGridW);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(startX, startY + i * cellSize);
        ctx.lineTo(startX + actualGridW, startY + i * cellSize);
        ctx.stroke();
      }

      // Numbers
      ctx.fillStyle = '#000000';
      ctx.font = `bold ${Math.floor(cellSize * 0.65)}px monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      for (let r = 0; r < 9; r++) {
        for (let c = 0; c < 9; c++) {
          const val = puzzle.grid[r][c];
          if (val > 0) {
            const cx = startX + c * cellSize + cellSize / 2;
            const cy = startY + r * cellSize + cellSize / 2;
            ctx.fillText(String(val), cx, cy + 1);
          }
        }
      }
      ctx.textBaseline = 'alphabetic';

      const nextY = startY + actualGridW + 10;
      if (showAnswerInPrint) {
        // Compact single-line row solution string
        const solRows = puzzle.solution.map(r => r.join('')).join(' | ');
        drawInvertedAnswer(nextY, 'SUDOKU ÇÖZÜMÜ (Satır Satır)', `${solRows.slice(0, 44)}\n${solRows.slice(44)}`, 74);
      }
    }

    // 4. PROSEDÜREL LABİRENT (MAZE)
    else if (selectedGame === 'maze') {
      const maze = generateMaze(mazeSize, mazeSize, gameSeed);
      const totalH = showAnswerInPrint ? 560 : 470;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🌀 PROSEDÜREL TERMAL LABİRENT', targetW / 2, 36);

      ctx.fillStyle = '#000000';
      ctx.font = '10px sans-serif';
      ctx.fillText('🚩 GİRİŞ (Sol Üst)  ----->  🏆 ÇIKIŞ (Sağ Alt)', targetW / 2, 65);

      const margin = is80mm ? 36 : 20;
      const mazeDim = targetW - (margin * 2);
      const cellSize = Math.floor(mazeDim / mazeSize);
      const actualMazeW = cellSize * mazeSize;
      const startX = Math.floor((targetW - actualMazeW) / 2);
      const startY = 75;

      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2.5;

      for (let r = 0; r < maze.rows; r++) {
        for (let c = 0; c < maze.cols; c++) {
          const cell = maze.grid[r][c];
          const x = startX + c * cellSize;
          const y = startY + r * cellSize;

          if (cell.top) {
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + cellSize, y); ctx.stroke();
          }
          if (cell.right) {
            ctx.beginPath(); ctx.moveTo(x + cellSize, y); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke();
          }
          if (cell.bottom) {
            ctx.beginPath(); ctx.moveTo(x, y + cellSize); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke();
          }
          if (cell.left) {
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cellSize); ctx.stroke();
          }
        }
      }

      // Draw start and end flags
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText('🚩', startX - 12, startY + 10);
      ctx.fillText('🏆', startX + actualMazeW + 4, startY + actualMazeW);

      const nextY = startY + actualMazeW + 12;
      if (showAnswerInPrint) {
        drawInvertedAnswer(nextY, 'LABİRENT YOL İPUCU', `Toplam Çözüm Adımı: ${maze.solutionPath.length} hücre.\nBaşlangıç yönü: Doğu/Güney rotasını takip ediniz.`, 65);
      }
    }

    // 5. KELİME KARIŞTIRMA (JUMBLE / ANAGRAM)
    else if (selectedGame === 'jumble') {
      const puzzleIndex = Math.abs(gameSeed) % JUMBLE_PRESETS.length;
      const puzzle = JUMBLE_PRESETS[puzzleIndex];
      const totalH = showAnswerInPrint ? 560 : 470;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔤 KELİME KARIŞTIRMA (JUMBLE)', targetW / 2, 36);

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`Tema: ${puzzle.theme}`, targetW / 2, 65);
      ctx.font = '10px sans-serif';
      ctx.fillText('Harfleri düzeltip kutucuklara yazın, daireli harflerden şifreyi bulun!', targetW / 2, 80);

      let y = 98;
      puzzle.items.forEach((item) => {
        // Scrambled badge
        ctx.fillStyle = '#000000';
        ctx.fillRect(16, y, 90, 26);
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 13px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(item.scrambled, 61, y + 18);

        // Hint text
        ctx.fillStyle = '#000000';
        ctx.font = 'italic 10px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`(${item.hint})`, 112, y + 17);

        // Empty letter boxes on right
        const boxSize = 22;
        const startX = targetW - 18 - (item.original.length * (boxSize + 4));

        for (let i = 0; i < item.original.length; i++) {
          const bx = startX + i * (boxSize + 4);
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(bx, y + 2, boxSize, boxSize);

          if (item.circledIndices.includes(i)) {
            // Draw circle around/inside this box for mystery clue
            ctx.beginPath();
            ctx.arc(bx + boxSize / 2, y + 2 + boxSize / 2, boxSize / 2 - 2, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

        y += 36;
      });

      // Bonus Riddle
      y += 8;
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(16, y, targetW - 32, 65);

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('✨ GÜNÜN GİZEMLİ ŞİFRE SORUSU:', targetW / 2, y + 18);

      ctx.font = '10px sans-serif';
      ctx.fillText(puzzle.mysteryRiddle, targetW / 2, y + 34);

      // Mystery Boxes
      const mLen = puzzle.mysteryAnswer.replace(/\s+/g, '').length;
      const mBoxW = Math.min(22, Math.floor((targetW - 50) / mLen));
      const mStartX = Math.floor((targetW - (mLen * (mBoxW + 4))) / 2);

      for (let i = 0; i < mLen; i++) {
        ctx.strokeRect(mStartX + i * (mBoxW + 4), y + 42, mBoxW, 16);
      }

      y += 76;
      if (showAnswerInPrint) {
        const solvedWords = puzzle.items.map(it => it.original).join(', ');
        drawInvertedAnswer(y, 'JUMBLE ÇÖZÜMÜ', `Kelimeler: ${solvedWords}\nGizemli Şifre: [ ${puzzle.mysteryAnswer} ]`, 70);
      }
    }

    // 6. KELİME ARAMA (WORD SEARCH)
    else if (selectedGame === 'word_search') {
      const ws = generateWordSearch(gameSeed, wordSearchSize);
      const totalH = showAnswerInPrint ? 560 : 470;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🔍 KELİME AVCI IZGARASI (WORD SEARCH)', targetW / 2, 36);

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`Tema: ${ws.theme}`, targetW / 2, 65);

      // Draw Letter Grid
      const margin = is80mm ? 36 : 22;
      const gridDim = targetW - (margin * 2);
      const cellSize = Math.floor(gridDim / ws.size);
      const actualGridW = cellSize * ws.size;
      const startX = Math.floor((targetW - actualGridW) / 2);
      const startY = 76;

      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(startX, startY, actualGridW, actualGridW);

      ctx.fillStyle = '#000000';
      ctx.font = `bold ${Math.floor(cellSize * 0.55)}px monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      for (let r = 0; r < ws.size; r++) {
        for (let c = 0; c < ws.size; c++) {
          const cx = startX + c * cellSize + cellSize / 2;
          const cy = startY + r * cellSize + cellSize / 2;

          ctx.strokeStyle = '#e2e8f0';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(startX + c * cellSize, startY + r * cellSize, cellSize, cellSize);

          ctx.fillText(ws.grid[r][c], cx, cy);
        }
      }
      ctx.textBaseline = 'alphabetic';

      // Word Bank Checklist
      let wordY = startY + actualGridW + 16;
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('Bulunacak Kelimeler:', 20, wordY);

      wordY += 14;
      const cols = is80mm ? 3 : 2;
      const colW = Math.floor((targetW - 40) / cols);

      ws.words.forEach((w, idx) => {
        const c = idx % cols;
        const r = Math.floor(idx / cols);
        const wx = 20 + c * colW;
        const wy = wordY + r * 16;

        ctx.font = '10px monospace';
        ctx.fillText(`[ ] ${w}`, wx, wy);
      });

      const nextY = wordY + Math.ceil(ws.words.length / cols) * 16 + 10;
      if (showAnswerInPrint) {
        drawInvertedAnswer(nextY, 'KELİME LİSTESİ', `Gizlenmiş Kelimeler:\n${ws.words.join(' • ')}`, 65);
      }
    }

    // 7. MİNİ ÇAPRAZ BULMACA (MINI CROSSWORD)
    else if (selectedGame === 'mini_crossword') {
      const pIdx = Math.abs(gameSeed) % MINI_CROSSWORD_PRESETS.length;
      const cross = MINI_CROSSWORD_PRESETS[pIdx];
      const totalH = showAnswerInPrint ? 580 : 490;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('✏️ MİNİ ÇAPRAZ BULMACA', targetW / 2, 36);

      // Grid on Left / Top
      const cellSize = is80mm ? 32 : 26;
      const actualGridW = cellSize * cross.size;
      const startX = Math.floor((targetW - actualGridW) / 2);
      const startY = 60;

      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(startX, startY, actualGridW, actualGridW);

      for (let r = 0; r < cross.size; r++) {
        for (let c = 0; c < cross.size; c++) {
          const cell = cross.grid[r][c];
          const cx = startX + c * cellSize;
          const cy = startY + r * cellSize;

          if (cell.isBlock) {
            ctx.fillStyle = '#000000';
            ctx.fillRect(cx, cy, cellSize, cellSize);
          } else {
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 1;
            ctx.strokeRect(cx, cy, cellSize, cellSize);

            if (cell.num) {
              ctx.fillStyle = '#000000';
              ctx.font = 'bold 8px sans-serif';
              ctx.textAlign = 'left';
              ctx.fillText(String(cell.num), cx + 2, cy + 9);
            }
          }
        }
      }

      // Clues across & down
      let clueY = startY + actualGridW + 16;

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('➡️ SOLDAN SAĞA:', 18, clueY);
      clueY += 13;

      ctx.font = '9px sans-serif';
      cross.cluesAcross.forEach(cl => {
        ctx.fillText(`${cl.num}. ${cl.clue} (${cl.answer.length})`, 22, clueY);
        clueY += 12;
      });

      clueY += 4;
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText('⬇️ YUKARIDAN AŞAĞIYA:', 18, clueY);
      clueY += 13;

      ctx.font = '9px sans-serif';
      cross.cluesDown.forEach(cl => {
        ctx.fillText(`${cl.num}. ${cl.clue} (${cl.answer.length})`, 22, clueY);
        clueY += 12;
      });

      if (showAnswerInPrint) {
        const acrossAns = cross.cluesAcross.map(c => `${c.num}:${c.answer}`).join(' ');
        const downAns = cross.cluesDown.map(c => `${c.num}:${c.answer}`).join(' ');
        drawInvertedAnswer(clueY, 'ÇAPRAZ BULMACA CEVAPLARI', `Yatay: ${acrossAns}\nDüşey: ${downAns}`, 65);
      }
    }

    // 8. GÖRSEL DEDEKTİF (MİKRO 5 FARK)
    else if (selectedGame === 'spot_diff') {
      const pIdx = Math.abs(gameSeed) % SPOT_DIFFERENCE_PRESETS.length;
      const spot = SPOT_DIFFERENCE_PRESETS[pIdx];
      const totalH = showAnswerInPrint ? 620 : 530;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      // Header Banner
      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🕵️ GÖRSEL DEDEKTİF: 5 FARK', targetW / 2, 36);

      ctx.fillStyle = '#000000';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(spot.themeTitle, targetW / 2, 65);
      ctx.font = '10px sans-serif';
      ctx.fillText(spot.themeDesc, targetW / 2, 78);

      const sceneW = targetW - 32;
      const sceneH = is80mm ? 155 : 135;
      const sceneX = 16;

      // Image 1: Original
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('📷 1. GÖRSEL (ORİJİNAL)', sceneX, 94);
      spot.drawScene(ctx, sceneX, 98, sceneW, sceneH, false);

      // Image 2: Modified (5 Differences)
      const scene2Y = 98 + sceneH + 16;
      ctx.fillText('🔍 2. GÖRSEL (5 MİKRO FARK GİZLİ)', sceneX, scene2Y - 4);
      spot.drawScene(ctx, sceneX, scene2Y, sceneW, sceneH, true);

      // Trackers for user
      const trackY = scene2Y + sceneH + 14;
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Bulunan Farklar:   ( 1 )      ( 2 )      ( 3 )      ( 4 )      ( 5 )', targetW / 2, trackY);

      if (showAnswerInPrint) {
        const diffList = spot.differences.map(d => `${d.id}) ${d.description}`).join('\n');
        drawInvertedAnswer(trackY + 8, '5 FARK CEVAPLARI', diffList, 95);
      }
    }

    // 9. KLASİK XOX
    else if (selectedGame === 'tictactoe') {
      const totalH = 460;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('❌ XOX (TIC-TAC-TOE) KARTI ⭕', targetW / 2, 36);

      const boxW = Math.floor((targetW - 40) / 2);
      const boxH = 160;

      const drawSingleGrid = (bx: number, by: number, label: string) => {
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.strokeRect(bx, by, boxW, boxH);

        ctx.fillStyle = '#000000';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, bx + boxW / 2, by + 16);

        const gSize = 100;
        const gx = bx + Math.floor((boxW - gSize) / 2);
        const gy = by + 30;
        const step = Math.floor(gSize / 3);

        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(gx + step, gy); ctx.lineTo(gx + step, gy + gSize);
        ctx.moveTo(gx + step * 2, gy); ctx.lineTo(gx + step * 2, gy + gSize);
        ctx.moveTo(gx, gy + step); ctx.lineTo(gx + gSize, gy + step);
        ctx.moveTo(gx, gy + step * 2); ctx.lineTo(gx + gSize, gy + step * 2);
        ctx.stroke();
      };

      drawSingleGrid(15, 60, 'Oyun #1');
      drawSingleGrid(targetW / 2 + 5, 60, 'Oyun #2');
      drawSingleGrid(15, 235, 'Oyun #3');
      drawSingleGrid(targetW / 2 + 5, 235, 'Oyun #4');

      ctx.fillStyle = '#000000';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('iPrint Pro • Eğlenceli Rulo Baskısı', targetW / 2, totalH - 14);
    }

    // 10. MATEMATİK ÇARPIM FİŞİ
    else if (selectedGame === 'math_quiz') {
      const totalH = 430;
      canvas.width = targetW;
      canvas.height = totalH;

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, targetW, totalH);

      ctx.fillStyle = '#000000';
      ctx.fillRect(12, 12, targetW - 24, 38);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('📐 ÇARPINIM & MATEMATİK FİŞİ', targetW / 2, 36);

      const nums = [2, 3, 4, 5, 6, 7, 8, 9];
      const baseNum = nums[gameSeed % nums.length];

      let y = 70;
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`🎯 ${baseNum}'ler Çarpım Alıştırması`, 20, y);
      y += 20;

      for (let i = 1; i <= 10; i++) {
        ctx.font = 'bold 13px monospace';
        ctx.fillText(`${i}  x  ${baseNum}  =  [      ]`, 25, y);
        y += 24;
      }

      ctx.font = 'italic 11px sans-serif';
      ctx.fillText('Not: Cevapları kutucuklara kurşun kalemle yazınız.', 20, y + 10);

      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('iPrint Pro Mini Öğrenme Kartı', targetW / 2, totalH - 14);
    }

    setPreviewUrl(canvas.toDataURL());
  };

  useEffect(() => {
    renderGameCanvas();
  }, [
    selectedGame,
    gameSeed,
    sudokuDifficulty,
    mazeSize,
    wordSearchSize,
    showAnswerInPrint,
    pageWidth
  ]);

  const handleExecutePrint = (direct: boolean = true) => {
    if (!previewUrl) return;
    setIsGenerating(true);
    try {
      const widthMm = pageWidth >= 576 ? 80 : 57;
      const title = `Zeka-Oyun-${selectedGame.toUpperCase()}`;

      if (direct && onDirectPrint) {
        onDirectPrint(previewUrl, title, widthMm);
      } else if (!direct && onPreviewAndPrint) {
        onPreviewAndPrint(previewUrl, title, widthMm);
      } else {
        onPrintImage(previewUrl, title, widthMm);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 p-4 sm:p-5 rounded-2xl text-white shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 shadow-inner">
            <Gamepad2 size={26} />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black tracking-tight leading-tight">
              Termal Zeka Oyunları & Bulmaca Stüdyosu
            </h2>
            <p className="text-xs text-purple-100 font-medium">
              Kasa Şifresi, IQ Matrisi, Sudoku, Labirent, Jumble, Kelime Avı ve Mikro Fark Basımları
            </p>
          </div>
        </div>

        {onBack && (
          <Button
            variant="ghost"
            onClick={onBack}
            className="text-white hover:bg-white/20 rounded-xl h-9 text-xs font-bold"
          >
            Geri Dön
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
        {/* Controls & Mode Selection */}
        <div className="md:col-span-7 space-y-4">
          <Card className="p-4 space-y-4 rounded-2xl border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Dices size={18} className="text-purple-500" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Oyun & Bulmaca Modülü
                </h3>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setGameSeed(s => s + 1)}
                className="h-8 text-xs font-black rounded-xl border-purple-300 dark:border-purple-800 text-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/50 flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw size={13} />
                🎲 Yeni Rastgele Üret
              </Button>
            </div>

            {/* Game Category Selector Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <button
                onClick={() => setSelectedGame('safe_code')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'safe_code'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <KeyRound size={18} className="mb-1 text-purple-600 dark:text-purple-400" />
                <span className="text-xs font-bold block">Kasa Şifresi</span>
                <span className="text-[10px] text-slate-400 font-normal">Sayısal & İpuçları</span>
              </button>

              <button
                onClick={() => setSelectedGame('matrix_iq')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'matrix_iq'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Brain size={18} className="mb-1 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-bold block">IQ Matrisi</span>
                <span className="text-[10px] text-slate-400 font-normal">Eksik Parçayı Bul</span>
              </button>

              <button
                onClick={() => setSelectedGame('sudoku')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'sudoku'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Grid size={18} className="mb-1 text-blue-600 dark:text-blue-400" />
                <span className="text-xs font-bold block">9x9 Sudoku</span>
                <span className="text-[10px] text-slate-400 font-normal">Benzersiz Çözümlü</span>
              </button>

              <button
                onClick={() => setSelectedGame('maze')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'maze'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Compass size={18} className="mb-1 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-bold block">Labirent (Maze)</span>
                <span className="text-[10px] text-slate-400 font-normal">Prosedürel Yollar</span>
              </button>

              <button
                onClick={() => setSelectedGame('jumble')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'jumble'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <FileText size={18} className="mb-1 text-amber-600 dark:text-amber-400" />
                <span className="text-xs font-bold block">Jumble (Anagram)</span>
                <span className="text-[10px] text-slate-400 font-normal">Kelime & Gizemli Şifre</span>
              </button>

              <button
                onClick={() => setSelectedGame('word_search')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'word_search'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Search size={18} className="mb-1 text-teal-600 dark:text-teal-400" />
                <span className="text-xs font-bold block">Kelime Avı</span>
                <span className="text-[10px] text-slate-400 font-normal">Word Search Izgarası</span>
              </button>

              <button
                onClick={() => setSelectedGame('mini_crossword')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'mini_crossword'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Grid size={18} className="mb-1 text-rose-600 dark:text-rose-400" />
                <span className="text-xs font-bold block">Mini Çapraz</span>
                <span className="text-[10px] text-slate-400 font-normal">5x5 Çengel Bulmaca</span>
              </button>

              <button
                onClick={() => setSelectedGame('spot_diff')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'spot_diff'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Eye size={18} className="mb-1 text-orange-600 dark:text-orange-400" />
                <span className="text-xs font-bold block">Görsel Dedektif</span>
                <span className="text-[10px] text-slate-400 font-normal">Mikro 5 Fark</span>
              </button>

              <button
                onClick={() => setSelectedGame('tictactoe')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'tictactoe'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Hash size={18} className="mb-1 text-violet-600 dark:text-violet-400" />
                <span className="text-xs font-bold block">4'lü XOX</span>
                <span className="text-[10px] text-slate-400 font-normal">İkili Oyun Kartı</span>
              </button>

              <button
                onClick={() => setSelectedGame('math_quiz')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedGame === 'math_quiz'
                    ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-900 dark:text-purple-200 font-bold shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-purple-300'
                }`}
              >
                <Calculator size={18} className="mb-1 text-pink-600 dark:text-pink-400" />
                <span className="text-xs font-bold block">Çarpım Fişi</span>
                <span className="text-[10px] text-slate-400 font-normal">Matematik Kartı</span>
              </button>
            </div>

            {/* Contextual Options for Selected Game */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
              {selectedGame === 'sudoku' && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    Sudoku Zorluk Derecesi:
                  </span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['easy', 'medium', 'hard', 'expert'] as SudokuDifficulty[]).map((diff) => (
                      <button
                        key={diff}
                        onClick={() => setSudokuDifficulty(diff)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold border capitalize transition-all ${
                          sudokuDifficulty === diff
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {diff === 'easy' ? 'Kolay' : diff === 'medium' ? 'Orta' : diff === 'hard' ? 'Zor' : 'Uzman'}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {selectedGame === 'maze' && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    Labirent Karmaşıklığı (Izgara Boyutu):
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {[13, 17, 21].map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setMazeSize(sz)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                          mazeSize === sz
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {sz === 13 ? 'Kısa (13x13)' : sz === 17 ? 'Standart (17x17)' : 'Geniş (21x21)'}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {selectedGame === 'word_search' && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                    Kelime Avı Izgara Ölçüsü:
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {[8, 10].map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setWordSearchSize(sz)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                          wordSearchSize === sz
                            ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {sz}x{sz} Izgara
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Answer Key Toggle */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <HelpCircle size={15} className="text-slate-400" />
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Ters Çözüm Anahtarı Basılsın mı?
                  </span>
                </div>
                <button
                  onClick={() => setShowAnswerInPrint(!showAnswerInPrint)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    showAnswerInPrint
                      ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-300 dark:border-purple-800'
                      : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  {showAnswerInPrint ? '✓ Ters Çözüm Açık' : '✗ Kapalı'}
                </button>
              </div>
            </div>
          </Card>
        </div>

        {/* Preview & Print */}
        <div className="md:col-span-5 space-y-4 sticky top-4">
          <Card className="p-4 space-y-3 rounded-2xl border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Sparkles size={16} className="text-purple-500" />
                <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Termal Kağıt Çıktı Önizleme
                </h3>
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                {pageWidth >= 576 ? '80mm (576px)' : '58mm (384px)'}
              </span>
            </div>

            <canvas ref={canvasRef} className="hidden" />

            <div className="border border-slate-300 dark:border-slate-700 rounded-xl overflow-hidden bg-white shadow-inner p-2 flex justify-center items-center min-h-[340px] max-h-[460px] overflow-y-auto">
              {previewUrl ? (
                <img
                  src={previewUrl}
                  alt="Oyun Kartı Önizleme"
                  className="w-full h-auto object-contain rounded-md shadow-xs"
                />
              ) : (
                <div className="text-xs text-slate-400 font-medium animate-pulse">
                  Oyun grafiği oluşturuluyor...
                </div>
              )}
            </div>

            {/* Print Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <Button
                variant="outline"
                onClick={() => handleExecutePrint(false)}
                disabled={!previewUrl || isGenerating}
                className="w-full h-11 rounded-xl text-xs font-bold border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Sparkles size={15} className="text-purple-500" />
                Önizleme & Ayarlar
              </Button>

              <Button
                onClick={() => handleExecutePrint(true)}
                disabled={!previewUrl || isGenerating}
                className="w-full h-11 rounded-xl text-xs font-black bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:to-indigo-700 text-white flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
              >
                <Printer size={16} />
                {isGenerating ? 'Hazırlanıyor...' : '⚡ Hızlı Yazdır'}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
