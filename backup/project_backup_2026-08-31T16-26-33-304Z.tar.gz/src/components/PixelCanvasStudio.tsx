import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Pencil, Eraser, PaintBucket, Minus, Square, Circle, Type,
  RotateCcw, RotateCw, Trash2, Upload, Printer, Download, Grid, Sparkles,
  ArrowLeft, Check, ZoomIn, ZoomOut, Maximize2,
  FlipHorizontal, FlipVertical, RefreshCw, Sliders,
  ArrowUp, ArrowDown, ArrowLeft as ArrowLeftIcon, ArrowRight,
  Layers, Palette, Eye, HelpCircle
} from 'lucide-react';
import { Card } from './ui/card';
import { renderBitmapText } from '../lib/bitmap-fonts';
import { processImage, DitheringType } from '../lib/image-processing';

export interface PixelCanvasStudioProps {
  pageWidth?: number; // 384 or 576
  onPrintImage: (dataUrl: string, title: string, widthMm?: number) => void;
  onBack?: () => void;
}

export type ToolType =
  | 'pencil'
  | 'eraser'
  | 'dither'
  | 'fill'
  | 'line'
  | 'rect'
  | 'rectOutline'
  | 'circle'
  | 'circleOutline'
  | 'text';

export type BrushSize = 1 | 2 | 3 | 4 | 6 | 8 | 12;
export type BrushShape = 'square' | 'round';

export interface CanvasPreset {
  id: string;
  name: string;
  category: 'Önerilen Kare' | 'Klasik Retro' | 'Kart & Etiket' | 'Geniş Rulo';
  width: number;
  height: number;
  icon: string;
  desc: string;
  recommendedZoom: number;
}

export const CANVAS_PRESETS: CanvasPreset[] = [
  { id: 'sq-100', name: '100x100 Kare', category: 'Önerilen Kare', width: 100, height: 100, icon: '🎯', desc: 'Standart hassas piksel çizim tuvali', recommendedZoom: 450 },
  { id: 'sq-64', name: '64x64 Rozet / Avatar', category: 'Önerilen Kare', width: 64, height: 64, icon: '👾', desc: 'Sprite ve rozet boyutları', recommendedZoom: 600 },
  { id: 'sq-32', name: '32x32 Mini Sprite', category: 'Klasik Retro', width: 32, height: 32, icon: '🎮', desc: 'Retro 8-bit oyun ikonu', recommendedZoom: 1000 },
  { id: 'sq-16', name: '16x16 Mikro İkon', category: 'Klasik Retro', width: 16, height: 16, icon: '🕹️', desc: 'En küçük mikro piksel boyutu', recommendedZoom: 1200 },
  { id: 'sq-48', name: '48x48 Piksel Damga', category: 'Klasik Retro', width: 48, height: 48, icon: '🏷️', desc: 'Damga ve küçük logolar', recommendedZoom: 700 },
  { id: 'sq-80', name: '80x80 Orta Kare', category: 'Önerilen Kare', width: 80, height: 80, icon: '🔲', desc: 'Dengeli kare çizim alanı', recommendedZoom: 500 },
  { id: 'sq-128', name: '128x128 Büyük Kare', category: 'Önerilen Kare', width: 128, height: 128, icon: '🖼️', desc: 'Detaylı piksel sanatları', recommendedZoom: 350 },
  { id: 'rect-150-100', name: '150x100 Yatay Kart', category: 'Kart & Etiket', width: 150, height: 100, icon: '📜', desc: 'Fiyat kartı ve etiket', recommendedZoom: 350 },
  { id: 'rect-100-150', name: '100x150 Dikey Kart', category: 'Kart & Etiket', width: 100, height: 150, icon: '📄', desc: 'Dikey mini fiş / not', recommendedZoom: 350 },
  { id: 'full-384', name: '384x384 Tam Termal Rulo', category: 'Geniş Rulo', width: 384, height: 384, icon: '🖨️', desc: '58mm tam sayfa genişliği', recommendedZoom: 125 },
  { id: 'full-576', name: '576x576 80mm Tam Rulo', category: 'Geniş Rulo', width: 576, height: 576, icon: '📐', desc: '80mm geniş yazıcılar için', recommendedZoom: 100 },
];

export function PixelCanvasStudio({ pageWidth = 384, onPrintImage, onBack }: PixelCanvasStudioProps) {
  // Canvas Resolution State (Default to 100x100 as requested)
  const [canvasWidth, setCanvasWidth] = useState<number>(100);
  const [canvasHeight, setCanvasHeight] = useState<number>(100);

  // Custom Dimension Form
  const [customW, setCustomW] = useState<string>('100');
  const [customH, setCustomH] = useState<string>('100');
  const [showDimensionModal, setShowDimensionModal] = useState<boolean>(false);
  const [preserveContentOnResize, setPreserveContentOnResize] = useState<boolean>(true);

  // Tools & Brushes
  const [activeTool, setActiveTool] = useState<ToolType>('pencil');
  const [brushSize, setBrushSize] = useState<BrushSize>(1);
  const [brushShape, setBrushShape] = useState<BrushShape>('square');
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showMajorGuides, setShowMajorGuides] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(450); // %450 default for 100x100

  // Micro Typography
  const [stampText, setStampText] = useState<string>('TERMİK');
  const [fontType, setFontType] = useState<'5x7' | '7x9'>('5x7');
  const [textScale, setTextScale] = useState<number>(1);
  const [textInverted, setTextInverted] = useState<boolean>(false);

  // Hover Coordinates & Active Cursor
  const [hoverCoord, setHoverCoord] = useState<{ x: number; y: number } | null>(null);

  // Print Setup Modal
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [printLayoutMode, setPrintLayoutMode] = useState<'auto-scale' | 'bordered' | 'native-center' | 'full-width'>('auto-scale');
  const [printTitle, setPrintTitle] = useState<string>('');

  // Image Import Modal
  const [showImportModal, setShowImportModal] = useState<boolean>(false);
  const [importedImageSrc, setImportedImageSrc] = useState<string | null>(null);
  const [importDither, setImportDither] = useState<DitheringType>('atkinson');
  const [importInvert, setImportInvert] = useState<boolean>(false);
  const [importFitMode, setImportFitMode] = useState<'contain' | 'cover'>('contain');

  // Canvas Refs & Buffers
  const displayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const bufferCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageContainerRef = useRef<HTMLDivElement | null>(null);
  const isDrawingRef = useRef<boolean>(false);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);

  // Undo / Redo Stacks (ImageData buffers)
  const historyRef = useRef<ImageData[]>([]);
  const historyIndexRef = useRef<number>(-1);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Stats
  const [blackPixelCount, setBlackPixelCount] = useState<number>(0);

  // Initialize or get contexts
  const getContexts = useCallback(() => {
    if (!displayCanvasRef.current) return null;
    const displayCanvas = displayCanvasRef.current;
    const displayCtx = displayCanvas.getContext('2d');

    if (!bufferCanvasRef.current) {
      bufferCanvasRef.current = document.createElement('canvas');
    }
    const bufferCanvas = bufferCanvasRef.current;
    if (bufferCanvas.width !== canvasWidth || bufferCanvas.height !== canvasHeight) {
      bufferCanvas.width = canvasWidth;
      bufferCanvas.height = canvasHeight;
      const bufCtx = bufferCanvas.getContext('2d');
      if (bufCtx) {
        bufCtx.fillStyle = '#FFFFFF';
        bufCtx.fillRect(0, 0, canvasWidth, canvasHeight);
      }
    }
    const bufCtx = bufferCanvas.getContext('2d');

    return { displayCanvas, displayCtx, bufferCanvas, bufCtx };
  }, [canvasWidth, canvasHeight]);

  // Recount black pixels
  const updateStats = useCallback(() => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const imgData = ctxs.bufCtx.getImageData(0, 0, canvasWidth, canvasHeight);
    let count = 0;
    for (let i = 0; i < imgData.data.length; i += 4) {
      if (imgData.data[i] < 128) count++;
    }
    setBlackPixelCount(count);
  }, [getContexts, canvasWidth, canvasHeight]);

  // Save current canvas state into history
  const saveHistory = useCallback(() => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const imgData = ctxs.bufCtx.getImageData(0, 0, canvasWidth, canvasHeight);

    // Slice off future redo steps
    const newHistory = historyRef.current.slice(0, historyIndexRef.current + 1);
    newHistory.push(imgData);
    if (newHistory.length > 40) newHistory.shift(); // 40 steps undo buffer

    historyRef.current = newHistory;
    historyIndexRef.current = newHistory.length - 1;
    setCanUndo(historyIndexRef.current > 0);
    setCanRedo(false);
    updateStats();
  }, [getContexts, canvasWidth, canvasHeight, updateStats]);

  // Redraw clean pixel buffer to display canvas
  const renderDisplay = useCallback(() => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.displayCtx || !ctxs.bufferCanvas) return;
    const { displayCtx, bufferCanvas, displayCanvas } = ctxs;

    displayCanvas.width = canvasWidth;
    displayCanvas.height = canvasHeight;

    displayCtx.imageSmoothingEnabled = false;
    displayCtx.clearRect(0, 0, canvasWidth, canvasHeight);
    displayCtx.drawImage(bufferCanvas, 0, 0);
  }, [getContexts, canvasWidth, canvasHeight]);

  // Initial Canvas Setup or Dimension Change
  useEffect(() => {
    const ctxs = getContexts();
    if (ctxs && ctxs.bufCtx) {
      ctxs.bufCtx.fillStyle = '#FFFFFF';
      ctxs.bufCtx.fillRect(0, 0, canvasWidth, canvasHeight);
      historyRef.current = [];
      historyIndexRef.current = -1;
      saveHistory();
      renderDisplay();
    }
  }, [canvasWidth, canvasHeight, getContexts, renderDisplay, saveHistory]);

  // Apply Dimension Change (with option to preserve existing content)
  const applyNewDimensions = (newW: number, newH: number, preserve: boolean = true, zoomPreset?: number) => {
    const safeW = Math.max(8, Math.min(1024, Math.round(newW)));
    const safeH = Math.max(8, Math.min(1536, Math.round(newH)));

    const ctxs = getContexts();
    let oldImgData: ImageData | null = null;
    const oldW = canvasWidth;
    const oldH = canvasHeight;

    if (preserve && ctxs && ctxs.bufCtx) {
      oldImgData = ctxs.bufCtx.getImageData(0, 0, oldW, oldH);
    }

    setCanvasWidth(safeW);
    setCanvasHeight(safeH);
    setCustomW(String(safeW));
    setCustomH(String(safeH));

    // Choose comfortable zoom
    if (zoomPreset) {
      setZoomLevel(zoomPreset);
    } else {
      if (safeW <= 16) setZoomLevel(1200);
      else if (safeW <= 32) setZoomLevel(1000);
      else if (safeW <= 48) setZoomLevel(700);
      else if (safeW <= 64) setZoomLevel(600);
      else if (safeW <= 100) setZoomLevel(450);
      else if (safeW <= 128) setZoomLevel(350);
      else if (safeW <= 200) setZoomLevel(250);
      else setZoomLevel(125);
    }

    setTimeout(() => {
      if (!bufferCanvasRef.current) return;
      const buf = bufferCanvasRef.current;
      buf.width = safeW;
      buf.height = safeH;
      const bCtx = buf.getContext('2d');
      if (!bCtx) return;

      bCtx.fillStyle = '#FFFFFF';
      bCtx.fillRect(0, 0, safeW, safeH);

      if (preserve && oldImgData) {
        const tempC = document.createElement('canvas');
        tempC.width = oldW;
        tempC.height = oldH;
        const tCtx = tempC.getContext('2d');
        if (tCtx) {
          tCtx.putImageData(oldImgData, 0, 0);
          bCtx.drawImage(tempC, 0, 0);
        }
      }

      historyRef.current = [];
      historyIndexRef.current = -1;
      saveHistory();
      renderDisplay();
      setShowDimensionModal(false);
    }, 50);
  };

  // Undo Handler
  const handleUndo = () => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current -= 1;
      const ctxs = getContexts();
      if (ctxs && ctxs.bufCtx) {
        ctxs.bufCtx.putImageData(historyRef.current[historyIndexRef.current], 0, 0);
        renderDisplay();
        updateStats();
      }
      setCanUndo(historyIndexRef.current > 0);
      setCanRedo(historyIndexRef.current < historyRef.current.length - 1);
    }
  };

  // Redo Handler
  const handleRedo = () => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current += 1;
      const ctxs = getContexts();
      if (ctxs && ctxs.bufCtx) {
        ctxs.bufCtx.putImageData(historyRef.current[historyIndexRef.current], 0, 0);
        renderDisplay();
        updateStats();
      }
      setCanUndo(historyIndexRef.current > 0);
      setCanRedo(historyIndexRef.current < historyRef.current.length - 1);
    }
  };

  // Clear Canvas
  const handleClear = () => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    ctxs.bufCtx.fillStyle = '#FFFFFF';
    ctxs.bufCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    saveHistory();
    renderDisplay();
  };

  // Fill Canvas with Black
  const handleFillAll = () => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    ctxs.bufCtx.fillStyle = '#000000';
    ctxs.bufCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    saveHistory();
    renderDisplay();
  };

  // Transform Actions: Invert, Flip H, Flip V, Rotate 90, Shift
  const handleInvertColors = () => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const imgData = ctxs.bufCtx.getImageData(0, 0, canvasWidth, canvasHeight);
    for (let i = 0; i < imgData.data.length; i += 4) {
      const isBlack = imgData.data[i] < 128;
      const newVal = isBlack ? 255 : 0;
      imgData.data[i] = newVal;
      imgData.data[i + 1] = newVal;
      imgData.data[i + 2] = newVal;
    }
    ctxs.bufCtx.putImageData(imgData, 0, 0);
    saveHistory();
    renderDisplay();
  };

  const handleFlipHorizontal = () => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvasWidth;
    tempCanvas.height = canvasHeight;
    const tCtx = tempCanvas.getContext('2d');
    if (!tCtx) return;
    tCtx.drawImage(ctxs.bufferCanvas, 0, 0);

    ctxs.bufCtx.save();
    ctxs.bufCtx.translate(canvasWidth, 0);
    ctxs.bufCtx.scale(-1, 1);
    ctxs.bufCtx.drawImage(tempCanvas, 0, 0);
    ctxs.bufCtx.restore();

    saveHistory();
    renderDisplay();
  };

  const handleFlipVertical = () => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvasWidth;
    tempCanvas.height = canvasHeight;
    const tCtx = tempCanvas.getContext('2d');
    if (!tCtx) return;
    tCtx.drawImage(ctxs.bufferCanvas, 0, 0);

    ctxs.bufCtx.save();
    ctxs.bufCtx.translate(0, canvasHeight);
    ctxs.bufCtx.scale(1, -1);
    ctxs.bufCtx.drawImage(tempCanvas, 0, 0);
    ctxs.bufCtx.restore();

    saveHistory();
    renderDisplay();
  };

  const handleRotate90 = () => {
    // For squares or any size, rotate 90 clockwise
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvasWidth;
    tempCanvas.height = canvasHeight;
    const tCtx = tempCanvas.getContext('2d');
    if (!tCtx) return;
    tCtx.drawImage(ctxs.bufferCanvas, 0, 0);

    // If width != height, swap
    if (canvasWidth !== canvasHeight) {
      const newW = canvasHeight;
      const newH = canvasWidth;
      setCanvasWidth(newW);
      setCanvasHeight(newH);
      setCustomW(String(newW));
      setCustomH(String(newH));
      ctxs.bufferCanvas.width = newW;
      ctxs.bufferCanvas.height = newH;
    }

    ctxs.bufCtx.save();
    ctxs.bufCtx.fillStyle = '#FFFFFF';
    ctxs.bufCtx.fillRect(0, 0, ctxs.bufferCanvas.width, ctxs.bufferCanvas.height);
    ctxs.bufCtx.translate(ctxs.bufferCanvas.width / 2, ctxs.bufferCanvas.height / 2);
    ctxs.bufCtx.rotate((90 * Math.PI) / 180);
    ctxs.bufCtx.drawImage(tempCanvas, -tempCanvas.width / 2, -tempCanvas.height / 2);
    ctxs.bufCtx.restore();

    saveHistory();
    renderDisplay();
  };

  const handleShift = (dx: number, dy: number) => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const imgData = ctxs.bufCtx.getImageData(0, 0, canvasWidth, canvasHeight);
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvasWidth;
    tempCanvas.height = canvasHeight;
    const tCtx = tempCanvas.getContext('2d');
    if (!tCtx) return;
    tCtx.putImageData(imgData, 0, 0);

    ctxs.bufCtx.fillStyle = '#FFFFFF';
    ctxs.bufCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    ctxs.bufCtx.drawImage(tempCanvas, dx, dy);

    saveHistory();
    renderDisplay();
  };

  // Fit to screen calculation
  const handleFitToScreen = () => {
    if (!stageContainerRef.current) return;
    const { clientWidth, clientHeight } = stageContainerRef.current;
    const availableW = Math.max(200, clientWidth - 48);
    const availableH = Math.max(200, clientHeight - 48);

    const fitZoomW = (availableW / canvasWidth) * 100;
    const fitZoomH = (availableH / canvasHeight) * 100;
    const minZoom = Math.min(fitZoomW, fitZoomH);

    // Snap to nice round percentage
    const rounded = Math.max(50, Math.min(1200, Math.floor(minZoom / 25) * 25));
    setZoomLevel(rounded);
  };

  // Get Precise Canvas Pixel Coordinates from Pointer
  const getCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!displayCanvasRef.current) return { x: 0, y: 0 };
    const rect = displayCanvasRef.current.getBoundingClientRect();
    const scaleX = canvasWidth / rect.width;
    const scaleY = canvasHeight / rect.height;

    const x = Math.floor((e.clientX - rect.left) * scaleX);
    const y = Math.floor((e.clientY - rect.top) * scaleY);
    return {
      x: Math.max(0, Math.min(canvasWidth - 1, x)),
      y: Math.max(0, Math.min(canvasHeight - 1, y))
    };
  };

  // Draw Pixel Block (Exact 1x1, 2x2, 3x3, 4x4 with Shape)
  const drawPixelBlock = (
    bufCtx: CanvasRenderingContext2D,
    x: number,
    y: number,
    color: string,
    size: number,
    shape: BrushShape,
    isDither: boolean = false
  ) => {
    const half = Math.floor(size / 2);
    const startX = x - half;
    const startY = y - half;

    for (let dy = 0; dy < size; dy++) {
      for (let dx = 0; dx < size; dx++) {
        const px = startX + dx;
        const py = startY + dy;

        if (px < 0 || px >= canvasWidth || py < 0 || py >= canvasHeight) continue;

        // Shape test
        if (size > 2 && shape === 'round') {
          const distSq = (dx - half + 0.5) ** 2 + (dy - half + 0.5) ** 2;
          if (distSq > (size / 2) ** 2) continue;
        }

        // Dither test (50% checkerboard)
        if (isDither) {
          if ((px + py) % 2 !== 0) continue;
        }

        bufCtx.fillStyle = color;
        bufCtx.fillRect(px, py, 1, 1);
      }
    }
  };

  // Continuous Bresenham's Line Algorithm
  const drawLine = (
    bufCtx: CanvasRenderingContext2D,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    color: string,
    size: number,
    shape: BrushShape,
    isDither: boolean = false
  ) => {
    const dx = Math.abs(x1 - x0);
    const dy = Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1;
    const sy = y0 < y1 ? 1 : -1;
    let err = dx - dy;

    let currX = x0;
    let currY = y0;

    while (true) {
      drawPixelBlock(bufCtx, currX, currY, color, size, shape, isDither);
      if (currX === x1 && currY === y1) break;
      const e2 = 2 * err;
      if (e2 > -dy) {
        err -= dy;
        currX += sx;
      }
      if (e2 < dx) {
        err += dx;
        currY += sy;
      }
    }
  };

  // 4-Way Flood Fill (Bucket)
  const floodFill = (bufCtx: CanvasRenderingContext2D, startX: number, startY: number, targetIsBlack: boolean) => {
    const imgData = bufCtx.getImageData(0, 0, canvasWidth, canvasHeight);
    const data = imgData.data;

    const getIsBlack = (x: number, y: number) => {
      const idx = (y * canvasWidth + x) * 4;
      return data[idx] < 128;
    };

    const targetVal = targetIsBlack ? 1 : 0;
    const fillVal = targetIsBlack ? 0 : 1; // Flip

    if (targetVal === fillVal) return;
    const clickedIsBlack = getIsBlack(startX, startY);
    if (clickedIsBlack !== targetIsBlack) return;

    const stack: [number, number][] = [[startX, startY]];
    const visited = new Uint8Array(canvasWidth * canvasHeight);

    while (stack.length > 0) {
      const [x, y] = stack.pop()!;
      const pos = y * canvasWidth + x;
      if (visited[pos]) continue;
      visited[pos] = 1;

      if (getIsBlack(x, y) === clickedIsBlack) {
        const idx = pos * 4;
        const col = fillVal === 1 ? 0 : 255;
        data[idx] = col;
        data[idx + 1] = col;
        data[idx + 2] = col;
        data[idx + 3] = 255;

        if (x > 0) stack.push([x - 1, y]);
        if (x < canvasWidth - 1) stack.push([x + 1, y]);
        if (y > 0) stack.push([x, y - 1]);
        if (y < canvasHeight - 1) stack.push([x, y + 1]);
      }
    }

    bufCtx.putImageData(imgData, 0, 0);
  };

  // Stamp Bitmap Micro Text onto Canvas
  const stampMicroText = (bufCtx: CanvasRenderingContext2D, x: number, y: number) => {
    if (!stampText.trim()) return;
    const { width, height, pixels } = renderBitmapText(stampText, textScale, fontType, textInverted);

    for (let r = 0; r < height; r++) {
      for (let c = 0; c < width; c++) {
        const val = pixels[r][c];
        const px = x + c;
        const py = y + r;
        if (px >= 0 && px < canvasWidth && py >= 0 && py < canvasHeight) {
          bufCtx.fillStyle = val === 1 ? '#000000' : '#FFFFFF';
          bufCtx.fillRect(px, py, 1, 1);
        }
      }
    }
  };

  // Shape Drawers
  const drawRectangle = (bufCtx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, filled: boolean, size: number) => {
    const minX = Math.min(x0, x1);
    const maxX = Math.max(x0, x1);
    const minY = Math.min(y0, y1);
    const maxY = Math.max(y0, y1);

    if (filled) {
      for (let y = minY; y <= maxY; y++) {
        for (let x = minX; x <= maxX; x++) {
          bufCtx.fillStyle = '#000000';
          bufCtx.fillRect(x, y, 1, 1);
        }
      }
    } else {
      // Outline with exact pixel thickness
      for (let t = 0; t < size; t++) {
        const curMinX = minX + t;
        const curMaxX = maxX - t;
        const curMinY = minY + t;
        const curMaxY = maxY - t;
        if (curMinX > curMaxX || curMinY > curMaxY) break;

        for (let x = curMinX; x <= curMaxX; x++) {
          bufCtx.fillStyle = '#000000';
          bufCtx.fillRect(x, curMinY, 1, 1);
          bufCtx.fillRect(x, curMaxY, 1, 1);
        }
        for (let y = curMinY; y <= curMaxY; y++) {
          bufCtx.fillStyle = '#000000';
          bufCtx.fillRect(curMinX, y, 1, 1);
          bufCtx.fillRect(curMaxX, y, 1, 1);
        }
      }
    }
  };

  const drawCircleShape = (bufCtx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, filled: boolean, size: number) => {
    const radiusX = Math.abs(x1 - x0) / 2;
    const radiusY = Math.abs(y1 - y0) / 2;
    const centerX = Math.min(x0, x1) + radiusX;
    const centerY = Math.min(y0, y1) + radiusY;
    const rx = Math.max(0.5, radiusX);
    const ry = Math.max(0.5, radiusY);

    const minX = Math.floor(centerX - rx);
    const maxX = Math.ceil(centerX + rx);
    const minY = Math.floor(centerY - ry);
    const maxY = Math.ceil(centerY + ry);

    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        if (x < 0 || x >= canvasWidth || y < 0 || y >= canvasHeight) continue;
        const normalizedDist = ((x + 0.5 - centerX) / rx) ** 2 + ((y + 0.5 - centerY) / ry) ** 2;

        if (filled) {
          if (normalizedDist <= 1.0) {
            bufCtx.fillStyle = '#000000';
            bufCtx.fillRect(x, y, 1, 1);
          }
        } else {
          // Ring with thickness
          const innerRx = Math.max(0.1, rx - size);
          const innerRy = Math.max(0.1, ry - size);
          const innerNormDist = ((x + 0.5 - centerX) / innerRx) ** 2 + ((y + 0.5 - centerY) / innerRy) ** 2;
          if (normalizedDist <= 1.05 && innerNormDist >= 0.75) {
            bufCtx.fillStyle = '#000000';
            bufCtx.fillRect(x, y, 1, 1);
          }
        }
      }
    }
  };

  // Pointer Event Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const { bufCtx } = ctxs;

    isDrawingRef.current = true;
    const coords = getCanvasCoords(e);
    startPosRef.current = coords;

    if (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither') {
      const color = activeTool === 'eraser' ? '#FFFFFF' : '#000000';
      const isDither = activeTool === 'dither';
      drawPixelBlock(bufCtx, coords.x, coords.y, color, brushSize, brushShape, isDither);
      renderDisplay();
    } else if (activeTool === 'fill') {
      const imgData = bufCtx.getImageData(coords.x, coords.y, 1, 1);
      const isBlack = imgData.data[0] < 128;
      floodFill(bufCtx, coords.x, coords.y, isBlack);
      saveHistory();
      renderDisplay();
      isDrawingRef.current = false;
    } else if (activeTool === 'text') {
      stampMicroText(bufCtx, coords.x, coords.y);
      saveHistory();
      renderDisplay();
      isDrawingRef.current = false;
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoords(e);
    setHoverCoord(coords);

    if (!isDrawingRef.current || !startPosRef.current) return;
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const { bufCtx } = ctxs;
    const prev = startPosRef.current;

    if (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither') {
      const color = activeTool === 'eraser' ? '#FFFFFF' : '#000000';
      const isDither = activeTool === 'dither';
      drawLine(bufCtx, prev.x, prev.y, coords.x, coords.y, color, brushSize, brushShape, isDither);
      startPosRef.current = coords;
      renderDisplay();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // Ignored
    }

    if (!isDrawingRef.current) return;
    const ctxs = getContexts();
    if (ctxs && ctxs.bufCtx && startPosRef.current) {
      const { bufCtx } = ctxs;
      const coords = getCanvasCoords(e);
      const start = startPosRef.current;

      if (activeTool === 'line') {
        drawLine(bufCtx, start.x, start.y, coords.x, coords.y, '#000000', brushSize, brushShape, false);
        renderDisplay();
      } else if (activeTool === 'rect') {
        drawRectangle(bufCtx, start.x, start.y, coords.x, coords.y, true, brushSize);
        renderDisplay();
      } else if (activeTool === 'rectOutline') {
        drawRectangle(bufCtx, start.x, start.y, coords.x, coords.y, false, brushSize);
        renderDisplay();
      } else if (activeTool === 'circle') {
        drawCircleShape(bufCtx, start.x, start.y, coords.x, coords.y, true, brushSize);
        renderDisplay();
      } else if (activeTool === 'circleOutline') {
        drawCircleShape(bufCtx, start.x, start.y, coords.x, coords.y, false, brushSize);
        renderDisplay();
      }
    }

    isDrawingRef.current = false;
    startPosRef.current = null;
    saveHistory();
  };

  // Image Upload & Import
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setImportedImageSrc(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const applyImportedImageToCanvas = async () => {
    if (!importedImageSrc) return;
    const img = new Image();
    img.src = importedImageSrc;
    await new Promise((resolve) => {
      img.onload = resolve;
    });

    const offCanvas = document.createElement('canvas');
    offCanvas.width = canvasWidth;
    offCanvas.height = canvasHeight;
    const offCtx = offCanvas.getContext('2d');
    if (!offCtx) return;

    const aspect = img.width / img.height;
    let targetW = canvasWidth;
    let targetH = canvasWidth / aspect;

    if (importFitMode === 'contain') {
      if (targetH > canvasHeight) {
        targetH = canvasHeight;
        targetW = canvasHeight * aspect;
      }
    } else {
      if (targetH < canvasHeight) {
        targetH = canvasHeight;
        targetW = canvasHeight * aspect;
      }
    }

    const offsetX = (canvasWidth - targetW) / 2;
    const offsetY = (canvasHeight - targetH) / 2;

    offCtx.fillStyle = '#FFFFFF';
    offCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    offCtx.drawImage(img, offsetX, offsetY, targetW, targetH);

    // 1-Bit Dither processing
    const bitmap = processImage(
      offCtx,
      canvasWidth,
      canvasHeight,
      importDither,
      { brightness: 0, contrast: 0, invert: importInvert },
      { msbFirst: true }
    );

    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufCtx) return;
    const { bufCtx } = ctxs;

    const bytesPerRow = Math.ceil(canvasWidth / 8);
    const imgData = bufCtx.createImageData(canvasWidth, canvasHeight);

    for (let y = 0; y < canvasHeight; y++) {
      for (let x = 0; x < canvasWidth; x++) {
        const byteIndex = y * bytesPerRow + (x >> 3);
        const bitMask = 0x80 >> (x & 7);
        const isBlack = (bitmap[byteIndex] & bitMask) !== 0;
        const pixelIdx = (y * canvasWidth + x) * 4;
        const col = isBlack ? 0 : 255;
        imgData.data[pixelIdx] = col;
        imgData.data[pixelIdx + 1] = col;
        imgData.data[pixelIdx + 2] = col;
        imgData.data[pixelIdx + 3] = 255;
      }
    }
    bufCtx.putImageData(imgData, 0, 0);

    saveHistory();
    renderDisplay();
    setShowImportModal(false);
  };

  // Build Print Image with Smart Thermal Scaling & Centering
  const buildThermalPrintImage = (mode: 'auto-scale' | 'bordered' | 'native-center' | 'full-width'): string => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufferCanvas) return '';

    const targetPaperWidth = pageWidth >= 576 ? 576 : 384;
    const outCanvas = document.createElement('canvas');

    let scale = 1;
    let finalW = canvasWidth;
    let finalH = canvasHeight;

    if (mode === 'full-width') {
      scale = targetPaperWidth / canvasWidth;
      finalW = targetPaperWidth;
      finalH = Math.round(canvasHeight * scale);
    } else if (mode === 'auto-scale' || mode === 'bordered') {
      // Calculate integer scale so pixels remain 100% crisp squares
      const maxIntegerScale = Math.max(1, Math.floor((targetPaperWidth - (mode === 'bordered' ? 32 : 16)) / canvasWidth));
      scale = maxIntegerScale;
      finalW = canvasWidth * scale;
      finalH = canvasHeight * scale;
    } else {
      // native 1:1
      scale = 1;
      finalW = canvasWidth;
      finalH = canvasHeight;
    }

    const paddingX = Math.max(0, Math.floor((targetPaperWidth - finalW) / 2));
    const paddingY = 24; // Top & bottom margin for clean tear

    const totalHeight = finalH + paddingY * 2 + (printTitle.trim() ? 36 : 0);
    outCanvas.width = targetPaperWidth;
    outCanvas.height = totalHeight;

    const outCtx = outCanvas.getContext('2d');
    if (!outCtx) return '';

    outCtx.fillStyle = '#FFFFFF';
    outCtx.fillRect(0, 0, targetPaperWidth, totalHeight);
    outCtx.imageSmoothingEnabled = false;

    let startY = paddingY;

    // Draw optional title
    if (printTitle.trim()) {
      outCtx.fillStyle = '#000000';
      outCtx.font = 'bold 16px monospace';
      outCtx.textAlign = 'center';
      outCtx.fillText(printTitle.trim(), targetPaperWidth / 2, startY + 16);
      startY += 30;
    }

    // Draw border if requested
    if (mode === 'bordered') {
      outCtx.strokeStyle = '#000000';
      outCtx.lineWidth = 3;
      outCtx.strokeRect(paddingX - 6, startY - 6, finalW + 12, finalH + 12);
      outCtx.lineWidth = 1;
      outCtx.strokeRect(paddingX - 10, startY - 10, finalW + 20, finalH + 20);
    }

    // Draw the scaled artwork
    outCtx.drawImage(ctxs.bufferCanvas, paddingX, startY, finalW, finalH);

    return outCanvas.toDataURL('image/png');
  };

  // Direct Print & Composer Print
  const handlePrintClick = () => {
    // If it's a small canvas (<= 200px), open print modal to offer nice 3x scaling & sticker borders
    if (canvasWidth <= 200) {
      setShowPrintModal(true);
    } else {
      // Direct print full width
      const dataUrl = buildThermalPrintImage('auto-scale');
      const widthMm = pageWidth >= 576 ? 80 : 57;
      onPrintImage(dataUrl, `Piksel Çizim (${canvasWidth}x${canvasHeight})`, widthMm);
    }
  };

  const handleConfirmModalPrint = () => {
    const dataUrl = buildThermalPrintImage(printLayoutMode);
    const widthMm = pageWidth >= 576 ? 80 : 57;
    onPrintImage(dataUrl, `Piksel Çizim (${canvasWidth}x${canvasHeight})`, widthMm);
    setShowPrintModal(false);
  };

  // Download HD PNG
  const handleDownload = (scaleMultiplier: number = 1) => {
    const ctxs = getContexts();
    if (!ctxs || !ctxs.bufferCanvas) return;

    if (scaleMultiplier === 1) {
      const link = document.createElement('a');
      link.download = `pixel-canvas-${canvasWidth}x${canvasHeight}.png`;
      link.href = ctxs.bufferCanvas.toDataURL('image/png');
      link.click();
    } else {
      const hdCanvas = document.createElement('canvas');
      hdCanvas.width = canvasWidth * scaleMultiplier;
      hdCanvas.height = canvasHeight * scaleMultiplier;
      const hdCtx = hdCanvas.getContext('2d');
      if (hdCtx) {
        hdCtx.imageSmoothingEnabled = false;
        hdCtx.drawImage(ctxs.bufferCanvas, 0, 0, hdCanvas.width, hdCanvas.height);
        const link = document.createElement('a');
        link.download = `pixel-art-HD-${hdCanvas.width}x${hdCanvas.height}.png`;
        link.href = hdCanvas.toDataURL('image/png');
        link.click();
      }
    }
  };

  // Mathematical Pixel Display Scale
  const pixelCellSize = zoomLevel / 100;
  const displayStyleWidth = Math.round(canvasWidth * pixelCellSize);
  const displayStyleHeight = Math.round(canvasHeight * pixelCellSize);

  // Guide step (every 10px for 100x100 or decimal scales, else 8px)
  const majorGuideStep = canvasWidth % 10 === 0 ? 10 : 8;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-3 max-w-6xl mx-auto pb-12"
    >
      {/* Top Header & Fast Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 p-3.5 rounded-3xl bg-slate-900 text-white shadow-lg border border-slate-800">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
              title="Geri Dön"
            >
              <ArrowLeft size={17} />
            </button>
          )}
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10.5px] font-bold">
              <Sparkles size={11} /> 1-Bit Piksel Çizim & Mikro Font Tuvali
            </div>
            <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
              Piksel Tuval ({canvasWidth}×{canvasHeight} px)
            </h2>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowDimensionModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Sliders size={14} className="text-indigo-400" />
            Özel Ebat ({canvasWidth}x{canvasHeight})
          </button>

          <button
            onClick={() => setShowImportModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Upload size={14} className="text-indigo-400" />
            Resim İçe Aktar
          </button>

          <div className="flex items-center bg-slate-800 rounded-xl p-0.5 border border-slate-700">
            <button
              onClick={() => handleDownload(1)}
              className="px-2.5 py-1 text-[11px] font-bold text-slate-300 hover:text-white"
              title="1x Orijinal PNG İndir"
            >
              PNG
            </button>
            <button
              onClick={() => handleDownload(4)}
              className="px-2 py-1 text-[10px] font-bold bg-indigo-600/60 text-indigo-200 rounded-lg hover:bg-indigo-600"
              title="4x HD Piksel İndir"
            >
              4x HD
            </button>
          </div>

          <button
            onClick={handlePrintClick}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-xs font-black shadow-md flex items-center gap-1.5 cursor-pointer"
          >
            <Printer size={15} />
            Yazdır (Print)
          </button>
        </div>
      </div>

      {/* Fast 1-Click Resolution Switcher Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 px-1 scrollbar-none">
        <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider shrink-0 flex items-center gap-1 mr-1">
          <Layers size={13} className="text-indigo-500" /> Ebat:
        </span>
        {[
          { w: 100, h: 100, label: '100x100 (Kare)', badge: '⭐ Önerilen' },
          { w: 32, h: 32, label: '32x32 (Sprite)' },
          { w: 64, h: 64, label: '64x64 (Rozet)' },
          { w: 80, h: 80, label: '80x80 (İkon)' },
          { w: 128, h: 128, label: '128x128 (Büyük)' },
          { w: 150, h: 100, label: '150x100 (Yatay)' },
          { w: 100, h: 150, label: '100x150 (Dikey)' },
          { w: 384, h: 384, label: '384x384 (Rulo)' },
        ].map((item) => {
          const isSelected = canvasWidth === item.w && canvasHeight === item.h;
          return (
            <button
              key={`${item.w}x${item.h}`}
              onClick={() => applyNewDimensions(item.w, item.h, preserveContentOnResize)}
              className={`px-3 py-1 rounded-xl text-xs font-black whitespace-nowrap transition-all border cursor-pointer flex items-center gap-1 ${
                isSelected
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50'
              }`}
            >
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[9px] px-1 py-0.2 rounded bg-amber-400 text-slate-950 font-black">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Studio Grid: Left Tools + Center Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Left Side: Drawing Tools, Brushes & Micro Typography */}
        <Card className="lg:col-span-3.5 p-3.5 rounded-3xl border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3.5 shadow-sm">
          {/* Drawing Tool Buttons */}
          <div>
            <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1.5">
              Çizim Araçları
            </label>
            <div className="grid grid-cols-5 gap-1">
              {[
                { id: 'pencil', label: 'Kalem', icon: <Pencil size={15} /> },
                { id: 'eraser', label: 'Silgi', icon: <Eraser size={15} /> },
                { id: 'dither', label: 'Tonlama', icon: <Palette size={15} /> },
                { id: 'fill', label: 'Kova', icon: <PaintBucket size={15} /> },
                { id: 'line', label: 'Çizgi', icon: <Minus size={15} /> },
                { id: 'rect', label: 'Dolu Kutu', icon: <Square size={15} className="fill-current" /> },
                { id: 'rectOutline', label: 'Çerçeve', icon: <Square size={15} /> },
                { id: 'circle', label: 'Daire', icon: <Circle size={15} className="fill-current" /> },
                { id: 'circleOutline', label: 'Çember', icon: <Circle size={15} /> },
                { id: 'text', label: 'Mikro Font', icon: <Type size={15} /> },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActiveTool(t.id as ToolType)}
                  className={`p-1.5 rounded-xl text-[10px] font-bold transition-all flex flex-col items-center gap-1 cursor-pointer ${
                    activeTool === t.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                  title={t.label}
                >
                  {t.icon}
                  <span className="truncate text-[9.5px]">{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Brush Size & Shape */}
          <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Fırça Boyutu
              </label>
              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                {brushSize}x{brushSize} px
              </span>
            </div>

            <div className="grid grid-cols-7 gap-1">
              {([1, 2, 3, 4, 6, 8, 12] as BrushSize[]).map((size) => (
                <button
                  key={size}
                  onClick={() => setBrushSize(size)}
                  className={`py-1 rounded-lg text-[10.5px] font-black transition-all border cursor-pointer ${
                    brushSize === size
                      ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {size}p
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-slate-500 font-bold text-[10.5px]">Uç Tipi:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => setBrushShape('square')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${
                    brushShape === 'square'
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Kare Blok
                </button>
                <button
                  onClick={() => setBrushShape('round')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${
                    brushShape === 'round'
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white dark:bg-slate-800 text-slate-600 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Yuvarlak
                </button>
              </div>
            </div>
          </div>

          {/* Micro Typography Inspector */}
          {activeTool === 'text' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="p-3 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 space-y-2"
            >
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-indigo-900 dark:text-indigo-200">
                  Gömülü 1-Bit Mikro Font
                </label>
                <span className="text-[8.5px] font-bold px-1.5 py-0.2 rounded bg-indigo-200 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
                  0 Anti-Alias
                </span>
              </div>

              <input
                type="text"
                value={stampText}
                onChange={(e) => setStampText(e.target.value)}
                placeholder="Basılacak metin..."
                className="w-full px-2.5 py-1 rounded-xl border border-indigo-300 dark:border-indigo-800 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
              />

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[9.5px] font-bold text-indigo-700 dark:text-indigo-300 block mb-0.5">
                    Font Matrisi:
                  </label>
                  <div className="flex gap-1">
                    {(['5x7', '7x9'] as const).map((f) => (
                      <button
                        key={f}
                        onClick={() => setFontType(f)}
                        className={`flex-1 py-0.5 rounded-lg text-[9.5px] font-bold border ${
                          fontType === f
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-white dark:bg-slate-900 text-indigo-700 border-indigo-200 dark:border-indigo-800'
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[9.5px] font-bold text-indigo-700 dark:text-indigo-300 block mb-0.5">
                    Ölçek:
                  </label>
                  <div className="flex gap-1">
                    {[1, 2, 3].map((s) => (
                      <button
                        key={s}
                        onClick={() => setTextScale(s)}
                        className={`flex-1 py-0.5 rounded-lg text-[9.5px] font-bold ${
                          textScale === s
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white dark:bg-slate-900 text-indigo-700 border border-indigo-200 dark:border-indigo-800'
                        }`}
                      >
                        {s}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <label className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-800 dark:text-indigo-200 cursor-pointer pt-0.5">
                <input
                  type="checkbox"
                  checked={textInverted}
                  onChange={(e) => setTextInverted(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                Ters Zemin (Siyah Kutu İçinde Beyaz Yazı)
              </label>
            </motion.div>
          )}

          {/* Transformation & Shift Tools */}
          <div>
            <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1">
              Dönüştürme & Aynalama
            </label>
            <div className="grid grid-cols-4 gap-1">
              <button
                onClick={handleInvertColors}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-bold flex flex-col items-center gap-0.5 cursor-pointer"
                title="Renkleri Ters Çevir"
              >
                <RefreshCw size={14} />
                <span className="text-[9px]">Ters Çevir</span>
              </button>

              <button
                onClick={handleFlipHorizontal}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-bold flex flex-col items-center gap-0.5 cursor-pointer"
                title="Yatay Aynala"
              >
                <FlipHorizontal size={14} />
                <span className="text-[9px]">Yatay</span>
              </button>

              <button
                onClick={handleFlipVertical}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-bold flex flex-col items-center gap-0.5 cursor-pointer"
                title="Dikey Aynala"
              >
                <FlipVertical size={14} />
                <span className="text-[9px]">Dikey</span>
              </button>

              <button
                onClick={handleRotate90}
                className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-bold flex flex-col items-center gap-0.5 cursor-pointer"
                title="90° Sağa Döndür"
              >
                <RotateCw size={14} />
                <span className="text-[9px]">Döndür</span>
              </button>
            </div>

            {/* D-Pad Pixel Shift */}
            <div className="flex items-center justify-between mt-1.5 px-2 py-1 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/50 text-[10px] font-bold">
              <span className="text-slate-500">Piksel Kaydır:</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleShift(-1, 0)}
                  className="p-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                  title="1px Sola"
                >
                  <ArrowLeftIcon size={12} />
                </button>
                <button
                  onClick={() => handleShift(0, -1)}
                  className="p-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                  title="1px Yukarı"
                >
                  <ArrowUp size={12} />
                </button>
                <button
                  onClick={() => handleShift(0, 1)}
                  className="p-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                  title="1px Aşağı"
                >
                  <ArrowDown size={12} />
                </button>
                <button
                  onClick={() => handleShift(1, 0)}
                  className="p-1 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                  title="1px Sağa"
                >
                  <ArrowRight size={12} />
                </button>
              </div>
            </div>
          </div>

          {/* Undo / Redo & Clear */}
          <div className="flex items-center justify-between gap-1 pt-1.5 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-1">
              <button
                onClick={handleUndo}
                disabled={!canUndo}
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 disabled:opacity-30 transition-opacity cursor-pointer flex items-center gap-1 text-xs font-bold"
                title="Geri Al"
              >
                <RotateCcw size={14} /> Geri
              </button>
              <button
                onClick={handleRedo}
                disabled={!canRedo}
                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 disabled:opacity-30 transition-opacity cursor-pointer flex items-center gap-1 text-xs font-bold"
                title="İleri Al"
              >
                <RotateCw size={14} /> İleri
              </button>
            </div>

            <button
              onClick={handleClear}
              className="px-2.5 py-1.5 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 text-xs font-bold border border-red-200 dark:border-red-900 flex items-center gap-1 hover:bg-red-100 cursor-pointer"
            >
              <Trash2 size={14} /> Temizle
            </button>
          </div>
        </Card>

        {/* Center & Right: High-Precision 1:1 Pixel Canvas Stage */}
        <div className="lg:col-span-8.5 space-y-2">
          {/* Stage Controls Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-xs font-bold">
            {/* Zoom Controls */}
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 text-[11px]">Yakınlaştırma:</span>
              <div className="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
                <button
                  onClick={() => setZoomLevel((z) => Math.max(50, z - 50))}
                  className="p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                  title="Uzaklaştır"
                >
                  <ZoomOut size={14} />
                </button>
                <span className="px-1.5 font-mono font-black text-indigo-600 dark:text-indigo-400 min-w-[48px] text-center text-xs">
                  %{zoomLevel}
                </span>
                <button
                  onClick={() => setZoomLevel((z) => Math.min(1200, z + 50))}
                  className="p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                  title="Yakınlaştır"
                >
                  <ZoomIn size={14} />
                </button>
              </div>

              <button
                onClick={handleFitToScreen}
                className="px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950 text-slate-700 dark:text-slate-300 text-[11px] font-bold border border-slate-200 dark:border-slate-700"
                title="Ekrana Sığdır"
              >
                Sığdır
              </button>

              {/* Quick zoom pills */}
              <div className="hidden sm:flex items-center gap-1">
                {[100, 300, 450, 600, 800].map((z) => (
                  <button
                    key={z}
                    onClick={() => setZoomLevel(z)}
                    className={`px-1.5 py-0.5 rounded-lg text-[10px] font-bold ${
                      zoomLevel === z
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    %{z}
                  </button>
                ))}
              </div>
            </div>

            {/* Grid & Guide Toggles + Coordinates */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowGrid(!showGrid)}
                className={`px-2.5 py-1 rounded-xl border text-[11px] transition-all flex items-center gap-1 cursor-pointer ${
                  showGrid
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-300 dark:bg-indigo-950/60 dark:text-indigo-300'
                    : 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400'
                }`}
              >
                <Grid size={13} /> Izgara: {showGrid ? 'AÇIK' : 'KAPALI'}
              </button>

              <div className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-[11px] text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <span className="font-bold">{canvasWidth}×{canvasHeight}px</span>
                {hoverCoord && (
                  <span className="text-indigo-600 dark:text-indigo-400 font-black">
                    [{hoverCoord.x}, {hoverCoord.y}]
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Precision Stage Viewport */}
          <Card
            ref={stageContainerRef}
            className="p-6 rounded-3xl border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 min-h-[500px] max-h-[720px] overflow-auto shadow-inner flex flex-col items-center justify-center relative select-none"
          >
            {/* The 1:1 Pixel Canvas Stage Container */}
            <div
              className="relative shadow-2xl rounded-sm border-2 border-slate-400 dark:border-slate-700 transition-all bg-white"
              style={{
                width: `${displayStyleWidth}px`,
                height: `${displayStyleHeight}px`,
                minWidth: `${displayStyleWidth}px`,
                minHeight: `${displayStyleHeight}px`,
                maxWidth: `${displayStyleWidth}px`,
                maxHeight: `${displayStyleHeight}px`,
                touchAction: 'none',
              }}
            >
              {/* Primary Pixel Canvas */}
              <canvas
                ref={displayCanvasRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={() => setHoverCoord(null)}
                className="w-full h-full cursor-crosshair block select-none"
                style={{
                  imageRendering: 'pixelated',
                  width: `${displayStyleWidth}px`,
                  height: `${displayStyleHeight}px`,
                }}
              />

              {/* Crisp Non-Destructive CSS/SVG Overlay Grid */}
              {showGrid && pixelCellSize >= 3 && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, rgba(99, 102, 241, 0.22) 1px, transparent 1px),
                      linear-gradient(to bottom, rgba(99, 102, 241, 0.22) 1px, transparent 1px)
                    `,
                    backgroundSize: `${pixelCellSize}px ${pixelCellSize}px`,
                  }}
                />
              )}

              {/* Major Guide Lines (every 10px / 8px) */}
              {showGrid && showMajorGuides && pixelCellSize >= 2 && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, rgba(67, 56, 202, 0.5) 1px, transparent 1px),
                      linear-gradient(to bottom, rgba(67, 56, 202, 0.5) 1px, transparent 1px)
                    `,
                    backgroundSize: `${pixelCellSize * majorGuideStep}px ${pixelCellSize * majorGuideStep}px`,
                  }}
                />
              )}

              {/* Active Hover Pixel Cursor Highlight Box */}
              {hoverCoord && (
                <div
                  className="absolute pointer-events-none border-2 border-indigo-500 bg-indigo-500/20 shadow-xs"
                  style={{
                    left: `${hoverCoord.x * pixelCellSize}px`,
                    top: `${hoverCoord.y * pixelCellSize}px`,
                    width: `${pixelCellSize * (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither' ? brushSize : 1)}px`,
                    height: `${pixelCellSize * (activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither' ? brushSize : 1)}px`,
                    transform:
                      activeTool === 'pencil' || activeTool === 'eraser' || activeTool === 'dither'
                        ? `translate(-${Math.floor(brushSize / 2) * pixelCellSize}px, -${Math.floor(brushSize / 2) * pixelCellSize}px)`
                        : 'none',
                  }}
                />
              )}
            </div>

            {/* Bottom Floating Stats Bar */}
            <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-[11px] font-bold text-slate-500 dark:text-slate-400 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xs px-4 py-1.5 rounded-full border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 dark:bg-white inline-block"></span>
                Termal Piksel Doluluğu: %{((blackPixelCount / (canvasWidth * canvasHeight)) * 100).toFixed(1)}
              </span>
              <span>•</span>
              <span>Toplam: {(canvasWidth * canvasHeight).toLocaleString()} Piksel</span>
              <span>•</span>
              <span className="text-indigo-600 dark:text-indigo-400">1:1 Tam Kare Eşit Pikseller</span>
            </div>
          </Card>
        </div>
      </div>

      {/* Smart Print Composer Modal for Discrete 100x100 Canvases */}
      <AnimatePresence>
        {showPrintModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-black text-base">
                  <Printer size={20} className="text-indigo-600" />
                  Termal Yazdırma & Sayfa Düzeni ({canvasWidth}x{canvasHeight}px)
                </div>
                <button
                  onClick={() => setShowPrintModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  {canvasWidth}x{canvasHeight} ebatındaki piksel çiziminizin {pageWidth >= 576 ? '80mm' : '58mm'} termal kağıda nasıl basılacağını seçin:
                </p>

                <div className="grid grid-cols-1 gap-2">
                  {[
                    {
                      id: 'auto-scale',
                      title: '🚀 Otomatik Büyüt & Ortala (Önerilen)',
                      desc: `${Math.floor((pageWidth >= 576 ? 576 : 384) / canvasWidth)}x Net Piksel Büyütme ile rulo merkezine yerleştirir.`,
                    },
                    {
                      id: 'bordered',
                      title: '🏷️ Retro Çerçeveli Sticker Formatı',
                      desc: 'Piksel çizimin etrafına şık 1-bit çerçeve ekler.',
                    },
                    {
                      id: 'native-center',
                      title: '📐 1:1 Doğal Boyut (Ortalanmış)',
                      desc: `Birebir ${canvasWidth}x${canvasHeight} piksel boyutunda kağıdın ortasına basar.`,
                    },
                    {
                      id: 'full-width',
                      title: '📜 Tam Ruloya Sığdır (Genişlet)',
                      desc: `Rulo genişliğine (${pageWidth >= 576 ? '576px' : '384px'}) tam yayar.`,
                    },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setPrintLayoutMode(opt.id as any)}
                      className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                        printLayoutMode === opt.id
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-900 dark:text-indigo-200 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="text-xs font-black">{opt.title}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">{opt.desc}</div>
                    </button>
                  ))}
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                    İsteğe Bağlı Başlık / Not:
                  </label>
                  <input
                    type="text"
                    value={printTitle}
                    onChange={(e) => setPrintTitle(e.target.value)}
                    placeholder="Örn: Piksel Sanatı #1"
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                <button
                  onClick={() => setShowPrintModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  İptal
                </button>
                <button
                  onClick={handleConfirmModalPrint}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer size={15} /> Baskıyı Başlat
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dimension & Presets Modal */}
      <AnimatePresence>
        {showDimensionModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-xl w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-black text-lg">
                  <Sliders size={22} className="text-indigo-600" />
                  Tuval Ebatları & Sayfa Şablonları
                </div>
                <button
                  onClick={() => setShowDimensionModal(false)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>

              {/* Ready Presets Gallery */}
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                  Hazır Piksel & Kart Şablonları
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                  {CANVAS_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() =>
                        applyNewDimensions(preset.width, preset.height, preserveContentOnResize, preset.recommendedZoom)
                      }
                      className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                        canvasWidth === preset.width && canvasHeight === preset.height
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-900 dark:text-indigo-200 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-base">{preset.icon}</span>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                          {preset.width}x{preset.height} px
                        </span>
                      </div>
                      <div className="text-xs font-black">{preset.name}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{preset.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Dimensions Form */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/70 space-y-3">
                <label className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                  Elle Özel Ölçü Girişi (Manuel Piksel Ebatı)
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                      Genişlik (Width - px)
                    </label>
                    <input
                      type="number"
                      value={customW}
                      onChange={(e) => setCustomW(e.target.value)}
                      min={8}
                      max={1024}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                      Yükseklik (Height - px)
                    </label>
                    <input
                      type="number"
                      value={customH}
                      onChange={(e) => setCustomH(e.target.value)}
                      min={8}
                      max={1536}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                    />
                  </div>
                </div>

                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={preserveContentOnResize}
                    onChange={(e) => setPreserveContentOnResize(e.target.checked)}
                    className="rounded text-indigo-600"
                  />
                  Mevcut çizimi yeni tuvale aktar ve koru
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                <button
                  onClick={() => setShowDimensionModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Kapat
                </button>
                <button
                  onClick={() =>
                    applyNewDimensions(
                      parseInt(customW) || 100,
                      parseInt(customH) || 100,
                      preserveContentOnResize
                    )
                  }
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Check size={16} /> Özel Ebatı Uygula
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Image Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2 text-slate-900 dark:text-white font-black text-base">
                  <Upload size={20} className="text-indigo-600" />
                  Görsel İçe Aktar & 1-Bit Rötuş Modu
                </div>
                <button
                  onClick={() => setShowImportModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3">
                <label className="block p-5 border-2 border-dashed border-indigo-200 dark:border-indigo-900 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 text-center cursor-pointer hover:bg-indigo-100/50 transition-colors">
                  <Upload size={26} className="mx-auto text-indigo-600 mb-1" />
                  <span className="text-xs font-black text-indigo-700 dark:text-indigo-300 block">
                    {importedImageSrc ? 'Farklı Görsel Seç' : 'Galeriden / Dosyalardan Resim Seç'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>

                {importedImageSrc && (
                  <div className="space-y-3 pt-2">
                    <div className="p-3 bg-slate-100 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex justify-center max-h-48 overflow-hidden">
                      <img
                        src={importedImageSrc}
                        alt="Preview"
                        className="max-h-44 object-contain rounded-lg"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                          Pikselleme (Dithering)
                        </label>
                        <select
                          value={importDither}
                          onChange={(e) => setImportDither(e.target.value as any)}
                          className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-bold"
                        >
                          <option value="atkinson">Atkinson (Net Gölge)</option>
                          <option value="floyd-steinberg">Floyd-Steinberg</option>
                          <option value="bayer">Bayer Matrix (Retro)</option>
                          <option value="threshold">Eşik Değeri (Keskin)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">
                          Yerleşim Modu
                        </label>
                        <select
                          value={importFitMode}
                          onChange={(e) => setImportFitMode(e.target.value as any)}
                          className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-bold"
                        >
                          <option value="contain">En-Boy Koru (Ortala)</option>
                          <option value="cover">Tuvali Tam Doldur (Kırp)</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={importInvert}
                          onChange={(e) => setImportInvert(e.target.checked)}
                          className="rounded text-indigo-600"
                        />
                        Renkleri Ters Çevir (Invert)
                      </label>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  İptal
                </button>
                <button
                  onClick={applyImportedImageToCanvas}
                  disabled={!importedImageSrc}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md disabled:opacity-50 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Check size={16} /> Tuvale Aktar & Rötuşla
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
