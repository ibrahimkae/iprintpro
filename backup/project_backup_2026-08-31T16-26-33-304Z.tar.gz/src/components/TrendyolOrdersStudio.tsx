import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Label } from './ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from './ui/select';
import { formatMoney, type ResolvedBlock } from '../lib/template-variables';
import { ORDER_STATUS_TR, type NormalizedOrder } from '../lib/trendyol-types';
import {
  Printer, RefreshCw, Loader2, AlertTriangle,
  CheckCircle2, Package, FileText, Sparkles, Key, HelpCircle, Eye, X, Star, Check, Search
} from 'lucide-react';
import { ThermalTemplateRenderer } from '../template-archive/components/ThermalTemplateRenderer';
import { INITIAL_TEMPLATES } from '../template-archive/data/templates';
import { ThermalTemplate } from '../template-archive/types';
import { captureElementToDataUrl } from '../utils/dom-capture';

export interface TrendyolOrdersStudioProps {
  apiBase: string;
  pageWidth: number;
  onPrintShippingLabel: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onPrintPackingSlip: (blocks: ResolvedBlock[], label: string) => Promise<void>;
  onDirectPrint?: (dataUrl: string, title: string, widthMm?: number) => Promise<void>;
  onPreviewAndPrint?: (dataUrl: string, title: string, widthMm?: number) => void;
  onBack?: () => void;
}

const PAGE_SIZE = 50;
const PRINTED_KEY = 'iprint_printed_packages_v1';
const DEFAULT_SHIPPING_TEMPLATE_KEY = 'iprint_default_shipping_template_id';
const DEFAULT_FALLBACK_TEMPLATE = 'tpl-trendyol-mini-slip-57mm';
const PRINT_CONFIRM_MSG = 'Bu paket için etiket basılmış. Yine de basılsın mı?';

type StatusFilter = '' | 'Created' | 'Picking' | 'Invoiced';

const STATUS_FILTERS: { value: StatusFilter; label: string }[] = [
  { value: '', label: 'Tümü' },
  { value: 'Created', label: 'Yeni' },
  { value: 'Picking', label: 'Hazırlanıyor' },
  { value: 'Invoiced', label: 'Faturalandırıldı' }
];

const STATUS_BADGE: Record<string, string> = {
  Created: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300',
  Picking: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300',
  Invoiced: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200 dark:border-sky-900 text-sky-700 dark:text-sky-300',
  Shipped: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900 text-indigo-700 dark:text-indigo-300',
  Delivered: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-900 text-teal-700 dark:text-teal-300',
  Cancelled: 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-900 text-red-600 dark:text-red-400'
};

export function packageKey(o: NormalizedOrder): string {
  return `${o.orderNumber}:${o.packageId}`;
}

function loadPrintedPackages(): Set<string> {
  try {
    const raw = localStorage.getItem(PRINTED_KEY);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.filter((v): v is string => typeof v === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

function savePrintedPackages(set: Set<string>): void {
  try {
    localStorage.setItem(PRINTED_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // quota safe
  }
}

function formatDateTr(ms: number): string {
  const d = new Date(ms);
  if (Number.isNaN(d.getTime())) return String(ms);
  return d.toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' });
}

export function mapOrderToTemplateData(o: NormalizedOrder, template: ThermalTemplate): Record<string, any> {
  const data: Record<string, any> = { ...template.defaultData };
  const itemsText = o.items.map(i => `${i.quantity}x ${i.name}${i.variant ? ` (${i.variant})` : ''}`).join(', ');
  const totalQty = o.items.reduce((s, i) => s + i.quantity, 0);

  data.orderNumber = o.orderNumber;
  data.orderNo = o.orderNumber;
  data.order_id = o.orderNumber;
  data.recipientName = o.customerName;
  data.customerName = o.customerName;
  data.buyerName = o.customerName;
  data.customerPhone = o.customerPhone;
  data.recipientPhone = o.customerPhone;
  data.recipientAddress = o.address.line1;
  data.addressLine = o.address.line1;
  data.address = o.address.line1;
  data.recipientDistrictCity = `${o.address.district || ''} / ${o.address.city || ''}`.trim().replace(/^\/|\/$/g, '');
  data.destination = `${o.address.district || ''} / ${o.address.city || ''}`.toUpperCase().trim().replace(/^\/|\/$/g, '');
  data.barcodeVal = o.cargoTrackingNumber || o.packageId;
  data.barcode = o.cargoTrackingNumber || o.packageId;
  data.packageBarcode = o.cargoTrackingNumber || o.packageId;
  data.trackingBarcode = o.cargoTrackingNumber || o.packageId;
  data.cargoProvider = o.cargoProviderName || 'Trendyol Express';
  data.cargoName = o.cargoProviderName || 'Trendyol Express';
  data.carrier = o.cargoProviderName || 'Trendyol Express';
  data.productName = itemsText;
  data.itemSummary = itemsText;
  data.productQty = `${totalQty} Adet`;
  data.packageItemCount = `${totalQty}`;
  data.pieceInfo = `Koli 1 / 1 (Desi: 1.0)`;
  data.hubCode = `HUB: ${o.address.city ? o.address.city.toUpperCase().slice(0, 3) : 'IST'}-${o.cargoProviderName ? o.cargoProviderName.toUpperCase().slice(0, 3) : 'TEX'}-01`;
  data.originBranch = 'Merkez Çıkış Şubesi';
  data.totalPrice = formatMoney(o.totalPrice);
  data.date = formatDateTr(o.createdAt);
  data.marketplaceWarning = 'Kargo şirketinin dikkatine, bu bir pazaryeri anlaşmalı gönderisidir. İlgili anlaşma koduna göre işleme alınız.';

  if (o.items[0]) {
    data.productSku = o.items[0].sku || 'SKU-01';
    data.productBarcode = o.items[0].barcode || o.packageId;
    if (o.items[0].variant) {
      data.productColor = o.items[0].variant;
    }
  }
  return data;
}

export const MOCK_TRENDYOL_ORDERS: NormalizedOrder[] = [
  {
    orderNumber: 'TY-94827104',
    packageId: '734001928472',
    status: 'Created',
    customerName: 'Ahmet Yılmaz',
    customerPhone: '0532 *** ** 12',
    address: {
      line1: 'Atatürk Mah. Karanfil Sok. No: 14 D: 3',
      district: 'Kadıköy',
      city: 'İstanbul',
      postalCode: '34710',
      country: 'Türkiye'
    },
    items: [
      { name: 'Kablosuz Termal Yazıcı Etiketi 50x30mm', sku: 'TY-ETK-5030', barcode: '8680001928401', quantity: 2, variant: '500 Etiket/Rulo' },
      { name: 'Termal Rulo Kağıdı 57mm x 10m', sku: 'TY-RLO-57', barcode: '8680001928402', quantity: 5 }
    ],
    totalPrice: 429.90,
    cargoProviderName: 'Trendyol Express',
    cargoTrackingNumber: 'TEX-9988231',
    createdAt: Date.now() - 3600000 * 2
  },
  {
    orderNumber: 'TY-94826811',
    packageId: '734001928109',
    status: 'Picking',
    customerName: 'Ayşe Kaya',
    customerPhone: '0544 *** ** 88',
    address: {
      line1: 'Gazi Evrenos Cad. Paşa Apt. No: 8',
      district: 'Çankaya',
      city: 'Ankara',
      postalCode: '06680',
      country: 'Türkiye'
    },
    items: [
      { name: 'Ergonomik Bluetooth Mini Barkod Okuyucu', sku: 'TY-BRK-SCAN', barcode: '8680001928515', quantity: 1, variant: 'Siyah' }
    ],
    totalPrice: 899.00,
    cargoProviderName: 'Aras Kargo',
    cargoTrackingNumber: 'ARS-3321445',
    createdAt: Date.now() - 3600000 * 5
  },
  {
    orderNumber: 'TY-94825900',
    packageId: '734001927901',
    status: 'Invoiced',
    customerName: 'Mehmet Demir',
    customerPhone: '0505 *** ** 44',
    address: {
      line1: 'Karşıyaka Çarşı İçi No: 42',
      district: 'Karşıyaka',
      city: 'İzmir',
      postalCode: '35600',
      country: 'Türkiye'
    },
    items: [
      { name: 'Şeffaf Paketleme Bandı 45mmx100m', sku: 'TY-BND-45', barcode: '8680001928620', quantity: 6 },
      { name: 'A6 Kargo Poşeti Cepli 100 Adet', sku: 'TY-PST-A6', barcode: '8680001928621', quantity: 1 }
    ],
    totalPrice: 349.50,
    cargoProviderName: 'Yurtiçi Kargo',
    cargoTrackingNumber: 'YRT-7711902',
    createdAt: Date.now() - 3600000 * 18
  }
];

export function buildShippingBlocks(o: NormalizedOrder): ResolvedBlock[] {
  const blocks: ResolvedBlock[] = [
    { kind: 'text', value: 'KARGO ETİKETİ' },
    { kind: 'barcode', value: o.packageId, symbology: 'CODE128' }
  ];

  if (o.customerName.trim()) blocks.push({ kind: 'text', value: o.customerName });
  if (o.customerPhone?.trim()) blocks.push({ kind: 'text', value: o.customerPhone });
  if (o.address.line1.trim()) blocks.push({ kind: 'text', value: o.address.line1 });

  const districtCity = [o.address.district, o.address.city]
    .map(s => s.trim())
    .filter(Boolean)
    .join(' / ');
  if (districtCity) blocks.push({ kind: 'text', value: districtCity });

  const postalCountry = [o.address.postalCode, o.address.country]
    .map(s => s?.trim() ?? '')
    .filter(Boolean)
    .join(' ');
  if (postalCountry) blocks.push({ kind: 'text', value: postalCountry });

  blocks.push({
    kind: 'text',
    value: `${o.items.length} ürün • ${formatMoney(o.totalPrice)}`
  });

  const cargoLine = [o.cargoProviderName, o.cargoTrackingNumber]
    .map(s => s?.trim() ?? '')
    .filter(Boolean)
    .join(' · ');
  if (cargoLine) blocks.push({ kind: 'text', value: cargoLine });

  blocks.push({ kind: 'text', value: formatDateTr(o.createdAt) });
  return blocks;
}

export function buildPackingBlocks(o: NormalizedOrder): ResolvedBlock[] {
  const blocks: ResolvedBlock[] = [
    { kind: 'text', value: 'PAKET İÇİ SİPARİŞ FİŞİ' },
    { kind: 'qr', value: o.orderNumber },
    { kind: 'text', value: `Sipariş: ${o.orderNumber}` }
  ];

  for (const item of o.items) {
    blocks.push({
      kind: 'text',
      value: `${item.quantity}x ${item.name}${item.variant ? ` (${item.variant})` : ''}`
    });
  }

  blocks.push({ kind: 'text', value: 'Bizi tercih ettiğiniz için teşekkürler!' });
  return blocks;
}

export function TrendyolOrdersStudio(props: TrendyolOrdersStudioProps) {
  const [orders, setOrders] = useState<NormalizedOrder[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('');
  const [days, setDays] = useState<'1' | '7' | '30'>('7');
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [hasMore, setHasMore] = useState(false);

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [printed, setPrinted] = useState<Set<string>>(() => loadPrintedPackages());
  const [printing, setPrinting] = useState(false);

  // Filter state
  const [cargoFilter, setCargoFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Batch Print engine state
  const [batchDelayMs, setBatchDelayMs] = useState<number>(400);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number; orderNumber: string } | null>(null);
  const [batchPrintOrder, setBatchPrintOrder] = useState<NormalizedOrder | null>(null);
  const [batchCancelRequested, setBatchCancelRequested] = useState<boolean>(false);
  const batchHiddenRef = useRef<HTMLDivElement>(null);
  const batchCancelRef = useRef<boolean>(false);

  // Template management
  const shippingTemplates = useMemo(() => {
    return INITIAL_TEMPLATES.filter(
      (t) => t.category === 'ecommerce_shipping' || t.category === 'shipping' || t.tags.includes('kargo') || t.tags.includes('trendyol')
    );
  }, []);

  const [defaultTemplateId, setDefaultTemplateId] = useState<string>(() => {
    return localStorage.getItem(DEFAULT_SHIPPING_TEMPLATE_KEY) || DEFAULT_FALLBACK_TEMPLATE;
  });
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(() => {
    return localStorage.getItem(DEFAULT_SHIPPING_TEMPLATE_KEY) || DEFAULT_FALLBACK_TEMPLATE;
  });

  const [previewOrder, setPreviewOrder] = useState<NormalizedOrder | null>(null);
  const [isPrintingSingle, setIsPrintingSingle] = useState(false);
  const [savedDefaultNotice, setSavedDefaultNotice] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null);

  const activeTemplate = useMemo(() => {
    return shippingTemplates.find(t => t.id === selectedTemplateId) || shippingTemplates[0] || INITIAL_TEMPLATES[0];
  }, [shippingTemplates, selectedTemplateId]);

  const handleSetDefaultTemplate = (tplId: string) => {
    localStorage.setItem(DEFAULT_SHIPPING_TEMPLATE_KEY, tplId);
    setDefaultTemplateId(tplId);
    setSavedDefaultNotice(true);
    setTimeout(() => setSavedDefaultNotice(false), 2500);
  };

  const handleOpenPreviewModal = (order: NormalizedOrder) => {
    setSelectedTemplateId(defaultTemplateId);
    setPreviewOrder(order);
  };

  const handlePrintSingleOrder = async (order: NormalizedOrder) => {
    if (!previewRef.current) return;
    setIsPrintingSingle(true);
    try {
      const dataUrl = await captureElementToDataUrl(previewRef.current, {
        scale: 2,
        backgroundColor: '#ffffff'
      });
      const targetWidth = activeTemplate.recommendedWidthMm || 57;
      if (props.onDirectPrint) {
        await props.onDirectPrint(dataUrl, `Kargo-${order.orderNumber}`, targetWidth);
      } else if (props.onPreviewAndPrint) {
        props.onPreviewAndPrint(dataUrl, `Kargo-${order.orderNumber}`, targetWidth);
      } else {
        await props.onPrintShippingLabel(buildShippingBlocks(order), `Kargo-${order.orderNumber}`);
      }
      const printedSet = new Set(printed);
      printedSet.add(packageKey(order));
      savePrintedPackages(printedSet);
      setPrinted(new Set(printedSet));
      setPreviewOrder(null);
    } catch (err) {
      console.error('Print single error:', err);
      await props.onPrintShippingLabel(buildShippingBlocks(order), `Kargo-${order.orderNumber}`);
    } finally {
      setIsPrintingSingle(false);
    }
  };

  const handleOpenInPreviewStudio = async (order: NormalizedOrder) => {
    if (!previewRef.current) return;
    try {
      const dataUrl = await captureElementToDataUrl(previewRef.current, {
        scale: 2,
        backgroundColor: '#ffffff'
      });
      const targetWidth = activeTemplate.recommendedWidthMm || 57;
      if (props.onPreviewAndPrint) {
        props.onPreviewAndPrint(dataUrl, `Kargo-${order.orderNumber}`, targetWidth);
      }
      setPreviewOrder(null);
    } catch (err) {
      console.error('Open preview studio error:', err);
    }
  };

  const serverPageRef = useRef(0);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const [isDemoMode, setIsDemoMode] = useState(false);
  const [showApiGuide, setShowApiGuide] = useState(false);

  const fetchPage = useCallback(
    async (page: number, replace: boolean) => {
      if (replace) setLoading(true);
      else setLoadingMore(true);
      setError(null);

      try {
        const params = new URLSearchParams({
          status: statusFilter,
          page: String(page),
          size: String(PAGE_SIZE),
          days
        });

        let list: NormalizedOrder[] = [];
        let isDemo = false;

        try {
          const res = await fetch(`${props.apiBase}/trendyol/orders?${params.toString()}`);
          const ctype = res.headers.get('content-type') || '';
          
          if (!res.ok || !ctype.includes('application/json')) {
            list = MOCK_TRENDYOL_ORDERS;
            isDemo = true;
          } else {
            const data: unknown = await res.json();
            list = Array.isArray(data)
              ? (data as NormalizedOrder[])
              : Array.isArray((data as { orders?: NormalizedOrder[] })?.orders)
                ? ((data as { orders: NormalizedOrder[] }).orders)
                : [];
          }
        } catch {
          list = MOCK_TRENDYOL_ORDERS;
          isDemo = true;
        }

        if (!mountedRef.current) return;
        setIsDemoMode(isDemo);
        serverPageRef.current = page;
        setHasMore(!isDemo && list.length === PAGE_SIZE);
        setOrders(prev => (replace ? list : [...prev, ...list]));
        if (replace) {
          setSelected(new Set());
          setVisibleCount(PAGE_SIZE);
        } else {
          setVisibleCount(c => c + PAGE_SIZE);
        }
      } catch (e) {
        if (mountedRef.current) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (mountedRef.current) {
          setLoading(false);
          setLoadingMore(false);
        }
      }
    },
    [props.apiBase, statusFilter, days]
  );

  useEffect(() => {
    void fetchPage(0, true);
  }, [fetchPage]);

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      if (cargoFilter !== 'all') {
        const provider = (o.cargoProviderName || '').toLowerCase();
        if (!provider.includes(cargoFilter.toLowerCase())) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesOrder = o.orderNumber.toLowerCase().includes(q);
        const matchesName = o.customerName.toLowerCase().includes(q);
        const matchesCity = o.address.city.toLowerCase().includes(q);
        const matchesDistrict = o.address.district.toLowerCase().includes(q);
        const matchesTracking = (o.cargoTrackingNumber || '').toLowerCase().includes(q);
        if (!matchesOrder && !matchesName && !matchesCity && !matchesDistrict && !matchesTracking) {
          return false;
        }
      }
      return true;
    });
  }, [orders, cargoFilter, searchQuery]);

  const visible = useMemo(() => filteredOrders.slice(0, visibleCount), [filteredOrders, visibleCount]);
  const selectedCount = useMemo(
    () => filteredOrders.filter(o => selected.has(packageKey(o))).length,
    [filteredOrders, selected]
  );
  const allVisibleSelected =
    visible.length > 0 && visible.every(o => selected.has(packageKey(o)));

  function toggleRow(key: string) {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleAllVisible() {
    setSelected(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) visible.forEach(o => next.delete(packageKey(o)));
      else visible.forEach(o => next.add(packageKey(o)));
      return next;
    });
  }

  function handleShowMore() {
    if (visibleCount < filteredOrders.length) {
      setVisibleCount(c => c + PAGE_SIZE);
      return;
    }
    if (hasMore && !loading && !loadingMore) void fetchPage(serverPageRef.current + 1, false);
  }

  async function runPrint(kind: 'label' | 'slip') {
    const chosen = filteredOrders.filter(o => selected.has(packageKey(o)));
    if (chosen.length === 0 || printing) return;

    setPrinting(true);
    batchCancelRef.current = false;
    setBatchCancelRequested(false);
    const printedSet = new Set(printed);
    const failures: string[] = [];

    try {
      for (let i = 0; i < chosen.length; i++) {
        if (batchCancelRef.current) {
          failures.push(`Toplu baskı iptal edildi (${i}/${chosen.length} tamamlandı).`);
          break;
        }
        const o = chosen[i];
        const key = packageKey(o);
        setBatchProgress({ current: i + 1, total: chosen.length, orderNumber: o.orderNumber });

        if (printedSet.has(key) && chosen.length === 1 && !window.confirm(PRINT_CONFIRM_MSG)) continue;

        try {
          if (kind === 'label' && props.onDirectPrint) {
            setBatchPrintOrder(o);
            await new Promise(r => setTimeout(r, 80));
            if (batchHiddenRef.current) {
              const dataUrl = await captureElementToDataUrl(batchHiddenRef.current, {
                scale: 2,
                backgroundColor: '#ffffff'
              });
              const targetWidth = activeTemplate.recommendedWidthMm || 57;
              await props.onDirectPrint(dataUrl, `Kargo-${o.orderNumber}`, targetWidth);
            }
          } else if (kind === 'label') {
            await props.onPrintShippingLabel(buildShippingBlocks(o), 'kargo-etiketi');
          } else {
            await props.onPrintPackingSlip(buildPackingBlocks(o), 'koli-fisi');
          }
          printedSet.add(key);
          savePrintedPackages(printedSet);
          setPrinted(new Set(printedSet));
        } catch (e) {
          failures.push(`${o.orderNumber}: ${e instanceof Error ? e.message : String(e)}`);
        }

        if (i < chosen.length - 1 && batchDelayMs > 0) {
          await new Promise(r => setTimeout(r, batchDelayMs));
        }
      }
    } finally {
      setPrinting(false);
      setBatchProgress(null);
      setBatchPrintOrder(null);
      if (failures.length > 0) setError(failures.slice(0, 3).join(' • '));
    }
  }

  const showMoreAvailable = visibleCount < orders.length || hasMore;

  return (
    <div className="space-y-3">
      {/* Top Header Contextual Controls */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2 py-1 shadow-xs">
          <Star size={12} className="text-amber-500 mr-1.5 fill-amber-500 shrink-0" />
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mr-1.5 hidden sm:inline">Varsayılan Şablon:</span>
          <Select
            value={defaultTemplateId}
            onValueChange={(val) => val && handleSetDefaultTemplate(val)}
          >
            <SelectTrigger className="h-6 text-[11px] font-bold border-none bg-transparent shadow-none p-0 max-w-[170px] sm:max-w-[210px] focus:ring-0">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-900 dark:border-slate-800">
              {shippingTemplates.map((tpl) => (
                <SelectItem key={tpl.id} value={tpl.id} className="text-xs">
                  {tpl.title} ({tpl.recommendedWidthMm}mm)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowApiGuide(!showApiGuide)}
          className="h-8 text-xs font-bold rounded-lg border-teal-200 dark:border-teal-900 bg-teal-50/50 dark:bg-teal-950/30 text-teal-700 dark:text-teal-300 hover:bg-teal-100"
        >
          <HelpCircle size={13} className="mr-1 text-teal-600" /> API Rehberi
        </Button>
      </div>

      {showApiGuide && (
        <Card className="p-4 rounded-xl border border-teal-200 dark:border-teal-900 shadow-sm bg-gradient-to-r from-teal-50/90 to-emerald-50/90 dark:from-teal-950/40 dark:to-emerald-950/40 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <Key size={18} className="text-teal-600 dark:text-teal-400 shrink-0" />
              <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">Trendyol API Entegrasyon Bilgilendirmesi</h4>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setShowApiGuide(false)} className="h-6 text-[10px] px-2 text-slate-500">Kapat</Button>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Tarayıcı güvenlik kuralları (CORS) nedeniyle Trendyol API endpoints (<code>api.trendyol.com</code>) doğrudan istemci tarayıcısından çağrılamaz. 
            Sistemimiz sunucu tarafında güvenli proxy üzerinden Trendyol siparişlerinizi ve ürünlerinizi çeker.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono">
            <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg border border-teal-100 dark:border-teal-900">
              <span className="text-[10px] text-slate-400 font-sans font-bold block">1. Satıcı ID (Supplier ID)</span>
              <span>Trendyol Panel &gt; Hesap Ayarları</span>
            </div>
            <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg border border-teal-100 dark:border-teal-900">
              <span className="text-[10px] text-slate-400 font-sans font-bold block">2. API Key & Secret</span>
              <span>Pazaryeri Entegrasyon Bilgileri</span>
            </div>
            <div className="bg-white/80 dark:bg-slate-900/80 p-2 rounded-lg border border-teal-100 dark:border-teal-900">
              <span className="text-[10px] text-slate-400 font-sans font-bold block">3. Otomatik Etiket</span>
              <span>TEX Kargo & Paket Barkodu</span>
            </div>
          </div>
        </Card>
      )}

      {isDemoMode && (
        <div className="flex items-center justify-between gap-2 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/80 p-3 text-xs text-amber-800 dark:text-amber-200 shadow-xs">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-amber-500 shrink-0" />
            <span>
              <strong>Akıllı Demo Sipariş Modu:</strong> Hazır siparişler yüklendi. Herhangi bir siparişe tıklayarak canlı kargo etiketini görüntüleyebilir, varsayılan şablonunuzu belirleyip anında yazdırabilirsiniz.
            </span>
          </div>
        </div>
      )}

      <Card className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* Status Filters */}
          <div className="flex flex-wrap gap-1.5">
            {STATUS_FILTERS.map(f => (
              <button
                key={f.value || 'all'}
                type="button"
                onClick={() => setStatusFilter(f.value)}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === f.value
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 ml-auto flex-wrap">
            <Label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider shrink-0">
              Son
            </Label>
            <Select value={days} onValueChange={v => setDays((v ?? '7') as '1' | '7' | '30')}>
              <SelectTrigger className="w-24 h-8 rounded-lg bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-xs font-bold">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1" className="text-xs">1 gün</SelectItem>
                <SelectItem value="7" className="text-xs">7 gün</SelectItem>
                <SelectItem value="30" className="text-xs">30 gün</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              disabled={loading}
              onClick={() => void fetchPage(0, true)}
              className="h-8 rounded-lg text-xs font-bold px-3 dark:border-slate-700 cursor-pointer"
            >
              {loading ? (
                <Loader2 size={13} className="mr-1.5 animate-spin" />
              ) : (
                <RefreshCw size={13} className="mr-1.5" />
              )}
              Yenile
            </Button>
          </div>
        </div>

        {/* Live Search & Cargo Provider Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 border-t border-slate-100 dark:border-slate-800 pt-2.5">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Sipariş no, alıcı adı, şehir veya takip no ara..."
              className="w-full h-8 pl-8 pr-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 shrink-0">Kargo Firması:</span>
            <Select value={cargoFilter} onValueChange={(val) => setCargoFilter(val || 'all')}>
              <SelectTrigger className="h-8 text-xs font-bold rounded-lg border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 flex-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-xs">Tümü (Tüm Kargo Firmaları)</SelectItem>
                <SelectItem value="Trendyol Express" className="text-xs">Trendyol Express (TEX)</SelectItem>
                <SelectItem value="Aras Kargo" className="text-xs">Aras Kargo</SelectItem>
                <SelectItem value="Yurtiçi Kargo" className="text-xs">Yurtiçi Kargo</SelectItem>
                <SelectItem value="Sürat Kargo" className="text-xs">Sürat Kargo</SelectItem>
                <SelectItem value="MNG Kargo" className="text-xs">MNG Kargo</SelectItem>
                <SelectItem value="HepsiJet" className="text-xs">HepsiJet</SelectItem>
                <SelectItem value="PTT Kargo" className="text-xs">PTT Kargo</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-2 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 p-2.5">
            <AlertTriangle size={14} className="mt-0.5 text-red-500 shrink-0" />
            <span className="text-xs font-bold text-red-600 dark:text-red-400">{error}</span>
          </div>
        )}
      </Card>

      {loading ? (
        <Card className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 flex items-center justify-center">
          <Loader2 size={22} className="animate-spin text-teal-600" />
        </Card>
      ) : orders.length === 0 ? (
        <Card className="p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 text-center">
          <Package size={22} className="mx-auto mb-2 text-slate-300" />
          <div className="text-xs font-bold text-slate-400">Sipariş bulunamadı.</div>
        </Card>
      ) : (
        <Card className="rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs bg-white dark:bg-slate-900 overflow-hidden">
          <div className="flex items-center justify-between p-2.5 border-b border-slate-100 dark:border-slate-800 select-none bg-slate-50/50 dark:bg-slate-900/50">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={allVisibleSelected}
                onChange={toggleAllVisible}
                className="h-4 w-4 rounded accent-teal-600"
              />
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Tümünü seç ({visible.length})
              </span>
            </label>
            <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
              {selectedCount} seçili
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {visible.map(o => {
              const key = packageKey(o);
              const isPrinted = printed.has(key);
              const trStatus = ORDER_STATUS_TR[o.status] ?? o.status;
              return (
                <div
                  key={key}
                  className={`flex items-center gap-2.5 p-2.5 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60 ${
                    selected.has(key) ? 'bg-teal-50/60 dark:bg-teal-950/20' : ''
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selected.has(key)}
                    onChange={() => toggleRow(key)}
                    className="h-4 w-4 rounded accent-teal-600 shrink-0 cursor-pointer"
                  />

                  {/* Clickable order info opening preview */}
                  <div
                    onClick={() => handleOpenPreviewModal(o)}
                    className="flex-1 min-w-0 cursor-pointer group"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate group-hover:text-teal-600 transition-colors">
                        {o.customerName}
                      </span>
                      {isPrinted && (
                        <span className="inline-flex items-center gap-0.5 shrink-0 py-0.5 px-1.5 rounded-md bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 text-[10px] font-bold text-teal-600 dark:text-teal-400">
                          <CheckCircle2 size={10} /> Basıldı
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        #{o.packageId}
                      </span>
                      <span
                        className={`py-0.5 px-1.5 rounded-md border text-[10px] font-bold ${
                          STATUS_BADGE[o.status] ??
                          'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {trStatus}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {o.items.reduce((n, i) => n + i.quantity, 0)} kalem
                      </span>
                      <span className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold opacity-0 group-hover:opacity-100 transition-opacity hidden sm:inline">
                        (Etiketi Gör)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">
                      {formatMoney(o.totalPrice)}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleOpenPreviewModal(o)}
                      className="h-7 px-2 text-[11px] font-bold rounded-lg gap-1 border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950 cursor-pointer"
                      title="Kargo Etiketini Önizle & Bas"
                    >
                      <Eye size={12} />
                      <span className="hidden sm:inline">Etiket</span>
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>

          {showMoreAvailable && (
            <button
              type="button"
              onClick={handleShowMore}
              disabled={loadingMore}
              className="w-full py-2.5 text-xs font-bold text-teal-600 dark:text-teal-400 border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors disabled:opacity-60 flex items-center justify-center gap-1.5"
            >
              {loadingMore ? (
                <>
                  <Loader2 size={13} className="animate-spin" /> Yükleniyor…
                </>
              ) : (
                <>Daha fazla ({Math.max(orders.length - visibleCount, hasMore ? PAGE_SIZE : 0)})</>
              )}
            </button>
          )}
        </Card>
      )}

      {/* Bulk Print Actions Floating Bar */}
      <div className="sticky bottom-3 z-10">
        <Card className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm bg-white/95 dark:bg-slate-900/95 backdrop-blur flex flex-wrap items-center gap-2">
          {/* Delay Selector */}
          <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/80 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
            <span className="text-[10px] font-bold shrink-0">Baskı Gecikmesi:</span>
            <select
              value={batchDelayMs}
              onChange={(e) => setBatchDelayMs(Number(e.target.value))}
              className="bg-transparent text-[11px] font-bold focus:outline-none cursor-pointer"
            >
              <option value={200} className="bg-white dark:bg-slate-900">200 ms (Hızlı)</option>
              <option value={400} className="bg-white dark:bg-slate-900">400 ms (Normal)</option>
              <option value={800} className="bg-white dark:bg-slate-900">800 ms (Güvenli)</option>
              <option value={1200} className="bg-white dark:bg-slate-900">1200 ms (BLE Stabil)</option>
            </select>
          </div>

          <Button
            disabled={selectedCount === 0 || printing}
            onClick={() => void runPrint('label')}
            className="flex-1 min-w-[140px] h-9 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs cursor-pointer"
          >
            {printing ? <Loader2 size={14} className="mr-1.5 animate-spin" /> : <Printer size={14} className="mr-1.5" />}
            Toplu Etiket Bas ({selectedCount})
          </Button>

          <Button
            variant="outline"
            disabled={selectedCount === 0 || printing}
            onClick={() => void runPrint('slip')}
            className="flex-1 min-w-[140px] h-9 rounded-xl font-bold text-xs dark:border-slate-700 cursor-pointer"
          >
            <FileText size={14} className="mr-1.5" /> Koli Fişi Bas ({selectedCount})
          </Button>
        </Card>
      </div>

      {/* Offscreen Hidden Rendering Element for Batch Print Jobs */}
      {batchPrintOrder && (
        <div style={{ position: 'fixed', left: '-9999px', top: '-9999px', pointerEvents: 'none', zIndex: -100 }}>
          <div ref={batchHiddenRef} className="bg-white p-0.5 inline-block">
            <ThermalTemplateRenderer
              template={activeTemplate}
              data={mapOrderToTemplateData(batchPrintOrder, activeTemplate)}
              widthMm={activeTemplate.recommendedWidthMm || 57}
              paperStyle="standard"
              scale={1}
            />
          </div>
        </div>
      )}

      {/* Batch Progress Modal */}
      <AnimatePresence>
        {batchProgress && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-2xl p-6 w-full max-w-sm text-center shadow-2xl space-y-4"
            >
              <div className="w-12 h-12 rounded-full bg-teal-500/10 border border-teal-500/30 flex items-center justify-center mx-auto text-teal-600 dark:text-teal-400">
                <Printer size={24} className="animate-pulse" />
              </div>

              <div>
                <h4 className="font-bold text-slate-800 dark:text-slate-100 text-base">Toplu Baskı Yapılıyor</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono">
                  Sipariş: <span className="text-teal-600 dark:text-teal-400 font-bold">{batchProgress.orderNumber}</span>
                </p>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-mono font-bold text-slate-500 dark:text-slate-400">
                  <span>İlerleme</span>
                  <span>{batchProgress.current} / {batchProgress.total}</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 transition-all duration-300"
                    style={{ width: `${(batchProgress.current / batchProgress.total) * 100}%` }}
                  />
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  batchCancelRef.current = true;
                  setBatchCancelRequested(true);
                }}
                disabled={batchCancelRequested}
                className="w-full text-xs font-bold border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 h-8 rounded-xl"
              >
                {batchCancelRequested ? 'İptal Ediliyor...' : 'Baskıyı İptal Et'}
              </Button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Single Order Shipping Label Preview & Direct Print Modal */}
      <AnimatePresence>
        {previewOrder && (
          <div className="fixed inset-0 z-50 bg-black/60 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-2xl w-full max-w-2xl max-h-[95vh] flex flex-col shadow-2xl overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-3.5 sm:p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/80">
                <div>
                  <div className="flex items-center gap-2">
                    <Package size={16} className="text-teal-600 dark:text-teal-400" />
                    <h3 className="font-bold text-sm sm:text-base text-slate-800 dark:text-slate-100">
                      Kargo Etiketi Önizleme
                    </h3>
                    <span className="bg-teal-50 dark:bg-teal-500/20 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-500/30 text-[10px] font-mono px-1.5 py-0.5 rounded font-bold">
                      {previewOrder.orderNumber}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {previewOrder.customerName} • {previewOrder.cargoProviderName} ({previewOrder.cargoTrackingNumber || previewOrder.packageId})
                  </p>
                </div>
                <button
                  onClick={() => setPreviewOrder(null)}
                  className="p-1.5 rounded-full text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Template Selector & Default Switcher Toolbar */}
              <div className="p-3 bg-slate-50/90 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                  <Label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider shrink-0">
                    Şablon:
                  </Label>
                  <Select
                    value={selectedTemplateId}
                    onValueChange={(val) => val && setSelectedTemplateId(val)}
                  >
                    <SelectTrigger className="h-8 text-xs font-bold rounded-lg bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white max-h-64">
                      {shippingTemplates.map((t) => (
                        <SelectItem key={t.id} value={t.id} className="text-xs">
                          {t.title} ({t.recommendedWidthMm}mm{t.heightMm ? `×${t.heightMm}mm` : ''})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleSetDefaultTemplate(selectedTemplateId)}
                  className={`h-8 rounded-lg text-xs font-bold gap-1.5 transition-all cursor-pointer ${
                    selectedTemplateId === defaultTemplateId
                      ? 'bg-amber-50 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-500/40 hover:bg-amber-100 dark:hover:bg-amber-500/30'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {savedDefaultNotice ? (
                    <>
                      <Check size={13} className="text-emerald-500" />
                      <span className="text-emerald-600 dark:text-emerald-300">Varsayılan Kaydedildi!</span>
                    </>
                  ) : selectedTemplateId === defaultTemplateId ? (
                    <>
                      <Star size={13} className="fill-amber-500 text-amber-500" />
                      <span>Varsayılan Şablon</span>
                    </>
                  ) : (
                    <>
                      <Star size={13} />
                      <span>Varsayılan Yap</span>
                    </>
                  )}
                </Button>
              </div>

              {/* Rendered Live Cargo Label Preview Stage */}
              <div className="flex-1 overflow-auto p-3 sm:p-4 flex flex-col items-center justify-center bg-slate-100/70 dark:bg-slate-950 min-h-[280px]">
                {/* Template Info Badge */}
                <div className="mb-2 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                  <span className="bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-bold shadow-xs">
                    {activeTemplate.recommendedWidthMm || 57} mm ({(activeTemplate.recommendedWidthMm === 57 ? 384 : activeTemplate.recommendedWidthMm === 80 ? 576 : 800)} px)
                  </span>
                  <span className="truncate max-w-[200px] sm:max-w-[300px]">• {activeTemplate.title}</span>
                </div>

                <div
                  ref={previewRef}
                  className="bg-white rounded-lg shadow-xl p-1 sm:p-2 max-w-full overflow-visible flex items-center justify-center border border-slate-200 dark:border-slate-800"
                >
                  <ThermalTemplateRenderer
                    template={activeTemplate}
                    data={mapOrderToTemplateData(previewOrder, activeTemplate)}
                    widthMm={activeTemplate.recommendedWidthMm || 57}
                    paperStyle="standard"
                    scale={1}
                  />
                </div>
              </div>

              {/* Modal Footer Actions */}
              <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-wrap items-center justify-between gap-2">
                <Button
                  variant="ghost"
                  onClick={() => setPreviewOrder(null)}
                  className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white h-9 rounded-xl"
                >
                  Kapat
                </Button>

                <div className="flex items-center gap-2 flex-wrap">
                  <Button
                    variant="outline"
                    onClick={async () => {
                      await props.onPrintPackingSlip(buildPackingBlocks(previewOrder), 'koli-fisi');
                      setPreviewOrder(null);
                    }}
                    className="text-xs font-bold h-9 rounded-xl border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <FileText size={14} className="mr-1.5" /> Paket Fişi
                  </Button>

                  {props.onPreviewAndPrint && (
                    <Button
                      variant="outline"
                      onClick={() => handleOpenInPreviewStudio(previewOrder)}
                      className="text-xs font-bold h-9 rounded-xl border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 gap-1.5"
                    >
                      <Eye size={14} className="text-teal-600 dark:text-teal-400" /> Önizle & Düzenle
                    </Button>
                  )}

                  <Button
                    onClick={() => handlePrintSingleOrder(previewOrder)}
                    disabled={isPrintingSingle}
                    className="bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs h-9 px-4 rounded-xl shadow-md shadow-teal-600/30 gap-1.5 cursor-pointer"
                  >
                    {isPrintingSingle ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : (
                      <Printer size={14} />
                    )}
                    {isPrintingSingle ? 'Yazdırılıyor...' : 'Termal Yazdır'}
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
